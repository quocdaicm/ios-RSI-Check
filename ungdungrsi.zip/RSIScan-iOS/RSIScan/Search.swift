import SwiftUI

// MARK: - So khớp gần đúng (bỏ dấu tiếng Việt, bỏ dấu gạch/khoảng trắng, chịu gõ sai nhẹ)

enum Fuzzy {
    static func norm(_ s: String) -> String {
        let f = s.folding(options: [.diacriticInsensitive, .caseInsensitive],
                          locale: Locale(identifier: "en_US"))
        return f.replacingOccurrences(of: "đ", with: "d")
    }

    static func words(_ s: String) -> [String] {
        norm(s).split(whereSeparator: { !($0.isLetter || $0.isNumber) }).map { String($0) }
    }

    static func lev(_ a: [Character], _ b: [Character]) -> Int {
        if a.isEmpty { return b.count }
        if b.isEmpty { return a.count }
        var prev = Array(0...b.count)
        for i in 1...a.count {
            var cur = [Int](repeating: 0, count: b.count + 1)
            cur[0] = i
            for j in 1...b.count {
                let cost = a[i - 1] == b[j - 1] ? 0 : 1
                cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            }
            prev = cur
        }
        return prev[b.count]
    }

    static func maxDist(_ n: Int) -> Int { n >= 7 ? 2 : (n >= 4 ? 1 : 0) }

    static func isSubsequence(_ q: String, of t: String) -> Bool {
        var it = t.makeIterator()
        for c in q {
            var found = false
            while let x = it.next() {
                if x == c { found = true; break }
            }
            if !found { return false }
        }
        return true
    }

    /// 0 = không khớp. 110/100 = chứa nguyên cụm, 85 = chứa đủ các từ, 60 = gần đúng, 40 = khớp rải rác (chỉ cho mã)
    static func score(_ query: String, in text: String, subsequence: Bool = false) -> Int {
        let qw = words(query)
        let q = qw.joined()
        if q.isEmpty { return 0 }
        let tw = words(text)
        let t = tw.joined()
        if t.isEmpty { return 0 }

        if t.contains(q) { return t.hasPrefix(q) ? 110 : 100 }
        if qw.count > 1 && qw.allSatisfy({ t.contains($0) }) { return 85 }

        var allOK = true
        for tok in qw {
            if t.contains(tok) { continue }
            // số thì phải đúng, không đoán gần đúng
            let d = maxDist(tok.count)
            if d == 0 || tok.allSatisfy({ $0.isNumber }) { allOK = false; break }
            let tc = Array(tok)
            let ok = tw.contains { w in
                let wc = Array(w)
                if abs(wc.count - tc.count) <= d && lev(tc, wc) <= d { return true }
                if wc.count > tc.count && lev(tc, Array(wc.prefix(tc.count))) <= d { return true }
                return false
            }
            if !ok { allOK = false; break }
        }
        if allOK { return 60 }

        if subsequence && q.count >= 4 && isSubsequence(q, of: t) { return 40 }
        return 0
    }
}

// MARK: - Kết quả tìm kiếm và gợi ý

struct SearchHit: Identifiable {
    var slip: Slip
    var items: [Item]      // các kiện hàng khớp bên trong phiếu
    var score: Int
    var id: UUID { slip.id }
}

struct Suggestion: Identifiable {
    enum Kind { case rsi, package, desc }
    let kind: Kind
    let text: String
    let sub: String
    let slipID: UUID
    var id: String { "\(kind)-\(slipID)-\(text)" }
}

extension Store {
    func itemScore(_ q: String, _ it: Item) -> Int {
        max(Fuzzy.score(q, in: it.packageNo, subsequence: true),
            Fuzzy.score(q, in: it.desc),
            Fuzzy.score(q, in: it.tag))
    }

    func hits(_ q: String) -> [SearchHit] {
        let t = q.trimmingCharacters(in: .whitespaces)
        let base = slipsNewestFirst()
        guard !t.isEmpty else { return base.map { SearchHit(slip: $0, items: [], score: 0) } }

        var out: [SearchHit] = []
        for s in base {
            let rsiScore = Fuzzy.score(t, in: s.rsiNo, subsequence: true)
            var best = rsiScore
            for f in [s.requestDate, s.project, s.remark] {
                let sc = Fuzzy.score(t, in: f)
                if sc >= 85 { best = max(best, sc - 20) }
            }
            var matched: [(Item, Int)] = []
            for it in s.items {
                let sc = itemScore(t, it)
                if sc > 0 { matched.append((it, sc)) }
            }
            matched.sort { $0.1 > $1.1 }
            if let top = matched.first {
                best = max(best, top.1)
                // RSI đã khớp rõ thì chỉ hiện kiện hàng khớp rõ
                let minScore = rsiScore >= 100 ? 85 : min(top.1, 85)
                matched = matched.filter { $0.1 >= minScore }
            }
            if best > 0 {
                out.append(SearchHit(slip: s, items: matched.map { $0.0 }, score: best))
            }
        }
        return out.enumerated()
            .sorted { $0.element.score != $1.element.score
                ? $0.element.score > $1.element.score
                : $0.offset < $1.offset }
            .map { $0.element }
    }

    func suggestions(_ q: String, limit: Int = 6) -> [Suggestion] {
        let t = q.trimmingCharacters(in: .whitespaces)
        guard !t.isEmpty else { return [] }
        var seen = Set<String>()
        var list: [(Suggestion, Int)] = []

        for s in slipsNewestFirst() {
            let r = Fuzzy.score(t, in: s.rsiNo, subsequence: true)
            if r > 0 && seen.insert("r-" + s.rsiNo.uppercased()).inserted {
                let sub = "\(s.items.count) kiện" + (s.requestDate.isEmpty ? "" : " · \(s.requestDate)")
                list.append((Suggestion(kind: .rsi, text: s.rsiNo, sub: sub, slipID: s.id), r + 8))
            }
            for it in s.items {
                let p = Fuzzy.score(t, in: it.packageNo, subsequence: true)
                if p > 0 && seen.insert("p-\(s.id)-" + it.packageNo.uppercased()).inserted {
                    let sub = "trong \(s.rsiNo)" + (it.qty.isEmpty ? "" : " · \(it.qty) \(it.unit)")
                    list.append((Suggestion(kind: .package, text: it.packageNo, sub: sub, slipID: s.id), p + 4))
                }
                if !it.desc.isEmpty {
                    let d = Fuzzy.score(t, in: it.desc)
                    if d > 0 && seen.insert("d-\(s.id)-" + it.desc.uppercased()).inserted {
                        let sub = "trong \(s.rsiNo) · \(it.packageNo)"
                        list.append((Suggestion(kind: .desc, text: it.desc, sub: sub, slipID: s.id), d))
                    }
                }
            }
        }
        return list.enumerated()
            .sorted { $0.element.1 != $1.element.1 ? $0.element.1 > $1.element.1 : $0.offset < $1.offset }
            .prefix(limit)
            .map { $0.element.0 }
    }
}

// MARK: - Tô sáng chữ khớp

func highlighted(_ text: String, _ q: String) -> AttributedString {
    var a = AttributedString(text)
    let t = q.trimmingCharacters(in: .whitespaces)
    guard !t.isEmpty,
          let r = text.range(of: t, options: [.caseInsensitive, .diacriticInsensitive]),
          let ar = Range(r, in: a) else { return a }
    a[ar].backgroundColor = Theme.amberSoft
    a[ar].foregroundColor = Theme.amberText
    return a
}

// MARK: - Giao diện gợi ý và kiện hàng khớp

struct SuggestionRow: View {
    let s: Suggestion
    let query: String

    var icon: String {
        switch s.kind {
        case .rsi: return "doc.text"
        case .package: return "shippingbox"
        case .desc: return "text.alignleft"
        }
    }

    var label: String {
        switch s.kind {
        case .rsi: return "Số RSI"
        case .package: return "Mã kiện"
        case .desc: return "Tên hàng"
        }
    }

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(Theme.primaryDark)
                .frame(width: 32, height: 32)
                .background(Theme.primarySoft)
                .clipShape(Circle())
            VStack(alignment: .leading, spacing: 2) {
                Text(highlighted(s.text, query))
                    .font(.subheadline.weight(.semibold))
                    .foregroundColor(.primary)
                    .lineLimit(2)
                Text("\(label) · \(s.sub)")
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .lineLimit(1)
            }
            Spacer(minLength: 4)
            Image(systemName: "arrow.up.left")
                .font(.caption.weight(.semibold))
                .foregroundColor(.secondary)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .contentShape(Rectangle())
    }
}

struct SuggestionList: View {
    let items: [Suggestion]
    let query: String
    let onPick: (Suggestion) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("Gợi ý")
                .font(.caption.weight(.semibold))
                .foregroundColor(.secondary)
                .padding(.horizontal, 12)
                .padding(.top, 10)
                .padding(.bottom, 2)
            ForEach(items) { sg in
                Button { onPick(sg) } label: { SuggestionRow(s: sg, query: query) }
                    .buttonStyle(.plain)
                if sg.id != items.last?.id { Divider().padding(.leading, 54) }
            }
        }
        .padding(.bottom, 4)
        .card()
    }
}

struct MatchRows: View {
    let items: [Item]
    let query: String

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Kiện hàng khớp")
                .font(.caption2.weight(.semibold))
                .foregroundColor(Theme.primaryDark)
            ForEach(items.prefix(3)) { it in
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "shippingbox")
                        .font(.caption)
                        .foregroundColor(Theme.primary)
                        .padding(.top, 2)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(highlighted(it.packageNo, query))
                            .font(.caption.weight(.semibold))
                            .foregroundColor(.primary)
                        Text(highlighted(it.desc, query))
                            .font(.caption2)
                            .foregroundColor(.secondary)
                            .lineLimit(2)
                    }
                    Spacer(minLength: 6)
                    Text("\(it.qty) \(it.unit)")
                        .font(.caption2.weight(.bold))
                        .foregroundColor(Theme.primaryDark)
                }
            }
            if items.count > 3 {
                Text("+\(items.count - 3) kiện khớp khác")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
        }
        .padding(10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.primarySoft)
    }
}
