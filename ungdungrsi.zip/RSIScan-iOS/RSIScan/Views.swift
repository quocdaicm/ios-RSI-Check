import SwiftUI
import PhotosUI
import PDFKit
import VisionKit
import UniformTypeIdentifiers

// MARK: - Danh sách phiếu + tìm kiếm

struct DraftSlip: Identifiable {
    let id = UUID()
    var slip: Slip
    var images: [UIImage]
    var warnings: [String] = []
}

func hideKeyboard() {
    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
}

struct HeroHeader: View {
    @Binding var query: String
    let slips: [Slip]
    let onSettings: () -> Void
    @FocusState private var focused: Bool

    var compact: Bool { focused || !query.trimmingCharacters(in: .whitespaces).isEmpty }

    func stat(_ v: Int, _ l: String) -> some View {
        VStack(spacing: 2) {
            Text("\(v)").font(.title3.weight(.bold))
            Text(l).font(.caption2)
        }
        .foregroundColor(.white)
        .frame(maxWidth: .infinity)
        .padding(.vertical, 10)
        .background(Color.white.opacity(0.16))
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            if !compact {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Phiếu xuất hàng").font(.title2.weight(.bold))
                        Text("Quản lý và lưu trữ phiếu RSI").font(.footnote).opacity(0.85)
                    }
                    Spacer()
                    Button(action: onSettings) {
                        Image(systemName: "gearshape.fill")
                            .font(.system(size: 18))
                            .frame(width: 40, height: 40)
                            .background(Color.white.opacity(0.18))
                            .clipShape(Circle())
                    }
                }
                HStack(spacing: 10) {
                    stat(slips.count, "Phiếu")
                    stat(slips.reduce(0) { $0 + $1.items.count }, "Kiện hàng")
                    stat(slips.reduce(0) { $0 + $1.pages.count }, "Ảnh")
                }
            }
            HStack(spacing: 10) {
                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass").foregroundColor(.secondary)
                    TextField("Tìm số RSI, mã kiện, tên hàng", text: $query)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled(true)
                        .submitLabel(.search)
                        .focused($focused)
                        .onSubmit { focused = false }
                    if !query.isEmpty {
                        Button { query = "" } label: {
                            Image(systemName: "xmark.circle.fill").foregroundColor(.secondary)
                        }
                    }
                }
                .foregroundColor(.primary)
                .padding(.horizontal, 12)
                .padding(.vertical, 10)
                .background(Theme.card)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))

                if focused {
                    Button("Xong") { focused = false }
                        .font(.subheadline.weight(.semibold))
                        .foregroundColor(.white)
                }
            }
        }
        .animation(.easeInOut(duration: 0.2), value: compact)
        .foregroundColor(.white)
        .padding(.horizontal, 16)
        .padding(.top, 8)
        .padding(.bottom, 16)
        .background(
            Theme.heroGradient
                .clipShape(BottomRound(r: 26))
                .ignoresSafeArea(edges: .top)
        )
    }
}

struct EmptyState: View {
    let hasData: Bool

    var body: some View {
        VStack(spacing: 10) {
            Image(systemName: hasData ? "magnifyingglass" : "doc.viewfinder")
                .font(.system(size: 40))
                .foregroundColor(Theme.primary)
                .frame(width: 92, height: 92)
                .background(Theme.primarySoft)
                .clipShape(Circle())
            Text(hasData ? "Không tìm thấy phiếu" : "Chưa có phiếu nào").font(.headline)
            Text(hasData ? "Thử số RSI hoặc mã kiện khác." : "Bấm nút camera để quét phiếu đầu tiên.")
                .font(.footnote)
                .foregroundColor(.secondary)
        }
    }
}

struct SlipCard: View {
    @EnvironmentObject var store: Store
    let slip: Slip
    var matches: [Item] = []
    var query: String = ""

    var dateChip: some View {
        Chip(icon: "calendar", text: slip.requestDate.isEmpty ? "-" : slip.requestDate,
             fg: .secondary, bg: Color(.tertiarySystemFill))
    }

    var itemsChip: some View {
        Chip(icon: "shippingbox", text: "\(slip.items.count) kiện",
             fg: Theme.primaryDark, bg: Theme.primarySoft)
    }

    var photoChip: some View {
        Chip(icon: "photo", text: "\(slip.pages.count)",
             fg: Theme.amberText, bg: Theme.amberSoft)
    }

    var infoLine: String {
        var parts = [formatBytes(store.slipBytes(slip))]
        if let d = slip.items.first?.desc, !d.isEmpty { parts.append(d) }
        return parts.joined(separator: " · ")
    }

    var body: some View {
        VStack(spacing: 0) {
        HStack(spacing: 0) {
            Rectangle().fill(Theme.primary).frame(width: 5)
            HStack(spacing: 12) {
                Group {
                    if let n = slip.pages.first, let img = store.thumb(n) {
                        Image(uiImage: img).resizable().scaledToFill()
                    } else {
                        Theme.primarySoft
                    }
                }
                .frame(width: 58, height: 72)
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))

                VStack(alignment: .leading, spacing: 6) {
                    Text(slip.rsiNo.isEmpty ? "(chưa có số)" : slip.rsiNo)
                        .font(.subheadline.weight(.bold))
                        .foregroundColor(.primary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                    ViewThatFits(in: .horizontal) {
                        HStack(spacing: 6) { dateChip; itemsChip; photoChip }
                        VStack(alignment: .leading, spacing: 4) {
                            HStack(spacing: 6) { dateChip; itemsChip }
                            photoChip
                        }
                        VStack(alignment: .leading, spacing: 4) { dateChip; itemsChip; photoChip }
                    }
                    Text(infoLine)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.right")
                    .font(.footnote.weight(.semibold))
                    .foregroundColor(.secondary)
            }
            .padding(12)
        }
        if !matches.isEmpty { MatchRows(items: matches, query: query) }
        }
        .card()
    }
}

struct SlipListView: View {
    @EnvironmentObject var store: Store
    @State private var query = ""
    @State private var showScanner = false
    @State private var picked: [PhotosPickerItem] = []
    @State private var processing = false
    @State private var draft: DraftSlip? = nil
    @State private var showSettings = false
    @State private var showSuggest = true
    @State private var skipNext = false
    @State private var keyboardUp = false

    var hits: [SearchHit] { store.hits(query) }
    var suggestions: [Suggestion] { showSuggest ? store.suggestions(query) : [] }

    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottomTrailing) {
                Theme.bg.ignoresSafeArea()
                VStack(spacing: 0) {
                    HeroHeader(query: $query, slips: store.slips) { showSettings = true }
                    ScrollView {
                        VStack(spacing: 12) {
                            if !suggestions.isEmpty {
                                SuggestionList(items: suggestions, query: query) { sg in
                                    showSuggest = false
                                    skipNext = (query != sg.text)
                                    query = sg.text
                                    hideKeyboard()
                                }
                            }
                            if hits.isEmpty {
                                EmptyState(hasData: !store.slips.isEmpty).padding(.top, 50)
                            } else {
                                if !query.trimmingCharacters(in: .whitespaces).isEmpty {
                                    Text("\(hits.count) phiếu khớp")
                                        .font(.footnote.weight(.semibold))
                                        .foregroundColor(.secondary)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                }
                                LazyVStack(spacing: 10) {
                                    ForEach(hits) { h in
                                        NavigationLink {
                                            SlipDetailView(id: h.slip.id)
                                        } label: {
                                            SlipCard(slip: h.slip, matches: h.items, query: query)
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.top, 14)
                        .padding(.bottom, keyboardUp ? 24 : 130)
                    }
                    .scrollDismissesKeyboard(.immediately)
                }

                VStack(spacing: 12) {
                    PhotosPicker(selection: $picked, maxSelectionCount: Store.maxPages, matching: .images) {
                        Image(systemName: "photo.on.rectangle")
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundColor(Theme.primaryDark)
                            .frame(width: 52, height: 52)
                            .background(Theme.card)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Theme.line, lineWidth: 1))
                    }
                    Button {
                        showScanner = true
                    } label: {
                        Image(systemName: "camera.viewfinder")
                            .font(.system(size: 28, weight: .semibold))
                            .foregroundColor(.white)
                            .frame(width: 66, height: 66)
                            .background(Theme.heroGradient)
                            .clipShape(Circle())
                    }
                    .disabled(!VNDocumentCameraViewController.isSupported)
                    .opacity(VNDocumentCameraViewController.isSupported ? 1 : 0.4)
                }
                .padding(.trailing, 20)
                .padding(.bottom, 24)
                .opacity(keyboardUp ? 0 : 1)
                .allowsHitTesting(!keyboardUp)
                .animation(.easeInOut(duration: 0.15), value: keyboardUp)
            }
            .toolbar(.hidden, for: .navigationBar)
            .onReceive(NotificationCenter.default.publisher(for: UIResponder.keyboardWillShowNotification)) { _ in keyboardUp = true }
            .onReceive(NotificationCenter.default.publisher(for: UIResponder.keyboardWillHideNotification)) { _ in keyboardUp = false }
            .onChange(of: query) { _ in
                if skipNext { skipNext = false; showSuggest = false } else { showSuggest = true }
            }
            .fullScreenCover(isPresented: $showScanner) {
                DocumentScanner(
                    onFinish: { imgs in
                        showScanner = false
                        handle(imgs, flatten: false)
                    },
                    onCancel: { showScanner = false }
                )
                .ignoresSafeArea()
            }
            .onChange(of: picked) { items in
                guard !items.isEmpty else { return }
                Task {
                    var imgs: [UIImage] = []
                    for it in items {
                        if let d = try? await it.loadTransferable(type: Data.self),
                           let img = UIImage(data: d) { imgs.append(img) }
                    }
                    picked = []
                    handle(imgs, flatten: true)
                }
            }
            .sheet(isPresented: $showSettings) { SettingsView() }
            .sheet(item: $draft) { d in
                ReviewView(initial: d.slip, newImages: d.images, isNew: true, warnings: d.warnings)
            }
            .overlay {
                if processing {
                    ZStack {
                        Color.black.opacity(0.35).ignoresSafeArea()
                        VStack(spacing: 12) {
                            ProgressView()
                            Text("Đang đọc phiếu...").font(.footnote)
                        }
                        .padding(24)
                        .background(.regularMaterial)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                }
            }
        }
    }

    func handle(_ images: [UIImage], flatten: Bool) {
        guard !images.isEmpty else { return }
        let images = Array(images.prefix(Store.maxPages))
        processing = true
        Task.detached(priority: .userInitiated) {
            var outImgs: [UIImage] = []
            var parsed: [Parsed] = []
            for im in images {
                let (b, p) = Pipeline.process(im, flatten: flatten)
                outImgs.append(b)
                parsed.append(p)
            }
            let m = Pipeline.merge(parsed)
            let finalImgs = outImgs
            await MainActor.run {
                var s = Slip()
                s.rsiNo = m.rsiNo
                s.requestDate = m.date
                s.project = m.project
                s.items = m.items
                processing = false
                draft = DraftSlip(slip: s, images: finalImgs, warnings: m.warnings)
            }
        }
    }
}

struct SlipRow: View {
    @EnvironmentObject var store: Store
    let slip: Slip

    var body: some View {
        HStack(spacing: 12) {
            Group {
                if let n = slip.pages.first, let img = store.thumb(n) {
                    Image(uiImage: img).resizable().scaledToFill()
                } else {
                    Color(.secondarySystemBackground)
                }
            }
            .frame(width: 56, height: 56)
            .clipShape(RoundedRectangle(cornerRadius: 8))

            VStack(alignment: .leading, spacing: 3) {
                Text(slip.rsiNo.isEmpty ? "(chưa có số)" : slip.rsiNo).bold()
                Text("\(slip.requestDate.isEmpty ? "-" : slip.requestDate) · \(slip.items.count) dòng · \(slip.pages.count) trang")
                    .font(.caption)
                    .foregroundColor(.secondary)
                if let first = slip.items.first {
                    Text(first.desc)
                        .font(.caption2)
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                }
            }
        }
        .padding(.vertical, 2)
    }
}

// MARK: - Xác nhận / sửa kết quả đọc

struct ReviewView: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss

    @State var slip: Slip
    @State private var newImages: [UIImage]
    @State private var removedPages: [String] = []
    @State private var picked: [PhotosPickerItem] = []
    @State private var showScanner = false
    @State private var busy = false
    @State private var notice: String? = nil
    @State private var didStart = false
    @State private var confirmReread = false
    @State private var preview: PreviewImage? = nil
    @State private var showDebug = false
    @State private var debugText = ""
    @AppStorage(Compression.key) private var compressionRaw = Compression.balanced.rawValue
    let isNew: Bool
    let startScan: Bool

    init(initial: Slip, newImages: [UIImage], isNew: Bool, startScan: Bool = false, warnings: [String] = []) {
        _slip = State(initialValue: initial)
        _notice = State(initialValue: warnings.isEmpty ? nil : warnings.joined(separator: "\n"))
        _newImages = State(initialValue: newImages)
        self.isNew = isNew
        self.startScan = startScan
    }

    var duplicate: Bool { store.exists(rsiNo: slip.rsiNo, except: slip.id) }
    var totalPages: Int { slip.pages.count + newImages.count }
    var remaining: Int { max(0, Store.maxPages - totalPages) }

    func thumbBox(_ img: UIImage, full: UIImage? = nil, onDelete: @escaping () -> Void) -> some View {
        ZStack(alignment: .topTrailing) {
            Image(uiImage: img).resizable().scaledToFit().frame(height: 120)
                .contentShape(Rectangle())
                .onTapGesture { preview = PreviewImage(image: full ?? img) }
            Button(action: onDelete) {
                Image(systemName: "xmark.circle.fill")
                    .foregroundColor(.white)
                    .background(Circle().fill(Color.black.opacity(0.55)))
                    .font(.title3)
            }
            .buttonStyle(.plain)
            .padding(3)
        }
    }

    func absorb(_ p: Parsed) {
        if slip.rsiNo.isEmpty { slip.rsiNo = p.rsiNo }
        else if !p.rsiNo.isEmpty && p.rsiNo.uppercased() != slip.rsiNo.uppercased() {
            notice = "Ảnh vừa thêm có số RSI khác: \(p.rsiNo). Kiểm tra lại xem có đúng phiếu không."
        }
        if slip.requestDate.isEmpty { slip.requestDate = p.date }
        if slip.project.isEmpty { slip.project = p.project }
        slip.fillHand(p)
        if !p.warnings.isEmpty { notice = p.warnings.joined(separator: "\n") }
        for it in p.items where !slip.items.contains(where: { $0.sameAs(it) }) {
            slip.items.append(it)
        }
    }

    func addImages(_ imgs: [UIImage], flatten: Bool) {
        let take = Array(imgs.prefix(remaining))
        guard !take.isEmpty else { return }
        busy = true
        notice = nil
        Task.detached(priority: .userInitiated) {
            var out: [(UIImage, Parsed)] = []
            for im in take { out.append(Pipeline.process(im, flatten: flatten)) }
            let results = out
            await MainActor.run {
                for (img, p) in results {
                    newImages.append(img)
                    absorb(p)
                }
                busy = false
            }
        }
    }

    func reread() {
        let st = store
        let names = slip.pages
        let extra = newImages
        busy = true
        notice = nil
        Task.detached(priority: .userInitiated) {
            var parsed: [Parsed] = []
            for n in names {
                if let im = st.image(n) { parsed.append(Pipeline.process(im, flatten: false).1) }
            }
            for im in extra { parsed.append(Pipeline.process(im, flatten: false).1) }
            let m = Pipeline.merge(parsed)
            await MainActor.run {
                slip.items = m.items
                if slip.requestDate.isEmpty { slip.requestDate = m.date }
                if slip.project.isEmpty { slip.project = m.project }
                if slip.rsiNo.trimmingCharacters(in: .whitespaces).isEmpty { slip.rsiNo = m.rsiNo }
                slip.fillHand(m)
                notice = "Đã đọc lại \(m.items.count) dòng kiện hàng. Hãy kiểm tra số lượng trước khi lưu."
                    + (m.warnings.isEmpty ? "" : "\n" + m.warnings.joined(separator: "\n"))
                busy = false
            }
        }
    }

    func handCount() -> Int {
        [slip.receivedByText, slip.receivedDateText, slip.requestedByText, slip.checkedByText,
         slip.confirmedByText, slip.approvedByText, slip.remark, slip.rsiNo]
            .filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }.count
            + slip.items.filter { !$0.actualQtyText.isEmpty }.count
    }

    /// Đọc lại ảnh nhưng chỉ điền các ô còn trống (không đụng vào danh sách kiện hàng, không ghi đè chữ đã nhập)
    func readHand() {
        let st = store
        let names = slip.pages
        let extra = newImages
        busy = true
        notice = nil
        Task.detached(priority: .userInitiated) {
            var parsed: [Parsed] = []
            for n in names {
                if let im = st.image(n) { parsed.append(Pipeline.process(im, flatten: false).1) }
            }
            for im in extra { parsed.append(Pipeline.process(im, flatten: false).1) }
            let m = Pipeline.merge(parsed)
            await MainActor.run {
                let before = handCount()
                if slip.rsiNo.trimmingCharacters(in: .whitespaces).isEmpty { slip.rsiNo = m.rsiNo }
                slip.fillHand(m)
                for i in slip.items.indices where slip.items[i].actualQtyText.isEmpty {
                    let k = slip.items[i].packageNo.uppercased()
                    if let f = m.items.first(where: { $0.packageNo.uppercased() == k && !$0.actualQtyText.isEmpty }) {
                        slip.items[i].actualQtyText = f.actualQtyText
                    }
                }
                let added = handCount() - before
                notice = added > 0
                    ? "Đã điền thêm \(added) mục từ chữ viết tay. Hãy kiểm tra lại trước khi lưu."
                    : "Không đọc thêm được chữ viết tay nào. Bấm \"Xem kết quả OCR\" để xem máy đọc được gì."
                busy = false
            }
        }
    }

    func debugOCR() {
        let st = store
        let names = slip.pages
        let extra = newImages
        busy = true
        Task.detached(priority: .userInitiated) {
            func r2(_ v: CGFloat) -> String { String(format: "%.2f", Double(v)) }
            var imgs: [UIImage] = []
            for n in names { if let im = st.image(n) { imgs.append(im) } }
            imgs.append(contentsOf: extra)
            var out = ""
            for (i, im) in imgs.enumerated() {
                let base = im.normalized()
                let lines = OCR.lines(base).sorted { $0.box.midY > $1.box.midY }
                let p = SlipParser.parse(lines)
                out += "== Ảnh \(i + 1) (\(Int(base.size.width))x\(Int(base.size.height))) ==\n"
                out += "RSI=\(p.rsiNo) | nhận=\(p.receivedBy) \(p.receivedDate) | YC=\(p.requestedBy) | KT=\(p.checkedBy) | XN=\(p.confirmedBy) | DUYỆT=\(p.approvedBy) | GC=\(p.remark)\n"
                for l in lines {
                    out += "x\(r2(l.box.midX)) y\(r2(l.box.midY)) c\(r2(CGFloat(l.conf)))  \(l.text)\n"
                }
                out += "\n"
            }
            let result = out.isEmpty ? "Không có ảnh để đọc." : out
            await MainActor.run {
                debugText = result
                showDebug = true
                busy = false
            }
        }
    }

    func mergeInto(_ ex: Slip) {
        var t = ex
        for img in newImages {
            if let n = store.saveImage(img) { t.pages.append(n) }
        }
        for it in slip.items where !t.items.contains(where: { $0.sameAs(it) }) { t.items.append(it) }
        if t.requestDate.isEmpty { t.requestDate = slip.requestDate }
        if t.project.isEmpty { t.project = slip.project }
        if t.remark.isEmpty { t.remark = slip.remark }
        t.fillHand(from: slip)
        store.upsert(t)
        dismiss()
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Ảnh phiếu (\(totalPages)/\(Store.maxPages))") {
                    if totalPages > 0 {
                        ScrollView(.horizontal) {
                            HStack {
                                ForEach(Array(slip.pages.enumerated()), id: \.element) { _, n in
                                    if let img = store.thumb(n) {
                                        thumbBox(img, full: store.image(n)) {
                                            slip.pages.removeAll { $0 == n }
                                            removedPages.append(n)
                                        }
                                    }
                                }
                                ForEach(Array(newImages.enumerated()), id: \.offset) { i, img in
                                    thumbBox(img) { newImages.remove(at: i) }
                                }
                            }
                        }
                        .fullScreenCover(item: $preview) { p in
                            PageViewer(image: p.image)
                        }
                    }
                    PhotosPicker(selection: $picked, maxSelectionCount: max(remaining, 1), matching: .images) {
                        Label("Thêm ảnh từ thư viện", systemImage: "photo.on.rectangle")
                    }
                    .disabled(remaining == 0)
                    Button {
                        showScanner = true
                    } label: {
                        Label("Quét thêm bằng camera", systemImage: "camera.viewfinder")
                    }
                    .disabled(remaining == 0 || !VNDocumentCameraViewController.isSupported)
                    if totalPages > 0 {
                        Button { confirmReread = true } label: {
                            Label("Đọc lại kiện hàng từ ảnh", systemImage: "arrow.triangle.2.circlepath")
                        }
                        .disabled(busy)
                        Button { readHand() } label: {
                            Label("Điền chữ viết tay từ ảnh (chỉ ô còn trống)", systemImage: "signature")
                        }
                        .disabled(busy)
                        Button { debugOCR() } label: {
                            Label("Xem kết quả OCR (gỡ lỗi)", systemImage: "text.viewfinder")
                        }
                        .disabled(busy)
                    }
                    if remaining == 0 {
                        Text("Đã đủ \(Store.maxPages) ảnh. Xoá bớt để thêm ảnh khác.")
                            .font(.caption).foregroundColor(.orange)
                    } else {
                        Text("Còn thêm được \(remaining) ảnh. Ảnh thêm vào sẽ được đọc và bổ sung kiện hàng còn thiếu.")
                            .font(.caption).foregroundColor(.secondary)
                    }
                    if let n = notice {
                        Text(n).font(.caption).foregroundColor(.orange)
                    }
                    if busy { ProgressView() }
                    Picker("Mức nén ảnh", selection: $compressionRaw) {
                        ForEach(Compression.allCases) { c in Text(c.title).tag(c.rawValue) }
                    }
                    Text((Compression(rawValue: compressionRaw) ?? .balanced).detail)
                        .font(.caption).foregroundColor(.secondary)
                }

                if isNew && slip.rsiNo.trimmingCharacters(in: .whitespaces).isEmpty && !store.slips.isEmpty {
                    Section("Tờ này thuộc phiếu nào?") {
                        Text("Không thấy số RSI trên tờ này (tờ tiếp theo thường không in). Chọn phiếu để gắn vào, hoặc nhập số RSI bên dưới để tạo phiếu mới.")
                            .font(.footnote)
                        ForEach(Array(store.search("").prefix(5))) { ex in
                            Button { mergeInto(ex) } label: { SlipRow(slip: ex) }
                                .buttonStyle(.plain)
                                .disabled(ex.pages.count + newImages.count > Store.maxPages || busy)
                        }
                        NavigationLink("Chọn phiếu khác") {
                            SlipPicker { mergeInto($0) }
                        }
                    }
                }

                if isNew, let ex = store.existing(rsiNo: slip.rsiNo, except: slip.id) {
                    Section("Số RSI này đã có") {
                        Text("Đã có phiếu \(ex.rsiNo) với \(ex.pages.count) ảnh, \(ex.items.count) dòng. Nếu đây là tờ tiếp theo của cùng phiếu, hãy gộp vào.")
                            .font(.footnote)
                        Button("Gộp vào phiếu đã có") { mergeInto(ex) }
                            .disabled(ex.pages.count + newImages.count > Store.maxPages || busy)
                        if ex.pages.count + newImages.count > Store.maxPages {
                            Text("Gộp sẽ vượt \(Store.maxPages) ảnh, hãy xoá bớt ảnh trước.")
                                .font(.caption).foregroundColor(.orange)
                        }
                    }
                }

                Section("Thông tin phiếu") {
                    TextField("Số RSI (vd OM4-RSI-DE-EL-0012)", text: $slip.rsiNo)
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled(true)
                    if duplicate {
                        Text("Đã có phiếu khác cùng số RSI này").font(.caption).foregroundColor(.orange)
                    }
                    if slip.rsiNo.trimmingCharacters(in: .whitespaces).isEmpty {
                        Text("Chưa đọc được số RSI, hãy nhập tay").font(.caption).foregroundColor(.orange)
                    }
                    TextField("Ngày yêu cầu", text: $slip.requestDate)
                    TextField("Dự án", text: $slip.project)
                    TextField("Người nhận (chữ viết tay)", text: $slip.receivedByText)
                    TextField("Ngày nhận (chữ viết tay)", text: $slip.receivedDateText)
                    TextField("Người yêu cầu (Requested By)", text: $slip.requestedByText)
                    TextField("Người kiểm tra (Checked By)", text: $slip.checkedByText)
                    TextField("Người xác nhận (Confirmed By)", text: $slip.confirmedByText)
                    TextField("Người duyệt (Approved By)", text: $slip.approvedByText)
                    TextField("Ghi chú (Remark)", text: $slip.remark, axis: .vertical)
                }

                Section("Kiện hàng (\(slip.items.count) dòng)") {
                    ForEach($slip.items) { $it in
                        NavigationLink {
                            ItemEditView(item: $it)
                        } label: {
                            VStack(alignment: .leading, spacing: 2) {
                                HStack {
                                    Text(it.packageNo.isEmpty ? "(chưa có mã)" : it.packageNo).bold()
                                    Spacer()
                                    Text(it.qtyLabel).foregroundColor(.secondary)
                                }
                                Text(it.desc + (it.tag.isEmpty ? "" : " · " + it.tag))
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                    .lineLimit(2)
                            }
                        }
                    }
                    .onDelete { slip.items.remove(atOffsets: $0) }
                    Button("Thêm dòng") { slip.items.append(Item()) }
                }
            }
            .scrollContentBackground(.hidden)
            .background(Theme.bg)
            .navigationTitle(isNew ? "Xác nhận phiếu" : "Sửa phiếu")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Huỷ") { dismiss() }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Lưu") { save() }
                        .disabled(slip.rsiNo.trimmingCharacters(in: .whitespaces).isEmpty || busy)
                }
            }
            .onAppear {
                if startScan && !didStart {
                    didStart = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { showScanner = true }
                }
            }
            .onChange(of: picked) { items in
                guard !items.isEmpty else { return }
                Task {
                    var imgs: [UIImage] = []
                    for it in items {
                        if let d = try? await it.loadTransferable(type: Data.self),
                           let img = UIImage(data: d) { imgs.append(img) }
                    }
                    picked = []
                    addImages(imgs, flatten: true)
                }
            }
            .fullScreenCover(isPresented: $showScanner) {
                DocumentScanner(
                    onFinish: { imgs in
                        showScanner = false
                        addImages(imgs, flatten: false)
                    },
                    onCancel: { showScanner = false }
                )
                .ignoresSafeArea()
            }
            .sheet(isPresented: $showDebug) { DebugOCRView(text: debugText) }
            .confirmationDialog("Đọc lại sẽ thay toàn bộ danh sách kiện hàng hiện tại bằng kết quả đọc từ ảnh. Tiếp tục?",
                                isPresented: $confirmReread, titleVisibility: .visible) {
                Button("Đọc lại", role: .destructive) { reread() }
            }
        }
    }

    func save() {
        var s = slip
        s.rsiNo = s.rsiNo.trimmingCharacters(in: .whitespaces).uppercased()
        for n in removedPages { store.removeImageFile(n) }
        for img in newImages.prefix(max(0, Store.maxPages - s.pages.count)) {
            if let n = store.saveImage(img) { s.pages.append(n) }
        }
        store.upsert(s)
        dismiss()
    }
}

struct ItemEditView: View {
    @Binding var item: Item

    var body: some View {
        Form {
            TextField("Package No", text: $item.packageNo)
                .textInputAutocapitalization(.characters)
                .autocorrectionDisabled(true)
            TextField("Mô tả hàng", text: $item.desc, axis: .vertical)
            TextField("Tag No / Serial No", text: $item.tag)
            TextField("Đơn vị", text: $item.unit)
                .textInputAutocapitalization(.characters)
            TextField("Số lượng", text: $item.qty)
                .keyboardType(.decimalPad)
            TextField("Số lượng thực nhận (viết tay)", text: $item.actualQtyText)
                .keyboardType(.decimalPad)
        }
        .scrollContentBackground(.hidden)
        .background(Theme.bg)
        .navigationTitle("Dòng hàng")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Chi tiết phiếu

struct SlipDetailView: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    let id: UUID

    @State private var pdfURL: URL? = nil
    @State private var editing: Slip? = nil
    @State private var autoScan = false
    @State private var viewing: String? = nil
    @State private var confirmDelete = false
    @State private var expandNote = false

    var slip: Slip? { store.slips.first { $0.id == id } }

    func makePDF(_ s: Slip) -> URL? {
        let doc = PDFDocument()
        for n in s.pages {
            if let img = store.image(n), let page = PDFPage(image: img) {
                doc.insert(page, at: doc.pageCount)
            }
        }
        guard doc.pageCount > 0 else { return nil }
        let safe = (s.rsiNo.isEmpty ? "phieu" : s.rsiNo).replacingOccurrences(of: "/", with: "-")
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("\(safe).pdf")
        doc.write(to: url)
        return url
    }

    func header(_ s: Slip) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(s.rsiNo.isEmpty ? "(chưa có số)" : s.rsiNo).font(.title3.weight(.bold))
            HStack(spacing: 6) {
                Chip(icon: "calendar", text: s.requestDate.isEmpty ? "-" : s.requestDate,
                     fg: .white, bg: Color.white.opacity(0.2))
                Chip(icon: "shippingbox", text: "\(s.items.count) kiện",
                     fg: .white, bg: Color.white.opacity(0.2))
                Chip(icon: "photo", text: "\(s.pages.count) ảnh",
                     fg: .white, bg: Color.white.opacity(0.2))
            }
            if !s.project.isEmpty { Text(s.project).font(.footnote).opacity(0.9) }
            Text("Dung lượng ảnh: \(formatBytes(store.slipBytes(s)))").font(.footnote).opacity(0.9)
        }
        .foregroundColor(.white)
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(Theme.heroGradient)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    func infoRow(_ icon: String, _ label: String, _ value: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(Theme.primary)
                .frame(width: 20)
            Text(label)
                .font(.footnote)
                .foregroundColor(.secondary)
                .frame(width: 88, alignment: .leading)
            Text(value)
                .font(.subheadline.weight(.medium))
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.vertical, 9)
    }

    @ViewBuilder
    func signCard(_ s: Slip) -> some View {
        let rows: [(String, String, String)] = [
            ("person.fill.checkmark", "Người nhận", s.receivedByText),
            ("calendar.badge.checkmark", "Ngày nhận", s.receivedDateText),
            ("pencil.line", "Yêu cầu", s.requestedByText),
            ("checkmark.seal", "Kiểm tra", s.checkedByText),
            ("person.badge.shield.checkmark", "Xác nhận", s.confirmedByText),
            ("signature", "Duyệt", s.approvedByText)
        ].filter { !$0.2.trimmingCharacters(in: .whitespaces).isEmpty }
        let note = s.remark.trimmingCharacters(in: .whitespacesAndNewlines)

        if !rows.isEmpty || !note.isEmpty {
            VStack(alignment: .leading, spacing: 6) {
                sectionTitle("Ký nhận & ghi chú")
                VStack(alignment: .leading, spacing: 0) {
                    ForEach(Array(rows.enumerated()), id: \.offset) { i, r in
                        if i > 0 { Divider().overlay(Theme.line) }
                        infoRow(r.0, r.1, r.2)
                    }
                    if !note.isEmpty {
                        if !rows.isEmpty { Divider().overlay(Theme.line) }
                        VStack(alignment: .leading, spacing: 6) {
                            HStack(spacing: 6) {
                                Image(systemName: "note.text")
                                    .font(.system(size: 13, weight: .semibold))
                                    .foregroundColor(Theme.primary)
                                Text("Ghi chú").font(.footnote).foregroundColor(.secondary)
                            }
                            Text(note)
                                .font(.subheadline)
                                .lineLimit(expandNote ? nil : 3)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            if note.count > 90 {
                                Button(expandNote ? "Thu gọn" : "Xem thêm") {
                                    withAnimation(.easeInOut(duration: 0.2)) { expandNote.toggle() }
                                }
                                .font(.caption.weight(.semibold))
                                .foregroundColor(Theme.primaryDark)
                            }
                        }
                        .padding(.vertical, 10)
                    }
                }
                .padding(.horizontal, 14)
                .frame(maxWidth: .infinity, alignment: .leading)
                .card()
            }
        }
    }

    func sectionTitle(_ t: String) -> some View {
        Text(t)
            .font(.footnote.weight(.semibold))
            .foregroundColor(.secondary)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.top, 4)
    }

    func pages(_ s: Slip) -> some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach(Array(s.pages.enumerated()), id: \.element) { i, n in
                    if let img = store.thumb(n) {
                        ZStack(alignment: .bottomTrailing) {
                            Image(uiImage: img).resizable().scaledToFit()
                                .frame(height: 140)
                            Text("\(i + 1) · \(formatBytes(store.fileSize(n)))")
                                .font(.caption2.weight(.bold))
                                .foregroundColor(.white)
                                .padding(.horizontal, 7)
                                .padding(.vertical, 3)
                                .background(Color.black.opacity(0.55))
                                .clipShape(Capsule())
                                .padding(6)
                        }
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(Theme.line, lineWidth: 1))
                        .onTapGesture { viewing = n }
                    }
                }
            }
        }
    }

    func actions(_ s: Slip) -> some View {
        HStack(spacing: 10) {
            Button {
                autoScan = true
                editing = s
            } label: {
                Label("Quét tờ tiếp theo", systemImage: "camera.viewfinder")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(Theme.heroGradient)
                    .foregroundColor(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            .disabled(s.pages.count >= Store.maxPages || !VNDocumentCameraViewController.isSupported)
            .opacity(s.pages.count >= Store.maxPages ? 0.4 : 1)

            if let u = pdfURL {
                ShareLink(item: u) {
                    Label("PDF", systemImage: "square.and.arrow.up")
                        .font(.subheadline.weight(.semibold))
                        .padding(.horizontal, 18)
                        .padding(.vertical, 12)
                        .background(Theme.primarySoft)
                        .foregroundColor(Theme.primaryDark)
                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                }
            }
        }
    }

    func itemBody(_ it: Item, _ n: Int) -> some View {
        HStack(alignment: .top, spacing: 10) {
            VStack(alignment: .leading, spacing: 5) {
                Text(it.packageNo).font(.subheadline.weight(.semibold))
                Text(it.desc).font(.caption).foregroundColor(.secondary)
                if !it.tag.isEmpty {
                    Chip(icon: "tag", text: it.tag, fg: Theme.amberText, bg: Theme.amberSoft)
                }
                if n > 1 {
                    Chip(icon: "clock.arrow.circlepath", text: "Xuất \(n) lần, xem lịch sử",
                         fg: Theme.primaryDark, bg: Theme.primarySoft)
                }
            }
            Spacer(minLength: 8)
            VStack(alignment: .trailing, spacing: 4) {
                Text("\(it.qty) \(it.unit)")
                    .font(.footnote.weight(.bold))
                    .lineLimit(1)
                    .fixedSize()
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(Theme.primarySoft)
                    .foregroundColor(Theme.primaryDark)
                    .clipShape(Capsule())
                if let a = it.actualQty, !a.isEmpty {
                    HStack(spacing: 3) {
                        Image(systemName: "checkmark.circle.fill").font(.system(size: 10))
                        Text("Nhận \(a)").font(.caption2.weight(.semibold))
                    }
                    .foregroundColor(Theme.primary)
                    .fixedSize()
                }
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .card()
    }

    @ViewBuilder
    func itemCard(_ it: Item) -> some View {
        if it.packageNo.trimmingCharacters(in: .whitespaces).isEmpty {
            itemBody(it, 0)
        } else {
            NavigationLink {
                PackageHistoryView(item: it)
            } label: {
                itemBody(it, store.history(for: it).count)
            }
            .buttonStyle(.plain)
        }
    }

    var body: some View {
        if let s = slip {
            ScrollView {
                VStack(spacing: 14) {
                    header(s)
                    signCard(s)
                    if !s.pages.isEmpty {
                        sectionTitle("Ảnh phiếu · \(s.pages.count)/\(Store.maxPages), chạm để phóng to")
                        pages(s)
                    }
                    actions(s)
                    sectionTitle("Kiện hàng · \(s.items.count) dòng")
                    if s.items.isEmpty {
                        Text("Chưa có kiện hàng. Bấm Sửa để thêm.")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                    }
                    ForEach(s.items) { it in itemCard(it) }
                    Button(role: .destructive) { confirmDelete = true } label: {
                        Label("Xoá phiếu", systemImage: "trash")
                            .font(.subheadline.weight(.semibold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .background(Theme.redSoft)
                            .foregroundColor(Theme.red)
                            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                    }
                    .padding(.top, 8)
                }
                .padding(16)
            }
            .background(Theme.bg.ignoresSafeArea())
            .navigationTitle(s.rsiNo.isEmpty ? "Phiếu" : s.rsiNo)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Sửa") { autoScan = false; editing = s }
                }
            }
            .onAppear { pdfURL = makePDF(s) }
            .onChange(of: s) { new in pdfURL = makePDF(new) }
            .sheet(item: $editing) { e in
                ReviewView(initial: e, newImages: [], isNew: false, startScan: autoScan)
            }
            .fullScreenCover(item: Binding(
                get: { viewing.map { PageRef(name: $0) } },
                set: { viewing = $0?.name })
            ) { ref in
                PageViewer(image: store.image(ref.name))
            }
            .confirmationDialog("Xoá phiếu này và ảnh scan?", isPresented: $confirmDelete,
                                titleVisibility: .visible) {
                Button("Xoá", role: .destructive) {
                    store.delete(s)
                    dismiss()
                }
            }
        } else {
            Text("Không tìm thấy")
        }
    }
}

struct DebugOCRView: View {
    @Environment(\.dismiss) var dismiss
    let text: String

    var body: some View {
        NavigationStack {
            ScrollView {
                Text(text)
                    .font(.system(size: 11, design: .monospaced))
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
            }
            .navigationTitle("Kết quả OCR")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) { Button("Đóng") { dismiss() } }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Sao chép") { UIPasteboard.general.string = text }
                }
            }
        }
    }
}

struct PreviewImage: Identifiable {
    let id = UUID()
    let image: UIImage
}

struct PageRef: Identifiable {
    let name: String
    var id: String { name }
}

struct PageViewer: View {
    @Environment(\.dismiss) var dismiss
    let image: UIImage?
    @State private var scale: CGFloat = 1
    @State private var base: CGFloat = 1

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Color.black.ignoresSafeArea()
            if let img = image {
                GeometryReader { geo in
                    ScrollView([.horizontal, .vertical], showsIndicators: false) {
                        Image(uiImage: img)
                            .resizable()
                            .scaledToFit()
                            .frame(width: geo.size.width * scale, height: geo.size.height * scale)
                    }
                    .simultaneousGesture(
                        MagnificationGesture()
                            .onChanged { scale = max(1, min(base * $0, 6)) }
                            .onEnded { _ in base = scale }
                    )
                }
            }
            Button {
                dismiss()
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.title)
                    .foregroundColor(.white)
                    .padding()
            }
        }
    }
}


struct SettingsView: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) var dismiss
    @AppStorage(Compression.key) private var raw = Compression.balanced.rawValue
    @State private var compressOpen = false
    @State private var exporting = false
    @State private var exportURL: URL? = nil
    @State private var exportFailed = false
    @State private var showImporter = false
    @State private var importing = false
    @State private var importMessage: String? = nil
    @State private var folderMode = false
    @State private var backupMessage: String? = nil
    @State private var backingUp = false
    @AppStorage(BackupPrefs.autoKey) private var autoOn = false
    @AppStorage(BackupPrefs.daysKey) private var backupDays = 7
    @AppStorage(BackupPrefs.nameKey) private var folderName = ""
    @AppStorage(BackupPrefs.lastKey) private var lastBackup = 0.0
    @AppStorage(DriveConfig.emailKey) private var driveEmail = ""
    @State private var signingIn = false

    var hasTarget: Bool { !driveEmail.isEmpty || !folderName.isEmpty }

    var lastBackupText: String {
        guard lastBackup > 0 else { return "Chưa sao lưu lần nào" }
        let f = DateFormatter()
        f.dateFormat = "dd/MM/yyyy HH:mm"
        return "Lần gần nhất: " + f.string(from: Date(timeIntervalSince1970: lastBackup))
    }

    var mb: String { formatBytes(store.storageBytes()) }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    DisclosureGroup(isExpanded: $compressOpen) {
                        ForEach(Compression.allCases) { c in
                            Button {
                                raw = c.rawValue
                                withAnimation { compressOpen = false }
                            } label: {
                                HStack(alignment: .top) {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(c.title).foregroundColor(.primary)
                                        Text(c.detail).font(.caption).foregroundColor(.secondary)
                                    }
                                    Spacer()
                                    if raw == c.rawValue {
                                        Image(systemName: "checkmark").foregroundColor(Theme.primary)
                                    }
                                }
                            }
                        }
                        Text("Áp dụng cho ảnh lưu từ giờ trở đi, ảnh đã lưu giữ nguyên.")
                            .font(.caption).foregroundColor(.secondary)
                    } label: {
                        HStack {
                            Text("Mức nén ảnh khi lưu")
                            Spacer()
                            Text((Compression(rawValue: raw) ?? .balanced).title)
                                .foregroundColor(.secondary)
                        }
                    }
                }
                Section("Dung lượng ảnh đã lưu") {
                    HStack {
                        Text("Tổng cộng")
                        Spacer()
                        Text(mb).foregroundColor(.secondary)
                    }
                    HStack {
                        Text("Số ảnh / số phiếu")
                        Spacer()
                        Text("\(store.slips.reduce(0) { $0 + $1.pages.count }) ảnh / \(store.slips.count) phiếu")
                            .foregroundColor(.secondary)
                    }
                }
                Section("Tự động sao lưu") {
                    HStack {
                        Text("Google Drive")
                        Spacer()
                        Text(driveEmail.isEmpty ? "Chưa đăng nhập" : driveEmail)
                            .foregroundColor(.secondary)
                            .lineLimit(1)
                    }
                    if driveEmail.isEmpty {
                        Button {
                            signingIn = true
                            backupMessage = nil
                            Task {
                                var msg: String? = nil
                                do {
                                    try await DriveSignIn.shared.signIn()
                                    msg = "Đã đăng nhập Google Drive."
                                } catch {
                                    msg = error.localizedDescription
                                }
                                await MainActor.run {
                                    backupMessage = msg
                                    signingIn = false
                                }
                            }
                        } label: {
                            Label("Đăng nhập Google Drive", systemImage: "person.crop.circle.badge.plus")
                        }
                        .disabled(signingIn)
                        HStack {
                            Text("Hoặc thư mục trong Tệp")
                            Spacer()
                            Text(folderName.isEmpty ? "Chưa chọn" : folderName)
                                .foregroundColor(.secondary)
                                .lineLimit(1)
                        }
                        Button { folderMode = true; showImporter = true } label: {
                            Label(folderName.isEmpty ? "Chọn thư mục sao lưu" : "Đổi thư mục sao lưu",
                                  systemImage: "folder.badge.plus")
                        }
                    } else {
                        NavigationLink {
                            DriveBackupsView()
                        } label: {
                            Label("Quản lý bản sao lưu trên Drive", systemImage: "externaldrive.badge.icloud")
                        }
                        Button(role: .destructive) {
                            Task { await DriveSignIn.signOut() }
                        } label: {
                            Label("Đăng xuất Google", systemImage: "rectangle.portrait.and.arrow.right")
                        }
                    }
                    Toggle("Tự sao lưu", isOn: $autoOn)
                        .disabled(!hasTarget)
                    if autoOn {
                        Picker("Tần suất", selection: $backupDays) {
                            Text("Hàng ngày").tag(1)
                            Text("Hàng tuần").tag(7)
                            Text("Hàng tháng").tag(30)
                        }
                    }
                    Button {
                        backingUp = true
                        backupMessage = nil
                        let st = store
                        Task.detached(priority: .userInitiated) {
                            let m = await st.backupAny()
                            await MainActor.run {
                                backupMessage = m
                                lastBackup = UserDefaults.standard.double(forKey: BackupPrefs.lastKey)
                                backingUp = false
                            }
                        }
                    } label: {
                        Label("Sao lưu ngay", systemImage: "arrow.clockwise.icloud")
                    }
                    .disabled(!hasTarget || backingUp || store.slips.isEmpty)
                    if backingUp { ProgressView() }
                    if let m = backupMessage {
                        Text(m).font(.caption).foregroundColor(Theme.primaryDark)
                    }
                    Text(lastBackupText).font(.caption).foregroundColor(.secondary)
                }
                Section("Xuất / khôi phục") {
                    Button {
                        exporting = true
                        exportURL = nil
                        exportFailed = false
                        let st = store
                        Task.detached(priority: .userInitiated) {
                            let u = st.exportAll()
                            await MainActor.run {
                                exportURL = u
                                exportFailed = (u == nil)
                                exporting = false
                            }
                        }
                    } label: {
                        Label("Xuất toàn bộ ảnh và thông tin (.zip)", systemImage: "square.and.arrow.up.on.square")
                    }
                    .disabled(exporting || store.slips.isEmpty)
                    if exporting { ProgressView() }
                    if let u = exportURL {
                        ShareLink(item: u) {
                            Label("Lưu / chia sẻ file vừa tạo", systemImage: "square.and.arrow.up")
                        }
                    }
                    if exportFailed {
                        Text("Không tạo được file xuất, hãy thử lại.")
                            .font(.caption).foregroundColor(.orange)
                    }
                    Button { folderMode = false; showImporter = true } label: {
                        Label("Khôi phục từ file zip đã xuất", systemImage: "square.and.arrow.down.on.square")
                    }
                    .disabled(importing)
                    if importing { ProgressView() }
                    if let m = importMessage {
                        Text(m).font(.caption).foregroundColor(Theme.primaryDark)
                    }
                    Text("File zip gồm slips.csv (mở bằng Excel), slips.json và thư mục Anh/ chứa toàn bộ ảnh phiếu, đặt tên theo số RSI.")
                        .font(.caption).foregroundColor(.secondary)
                }
            }
            .fileImporter(isPresented: $showImporter,
                          allowedContentTypes: folderMode ? [.folder] : [.zip]) { result in
                guard case .success(let url) = result else { return }
                if folderMode {
                    if store.saveBackupFolder(url) {
                        backupMessage = "Đã chọn thư mục: \(url.lastPathComponent)"
                    } else {
                        backupMessage = "Không lưu được thư mục này, hãy chọn thư mục khác."
                    }
                    return
                }
                importing = true
                importMessage = nil
                let st = store
                let ids = Set(store.slips.map { $0.id })
                Task.detached(priority: .userInitiated) {
                    let r = st.prepareImport(url: url, existingIDs: ids)
                    await MainActor.run {
                        if !r.slips.isEmpty {
                            st.slips.append(contentsOf: r.slips)
                            st.persist()
                        }
                        importMessage = r.message
                        importing = false
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(Theme.bg)
            .navigationTitle("Cài đặt")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Xong") { dismiss() }
                }
            }
        }
    }
}


struct SlipPicker: View {
    @EnvironmentObject var store: Store
    let onPick: (Slip) -> Void
    @State private var q = ""

    var body: some View {
        List(store.search(q)) { s in
            Button { onPick(s) } label: { SlipRow(slip: s) }
                .buttonStyle(.plain)
        }
        .searchable(text: $q, prompt: "Số RSI, mã kiện, mô tả")
        .navigationTitle("Chọn phiếu")
        .navigationBarTitleDisplayMode(.inline)
    }
}
