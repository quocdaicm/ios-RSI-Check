import SwiftUI

// MARK: - Lọc phiếu theo tháng (thanh chip dưới ô tìm kiếm)

struct MonthKey: Hashable, Comparable, Identifiable {
    let year: Int
    let month: Int
    var id: Int { year * 100 + month }

    static func < (a: MonthKey, b: MonthKey) -> Bool { a.id < b.id }

    init(year: Int, month: Int) { self.year = year; self.month = month }

    init(_ d: Date) {
        let c = Calendar.current.dateComponents([.year, .month], from: d)
        self.init(year: c.year ?? 1970, month: c.month ?? 1)
    }

    static var current: MonthKey { MonthKey(Date()) }

    /// "Tháng 10/2026"
    var title: String { "Tháng \(month)/\(year)" }
    /// Nhãn ngắn cho thanh chip: "10/2026"
    var short: String { "\(month)/\(year)" }
}

extension Slip {
    /// Tháng của phiếu: theo ngày yêu cầu trên phiếu, không đọc được thì theo ngày tạo.
    var monthKey: MonthKey { MonthKey(SlipDate.parse(requestDate) ?? createdAt) }
}

extension Store {
    /// Các tháng có phiếu (mới nhất trước), luôn có tháng hiện tại.
    func monthCounts() -> [(MonthKey, Int)] {
        var counts: [MonthKey: Int] = [MonthKey.current: 0]
        for s in slips { counts[s.monthKey, default: 0] += 1 }
        return counts.map { ($0.key, $0.value) }.sorted { $0.0 > $1.0 }
    }
}

struct MonthFilterBar: View {
    let months: [(MonthKey, Int)]
    let total: Int
    @Binding var selected: MonthKey?

    private func chip(_ title: String, _ count: Int, _ key: MonthKey?) -> some View {
        let on = selected == key
        return Button {
            withAnimation(.easeInOut(duration: 0.15)) { selected = key }
        } label: {
            HStack(spacing: 5) {
                Text(title).font(.system(size: 13, weight: .semibold))
                Text("\(count)")
                    .font(.system(size: 11, weight: .bold))
                    .padding(.horizontal, 6).padding(.vertical, 1)
                    .background(on ? Theme.primary.opacity(0.18) : Color.white.opacity(0.22))
                    .clipShape(Capsule())
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .foregroundColor(on ? Theme.primaryDark : .white)
            .background(on ? Color.white : Color.white.opacity(0.16))
            .clipShape(Capsule())
            .overlay(Capsule().stroke(Color.white.opacity(on ? 0 : 0.25), lineWidth: 1))
            .shadow(color: .black.opacity(on ? 0.15 : 0), radius: 4, y: 2)
        }
        .buttonStyle(.plain)
    }

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(months, id: \.0.id) { m in
                        chip(m.0.short, m.1, m.0).id(m.0.id)
                    }
                    chip("Tất cả", total, nil).id(0)
                }
                .padding(.horizontal, 16)
            }
            .padding(.horizontal, -16)
            // mờ dần hai mép để chip bị cắt không trông như bị kéo lệch
            .mask(
                HStack(spacing: 0) {
                    LinearGradient(colors: [.clear, .black], startPoint: .leading, endPoint: .trailing).frame(width: 16)
                    Color.black
                    LinearGradient(colors: [.black, .clear], startPoint: .leading, endPoint: .trailing).frame(width: 28)
                }
            )
            .onChange(of: selected) { s in
                // chỉ cuộn khi chip được chọn nằm ngoài tầm nhìn, không tự giật khi bấm
                withAnimation(.easeInOut(duration: 0.2)) { proxy.scrollTo(s?.id ?? 0, anchor: nil) }
            }
        }
    }
}
