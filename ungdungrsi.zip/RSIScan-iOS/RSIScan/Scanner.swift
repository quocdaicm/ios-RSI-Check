import SwiftUI
import UIKit
import Vision
import VisionKit
import CoreImage
import CoreImage.CIFilterBuiltins

// MARK: - Camera quét tài liệu (tự dò khung, nắn phẳng, nhiều trang)

struct DocumentScanner: UIViewControllerRepresentable {
    var onFinish: ([UIImage]) -> Void
    var onCancel: () -> Void

    func makeUIViewController(context: Context) -> VNDocumentCameraViewController {
        let vc = VNDocumentCameraViewController()
        vc.delegate = context.coordinator
        return vc
    }

    func updateUIViewController(_ vc: VNDocumentCameraViewController, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    final class Coordinator: NSObject, VNDocumentCameraViewControllerDelegate {
        let parent: DocumentScanner
        init(_ p: DocumentScanner) { parent = p }

        func documentCameraViewController(_ controller: VNDocumentCameraViewController,
                                          didFinishWith scan: VNDocumentCameraScan) {
            var imgs: [UIImage] = []
            for i in 0..<scan.pageCount { imgs.append(scan.imageOfPage(at: i)) }
            parent.onFinish(imgs)
        }

        func documentCameraViewControllerDidCancel(_ controller: VNDocumentCameraViewController) {
            parent.onCancel()
        }

        func documentCameraViewController(_ controller: VNDocumentCameraViewController,
                                          didFailWithError error: Error) {
            parent.onCancel()
        }
    }
}

// MARK: - Xử lý ảnh

extension UIImage {
    /// Vẽ lại cho đúng chiều + giới hạn cạnh dài nhất
    func normalized(maxSide: CGFloat = 2200) -> UIImage {
        let longest = max(size.width, size.height)
        let k = min(1, maxSide / max(longest, 1))
        let newSize = CGSize(width: size.width * k, height: size.height * k)
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        return UIGraphicsImageRenderer(size: newSize, format: fmt).image { _ in
            self.draw(in: CGRect(origin: .zero, size: newSize))
        }
    }

    /// Xoay theo bội số 90 độ (quarterTurns > 0 là xoay thuận chiều kim đồng hồ)
    func rotated(quarterTurns: Int) -> UIImage {
        let t = ((quarterTurns % 4) + 4) % 4
        if t == 0 { return self }
        let swap = (t % 2 == 1)
        let newSize = swap ? CGSize(width: size.height, height: size.width) : size
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        return UIGraphicsImageRenderer(size: newSize, format: fmt).image { ctx in
            let c = ctx.cgContext
            c.translateBy(x: newSize.width / 2, y: newSize.height / 2)
            c.rotate(by: CGFloat(t) * .pi / 2)
            self.draw(in: CGRect(x: -size.width / 2, y: -size.height / 2,
                                 width: size.width, height: size.height))
        }
    }
}

enum Rectifier {
    /// Dò tờ giấy trong ảnh chụp thường và nắn phẳng (giống bản scan).
    /// Nếu không dò được thì trả lại ảnh gốc.
    static func flatten(_ image: UIImage) -> UIImage {
        guard let cg = image.cgImage else { return image }
        let req = VNDetectDocumentSegmentationRequest()
        let handler = VNImageRequestHandler(cgImage: cg, options: [:])
        do { try handler.perform([req]) } catch { return image }
        guard let obs = req.results?.first, obs.confidence > 0.6 else { return image }

        let ci = CIImage(cgImage: cg)
        let w = ci.extent.width, h = ci.extent.height
        func p(_ q: CGPoint) -> CGPoint { CGPoint(x: q.x * w, y: q.y * h) }

        let f = CIFilter.perspectiveCorrection()
        f.inputImage = ci
        f.topLeft = p(obs.topLeft)
        f.topRight = p(obs.topRight)
        f.bottomLeft = p(obs.bottomLeft)
        f.bottomRight = p(obs.bottomRight)
        guard let out = f.outputImage else { return image }
        let ctx = CIContext()
        guard let res = ctx.createCGImage(out, from: out.extent) else { return image }
        return UIImage(cgImage: res)
    }
}

// MARK: - OCR

struct OCRLine {
    var text: String
    var box: CGRect   // toạ độ chuẩn hoá 0...1, gốc ở góc dưới trái (kiểu Vision)
}

enum OCR {
    static func lines(_ image: UIImage) -> [OCRLine] {
        guard let cg = image.cgImage else { return [] }
        let req = VNRecognizeTextRequest()
        req.recognitionLevel = .accurate
        req.usesLanguageCorrection = false
        req.recognitionLanguages = ["en-US"]
        let handler = VNImageRequestHandler(cgImage: cg, options: [:])
        do { try handler.perform([req]) } catch { return [] }
        var out: [OCRLine] = []
        for o in req.results ?? [] {
            if let c = o.topCandidates(1).first {
                out.append(OCRLine(text: c.string, box: o.boundingBox))
            }
        }
        return out
    }
}

// MARK: - Phân tích phiếu

struct Parsed {
    var rsiNo = ""
    var date = ""
    var project = ""
    var items: [Item] = []
}

enum SlipParser {
    static let rsiRe = try! NSRegularExpression(
        pattern: "(?:[A-Z0-9]{2,4}-)?RSI-[A-Z]{1,3}-[A-Z]{1,3}-\\d{3,5}")
    static let pkgRe = try! NSRegularExpression(
        pattern: "[A-Z0-9]{2,4}-[A-Z0-9]{1,4}-[A-Z]{2}-\\d{4}-\\d{3}")
    static let dateRe = try! NSRegularExpression(
        pattern: "\\b\\d{1,2}-[A-Za-z]{3}-\\d{2,4}\\b")
    static let unitRe = try! NSRegularExpression(
        pattern: "^(M|EA|SET|SETS|PC|PCS|KG|LOT|ROLL|NOS|NO|PKG|BOX|CAN|DRUM|TON|M2|M3|L)$",
        options: [.caseInsensitive])
    static let unitQtyRe = try! NSRegularExpression(
        pattern: "^(M|EA|SET|SETS|PC|PCS|KG|LOT|ROLL|NOS|NO|PKG|BOX|CAN|DRUM|TON|M2|M3|L)\\s+(\\d+(?:[.,]\\d+)?)$",
        options: [.caseInsensitive])
    static let numRe = try! NSRegularExpression(pattern: "^\\d+(?:[.,]\\d+)?$")
    static let tagRe = try! NSRegularExpression(pattern: "\\d+\\s*mm", options: [.caseInsensitive])

    // Chữ của dòng tiêu đề bảng / nhãn in sẵn, không phải nội dung hàng hoá
    static let headerContains = ["request date", "tag no", "serial no", "actual h/o",
                                 "received by", "received date", "full name", "with signature",
                                 "description of goods", "package no", "invoice no",
                                 "requestion for", "q'ty", "q\u{2019}ty"]
    static let headerExact: Set<String> = ["unit", "no", "request", "balance", "remark", "remark:",
                                           "signature", "qty", "h/o", "date"]
    static let dateFullRe = try! NSRegularExpression(pattern: "^\\d{1,2}-[A-Za-z]{3}-\\d{2,4}$")

    static func isHeader(_ t: String) -> Bool {
        let c = clean(t)
        let l = c.lowercased()
        if l.isEmpty || headerExact.contains(l) { return true }
        if match(dateFullRe, c) != nil { return true }
        return headerContains.contains { l.contains($0) }
    }

    static func clean(_ s: String) -> String {
        s.replacingOccurrences(of: "–", with: "-")
         .replacingOccurrences(of: "—", with: "-")
         .replacingOccurrences(of: "‐", with: "-")
         .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    /// Dạng dùng để dò mã: viết hoa, bỏ khoảng trắng
    static func idForm(_ s: String) -> String {
        clean(s).uppercased().replacingOccurrences(of: " ", with: "")
    }

    static func match(_ re: NSRegularExpression, _ s: String) -> NSRange? {
        let r = NSRange(s.startIndex..., in: s)
        let m = re.firstMatch(in: s, range: r)
        return m?.range
    }

    static func firstString(_ re: NSRegularExpression, _ s: String) -> String? {
        guard let r = match(re, s), let rr = Range(r, in: s) else { return nil }
        return String(s[rr])
    }

    static func parse(_ lines: [OCRLine]) -> Parsed {
        var out = Parsed()

        // 1. Số RSI
        for l in lines {
            if let s = firstString(rsiRe, idForm(l.text)) { out.rsiNo = s; break }
        }

        // 2. Ngày yêu cầu
        for l in lines {
            if let s = firstString(dateRe, clean(l.text)) { out.date = s; break }
        }

        // 3. Tên dự án
        for l in lines {
            let u = clean(l.text).uppercased()
            if u.contains("PROJECT") && u.count <= 40 { out.project = clean(l.text); break }
        }

        // 4. Bảng kiện hàng: mỗi mã Package No là một dòng
        struct Anchor { var pkg: String; var box: CGRect; var rest: String }
        var anchors: [Anchor] = []
        for l in lines {
            let id = idForm(l.text)
            if let pkg = firstString(pkgRe, id) {
                var rest = clean(l.text)
                // phần chữ còn lại cùng dòng (nếu OCR gộp), bỏ mã đi
                rest = rest.replacingOccurrences(of: pkg, with: "", options: .caseInsensitive)
                anchors.append(Anchor(pkg: pkg, box: l.box,
                                      rest: rest.trimmingCharacters(in: .whitespaces)))
            }
        }
        anchors.sort { $0.box.midY > $1.box.midY }

        // bỏ trùng (cùng mã, gần như cùng độ cao)
        var uniq: [Anchor] = []
        for a in anchors {
            if let last = uniq.last, last.pkg == a.pkg, abs(last.box.midY - a.box.midY) < 0.015 { continue }
            uniq.append(a)
        }

        var gaps: [CGFloat] = []
        if uniq.count > 1 {
            for i in 1..<uniq.count {
                gaps.append(uniq[i - 1].box.midY - uniq[i].box.midY)
            }
        }
        gaps.sort()
        let typical: CGFloat = gaps.isEmpty ? 0.05 : gaps[gaps.count / 2]

        for (i, a) in uniq.enumerated() {
            let up = i > 0 ? (uniq[i - 1].box.midY - a.box.midY) : typical
            let down = i < uniq.count - 1 ? (a.box.midY - uniq[i + 1].box.midY) : typical * 0.9
            let top = a.box.midY + up / 2
            let bottom = a.box.midY - down / 2

            var members: [OCRLine] = []
            if !a.rest.isEmpty && !isHeader(a.rest) {
                members.append(OCRLine(text: a.rest, box: CGRect(x: a.box.maxX, y: a.box.minY,
                                                                 width: 0.001, height: a.box.height)))
            }
            for l in lines {
                if l.box.midY < bottom || l.box.midY > top { continue }
                if l.box.minX < a.box.maxX - 0.01 { continue }
                if firstString(pkgRe, idForm(l.text)) != nil { continue }
                if isHeader(l.text) { continue }
                members.append(l)
            }

            var item = Item()
            item.packageNo = a.pkg

            // đơn vị + số lượng
            var unitBox: CGRect? = nil
            for l in members {
                let t = clean(l.text)
                if let r = match(unitQtyRe, t),
                   let m = unitQtyRe.firstMatch(in: t, range: r),
                   let u = Range(m.range(at: 1), in: t), let q = Range(m.range(at: 2), in: t) {
                    item.unit = String(t[u]).uppercased()
                    item.qty = String(t[q])
                    unitBox = l.box
                    break
                }
            }
            if unitBox == nil {
                for l in members where match(unitRe, clean(l.text)) != nil {
                    item.unit = clean(l.text).uppercased()
                    unitBox = l.box
                    break
                }
                if let ub = unitBox {
                    let right = members
                        .filter { $0.box.minX >= ub.maxX - 0.005 && match(numRe, clean($0.text)) != nil }
                        .sorted { $0.box.minX < $1.box.minX }
                    if let q = right.first { item.qty = clean(q.text) }
                }
            }

            // tag + mô tả
            var descParts: [OCRLine] = []
            for l in members {
                let t = clean(l.text)
                if match(tagRe, t) != nil && (unitBox == nil || l.box.minX < unitBox!.minX) {
                    item.tag = t
                    continue
                }
                if let ub = unitBox, l.box.minX >= ub.minX - 0.005 { continue }
                if match(numRe, t) != nil { continue }
                if match(unitRe, t) != nil { continue }
                descParts.append(l)
            }
            descParts.sort { $0.box.midY > $1.box.midY }
            var textRows: [[OCRLine]] = []
            for l in descParts {
                if var last = textRows.last, let f = last.first,
                   abs(f.box.midY - l.box.midY) < max(f.box.height, l.box.height) * 0.6 {
                    last.append(l)
                    textRows[textRows.count - 1] = last
                } else {
                    textRows.append([l])
                }
            }
            item.desc = textRows
                .map { $0.sorted { $0.box.minX < $1.box.minX }.map { clean($0.text) }.joined(separator: " ") }
                .joined(separator: " ")

            out.items.append(item)
        }
        return out
    }
}

// MARK: - Quy trình: ảnh -> (ảnh đã nắn phẳng, kết quả đọc)

enum Pipeline {
    static func process(_ original: UIImage, flatten: Bool) -> (UIImage, Parsed) {
        var base = original.normalized()
        if flatten { base = Rectifier.flatten(base).normalized() }

        var best = base
        var parsed = SlipParser.parse(OCR.lines(base))

        // Nếu không đọc được gì, thử xoay 90/180/270 (ảnh chụp ngang/dọc lệch)
        if parsed.rsiNo.isEmpty && parsed.items.isEmpty {
            for turns in [1, 3, 2] {
                let r = base.rotated(quarterTurns: turns)
                let p = SlipParser.parse(OCR.lines(r))
                if !p.rsiNo.isEmpty || !p.items.isEmpty {
                    best = r
                    parsed = p
                    break
                }
            }
        }
        return (best, parsed)
    }

    static func merge(_ list: [Parsed]) -> Parsed {
        var out = Parsed()
        for p in list {
            if out.rsiNo.isEmpty { out.rsiNo = p.rsiNo }
            if out.date.isEmpty { out.date = p.date }
            if out.project.isEmpty { out.project = p.project }
            out.items.append(contentsOf: p.items)
        }
        return out
    }
}
