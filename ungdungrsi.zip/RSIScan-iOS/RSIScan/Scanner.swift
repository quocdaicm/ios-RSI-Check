import SwiftUI
import UIKit
import Vision
import VisionKit
import CoreImage
import CoreImage.CIFilterBuiltins

// MARK: - Camera quét tài liệu (tự dò khung, nắn phẳng, nhiều trang)

struct DocumentScanner: UIViewControllerRepresentable {
    var onFinish: ([UIImage]) -> Void
    var onCancel: () -> Void

    func makeUIViewController(context: Context) -> VNDocumentCameraViewController {
        let vc = VNDocumentCameraViewController()
        vc.delegate = context.coordinator
        return vc
    }

    func updateUIViewController(_ vc: VNDocumentCameraViewController, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    final class Coordinator: NSObject, VNDocumentCameraViewControllerDelegate {
        let parent: DocumentScanner
        init(_ p: DocumentScanner) { parent = p }

        func documentCameraViewController(_ controller: VNDocumentCameraViewController,
                                          didFinishWith scan: VNDocumentCameraScan) {
            var imgs: [UIImage] = []
            for i in 0..<scan.pageCount { imgs.append(scan.imageOfPage(at: i)) }
            parent.onFinish(imgs)
        }

        func documentCameraViewControllerDidCancel(_ controller: VNDocumentCameraViewController) {
            parent.onCancel()
        }

        func documentCameraViewController(_ controller: VNDocumentCameraViewController,
                                          didFailWithError error: Error) {
            parent.onCancel()
        }
    }
}

// MARK: - Xử lý ảnh

extension UIImage {
    /// Vẽ lại cho đúng chiều + giới hạn cạnh dài nhất
    func normalized(maxSide: CGFloat = 2200) -> UIImage {
        let longest = max(size.width, size.height)
        let k = min(1, maxSide / max(longest, 1))
        let newSize = CGSize(width: size.width * k, height: size.height * k)
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        return UIGraphicsImageRenderer(size: newSize, format: fmt).image { _ in
            self.draw(in: CGRect(origin: .zero, size: newSize))
        }
    }

    /// Xoay theo bội số 90 độ (quarterTurns > 0 là xoay thuận chiều kim đồng hồ)
    func rotated(quarterTurns: Int) -> UIImage {
        let t = ((quarterTurns % 4) + 4) % 4
        if t == 0 { return self }
        let swap = (t % 2 == 1)
        let newSize = swap ? CGSize(width: size.height, height: size.width) : size
        let fmt = UIGraphicsImageRendererFormat.default()
        fmt.scale = 1
        return UIGraphicsImageRenderer(size: newSize, format: fmt).image { ctx in
            let c = ctx.cgContext
            c.translateBy(x: newSize.width / 2, y: newSize.height / 2)
            c.rotate(by: CGFloat(t) * .pi / 2)
            self.draw(in: CGRect(x: -size.width / 2, y: -size.height / 2,
                                 width: size.width, height: size.height))
        }
    }
}

enum Rectifier {
    /// Dò tờ giấy trong ảnh chụp thường và nắn phẳng (giống bản scan).
    /// Nếu không dò được thì trả lại ảnh gốc.
    static func flatten(_ image: UIImage) -> UIImage {
        guard let cg = image.cgImage else { return image }
        let req = VNDetectDocumentSegmentationRequest()
        let handler = VNImageRequestHandler(cgImage: cg, options: [:])
        do { try handler.perform([req]) } catch { return image }
        guard let obs = req.results?.first, obs.confidence > 0.6 else { return image }

        let ci = CIImage(cgImage: cg)
        let w = ci.extent.width, h = ci.extent.height
        func p(_ q: CGPoint) -> CGPoint { CGPoint(x: q.x * w, y: q.y * h) }

        let f = CIFilter.perspectiveCorrection()
        f.inputImage = ci
        f.topLeft = p(obs.topLeft)
        f.topRight = p(obs.topRight)
        f.bottomLeft = p(obs.bottomLeft)
        f.bottomRight = p(obs.bottomRight)
        guard let out = f.outputImage else { return image }
        let ctx = CIContext()
        guard let res = ctx.createCGImage(out, from: out.extent) else { return image }
        return UIImage(cgImage: res)
    }
}

// MARK: - OCR

struct OCRLine {
    var text: String
    var box: CGRect   // toạ độ chuẩn hoá 0...1, gốc ở góc dưới trái (kiểu Vision)
    var conf: Float = 1
}

enum OCR {
    static func recognize(_ cg: CGImage, correction: Bool, handwriting: Bool) -> [OCRLine] {
        let req = VNRecognizeTextRequest()
        req.recognitionLevel = .accurate
        req.usesLanguageCorrection = correction
        var langs = ["en-US"]
        if handwriting, let sup = try? req.supportedRecognitionLanguages(), sup.contains("vi-VN") {
            langs.append("vi-VN")
        }
        req.recognitionLanguages = langs
        let handler = VNImageRequestHandler(cgImage: cg, options: [:])
        do { try handler.perform([req]) } catch { return [] }
        var out: [OCRLine] = []
        for o in req.results ?? [] {
            if let c = o.topCandidates(1).first {
                out.append(OCRLine(text: c.string, box: o.boundingBox, conf: c.confidence))
            }
        }
        return out
    }

    static func overlap(_ a: CGRect, _ b: CGRect) -> CGFloat {
        let i = a.intersection(b)
        if i.isNull || i.isEmpty { return 0 }
        let inter = i.width * i.height
        let uni = a.width * a.height + b.width * b.height - inter
        return uni > 0 ? inter / uni : 0
    }

    /// Dòng đã khớp mẫu có cấu trúc (mã kiện, số RSI, ngày, đơn vị) thì giữ nguyên bản đọc chữ in.
    static func looksStructured(_ t: String) -> Bool {
        let id = SlipParser.idForm(t)
        if SlipParser.firstString(SlipParser.pkgRe, id) != nil { return true }
        if SlipParser.firstString(SlipParser.rsiRe, id) != nil { return true }
        if SlipParser.match(SlipParser.dateRe, SlipParser.clean(t)) != nil { return true }
        if id.contains("RSI-") { return true }
        return false
    }

    static func lines(_ image: UIImage) -> [OCRLine] {
        guard let cg = image.cgImage else { return [] }
        // Lượt 1: chữ in, giữ nguyên mã (không sửa chính tả)
        var out = recognize(cg, correction: false, handwriting: false)
        // Lượt 2: chữ viết tay (bật sửa chính tả, thêm tiếng Việt nếu máy hỗ trợ)
        let hand = recognize(cg, correction: true, handwriting: true)
        for h in hand {
            if let idx = out.firstIndex(where: { overlap($0.box, h.box) > 0.4 }) {
                let o = out[idx]
                if !looksStructured(o.text) && h.conf > o.conf + 0.05 { out[idx] = h }
            } else {
                out.append(h)
            }
        }
        return deskew(out, width: CGFloat(cg.width), height: CGFloat(cg.height))
    }

    /// Phiếu chụp bị nghiêng vài độ thì chữ bên phải thấp hơn bên trái cả một dòng,
    /// làm số lượng bị gán nhầm sang dòng khác. Ước lượng góc nghiêng rồi xoay toạ độ lại cho thẳng.
    static func deskew(_ lines: [OCRLine], width W: CGFloat, height H: CGFloat) -> [OCRLine] {
        guard lines.count >= 6, W > 0, H > 0 else { return lines }

        func yPrime(_ l: OCRLine, _ phi: CGFloat) -> CGFloat {
            let cx = l.box.midX * W
            let cy = l.box.midY * H
            return cy * cos(phi) - cx * sin(phi)
        }
        func score(_ phi: CGFloat) -> Int {
            var bins: [Int: Int] = [:]
            for l in lines {
                let b = Int(floor(yPrime(l, phi) / H / 0.005))
                bins[b, default: 0] += 1
            }
            return bins.values.reduce(0) { $0 + $1 * $1 }
        }

        var angles: [Double] = []
        var scores: [Int] = []
        var a = -6.0
        while a <= 6.0 {
            angles.append(a)
            scores.append(score(CGFloat(a * Double.pi / 180)))
            a += 0.25
        }
        let top = scores.max() ?? 0
        let base = score(0)
        guard Double(top) >= Double(base) * 1.08 else { return lines }

        var plateau: [Double] = []
        for (ang, sc) in zip(angles, scores) where Double(sc) >= Double(top) * 0.97 {
            plateau.append(ang)
        }
        plateau.sort()
        guard !plateau.isEmpty else { return lines }
        let phi = CGFloat(plateau[plateau.count / 2] * Double.pi / 180)

        return lines.map { l in
            let cx = l.box.midX * W
            let cy = l.box.midY * H
            let nx = (cx * cos(phi) + cy * sin(phi)) / W
            let ny = (cy * cos(phi) - cx * sin(phi)) / H
            return OCRLine(text: l.text,
                           box: CGRect(x: nx - l.box.width / 2, y: ny - l.box.height / 2,
                                       width: l.box.width, height: l.box.height))
        }
    }
}

// MARK: - Phân tích phiếu

struct Parsed {
    var rsiNo = ""
    var date = ""
    var project = ""
    var receivedBy = ""
    var receivedDate = ""
    var requestedBy = ""
    var checkedBy = ""
    var confirmedBy = ""
    var approvedBy = ""
    var remark = ""
    var items: [Item] = []
}

enum SlipParser {
    static let rsiRe = try! NSRegularExpression(
        pattern: "(?:[A-Z0-9]{2,4}-)?RSI-[A-Z]{1,3}-[A-Z]{1,3}-\\d{3,5}")
    static let pkgRe = try! NSRegularExpression(
        pattern: "[A-Z0-9]{2,4}-[A-Z0-9]{1,4}-[A-Z]{2}-\\d{4}-\\d{3}")
    static let dateRe = try! NSRegularExpression(
        pattern: "\\b\\d{1,2}-[A-Za-z]{3}-\\d{2,4}\\b")
    static let unitRe = try! NSRegularExpression(
        pattern: "^(M|EA|SET|SETS|PC|PCS|KG|LOT|ROLL|NOS|NO|PKG|BOX|CAN|DRUM|TON|M2|M3|L)$",
        options: [.caseInsensitive])
    static let unitQtyRe = try! NSRegularExpression(
        pattern: "^(M|EA|SET|SETS|PC|PCS|KG|LOT|ROLL|NOS|NO|PKG|BOX|CAN|DRUM|TON|M2|M3|L)\\s+(\\d+(?:[.,]\\d+)?)$",
        options: [.caseInsensitive])
    static let numRe = try! NSRegularExpression(pattern: "^\\d+(?:[.,]\\d+)?$")
    static let tagRe = try! NSRegularExpression(pattern: "\\d+\\s*mm", options: [.caseInsensitive])

    // Chữ của dòng tiêu đề bảng / nhãn in sẵn, không phải nội dung hàng hoá
    static let headerContains = ["request date", "tag no", "serial no", "actual h/o",
                                 "received by", "received date", "full name", "with signature",
                                 "description of goods", "package no", "invoice no",
                                 "requestion for", "q'ty", "q\u{2019}ty"]
    static let headerExact: Set<String> = ["unit", "no", "request", "balance", "remark", "remark:",
                                           "signature", "qty", "h/o", "date"]
    static let dateFullRe = try! NSRegularExpression(pattern: "^\\d{1,2}-[A-Za-z]{3}-\\d{2,4}$")

    static func isHeader(_ t: String) -> Bool {
        let c = clean(t)
        let l = c.lowercased()
        if l.isEmpty || headerExact.contains(l) { return true }
        if match(dateFullRe, c) != nil { return true }
        return headerContains.contains { l.contains($0) }
    }

    static func clean(_ s: String) -> String {
        s.replacingOccurrences(of: "–", with: "-")
         .replacingOccurrences(of: "—", with: "-")
         .replacingOccurrences(of: "‐", with: "-")
         .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    /// Dạng dùng để dò mã: viết hoa, bỏ khoảng trắng
    static func idForm(_ s: String) -> String {
        clean(s).uppercased().replacingOccurrences(of: " ", with: "")
    }

    static func match(_ re: NSRegularExpression, _ s: String) -> NSRange? {
        let r = NSRange(s.startIndex..., in: s)
        let m = re.firstMatch(in: s, range: r)
        return m?.range
    }

    static func firstString(_ re: NSRegularExpression, _ s: String) -> String? {
        guard let r = match(re, s), let rr = Range(r, in: s) else { return nil }
        return String(s[rr])
    }

    static let handTrim = CharacterSet(charactersIn: " .,…_(){}[]|\\/:;'\"`~-")
    static let digitMap: [Character: Character] = [
        "O": "0", "o": "0", "D": "0", "Q": "0",
        "l": "1", "I": "1", "i": "1", "|": "1", "!": "1",
        "Z": "2", "z": "2", "T": "7", "S": "5", "s": "5", "B": "8", "g": "9", "q": "9"
    ]

    /// Chữ số viết tay hay bị đọc nhầm (O->0, l->1, S->5...). Trả nil nếu không phải số ngắn.
    static func digitize(_ t: String) -> String? {
        let c = t.trimmingCharacters(in: handTrim)
        guard !c.isEmpty, c.count <= 4 else { return nil }
        var r = ""
        for ch in c {
            if ch.isNumber { r.append(ch) }
            else if let m = digitMap[ch] { r.append(m) }
            else { return nil }
        }
        return r
    }

    static let rsiPrefixRe = try! NSRegularExpression(
        pattern: "(?:[A-Z0-9]{2,4}-)?RSI-[A-Z]{1,3}-[A-Z]{1,3}-(\\d{0,5})")
    static let handDateRe = try! NSRegularExpression(
        pattern: "(\\d{1,2})[/.\\-](\\d{1,2})[/.\\-](\\d{2,4})")

    /// Số RSI: phần đầu in sẵn "OM4-RSI-DE-EL-00....", số cuối thường do người ký viết tay.
    static func rsiNumber(_ lines: [OCRLine]) -> String {
        for l in lines {
            let raw = idForm(l.text)
            let id = raw.replacingOccurrences(of: "…", with: "")
                .replacingOccurrences(of: ".", with: "")
                .replacingOccurrences(of: "_", with: "")
            let r = NSRange(id.startIndex..., in: id)
            guard let m = rsiPrefixRe.firstMatch(in: id, range: r),
                  let whole = Range(m.range, in: id),
                  let dg = Range(m.range(at: 1), in: id) else { continue }
            let digits = String(id[dg])
            let prefix = String(id[whole]).dropLast(digits.count)
            if digits.count >= 4 { return String(prefix) + digits }

            // thiếu số: tìm chữ số viết tay cùng dòng, nằm bên phải
            let band = max(l.box.height * 1.3, 0.012)
            var hand: [(CGFloat, String)] = []
            for c in lines where c.box != l.box {
                if abs(c.box.midY - l.box.midY) > band { continue }
                if c.box.midX < l.box.minX + l.box.width * 0.5 { continue }
                if let d = digitize(c.text) { hand.append((c.box.minX, d)) }
            }
            hand.sort { $0.0 < $1.0 }
            let h = hand.map { $0.1 }.joined()
            let total = digits + h
            if !h.isEmpty && total.count <= 5 && total.count >= 3 { return String(prefix) + total }
            if digits.count >= 3 { return String(prefix) + digits }
        }
        for l in lines {
            let id = idForm(l.text).replacingOccurrences(of: ".", with: "")
            if let s = firstString(rsiRe, id) { return s }
        }
        return ""
    }

    static let printedWords = ["requested", "checked", "confirmed", "approved", "sub-contractor",
                               "subcontractor", "material", "controller", "manager", "doosan",
                               "construction", "attachment", "packing", "drawing", "remark",
                               "signature", "installation of"]

    static func isPrinted(_ t: String) -> Bool {
        let l = clean(t).lowercased()
        return printedWords.contains { l.contains($0) }
    }

    /// Tên viết tay cạnh nhãn chữ ký (Requested By, Checked By...): nằm bên phải, hơi cao hơn nhãn
    static func nameNear(_ label: CGRect, _ lines: [OCRLine]) -> String {
        var c: [OCRLine] = []
        for l in lines {
            if l.box == label { continue }
            if l.box.minX < label.maxX - 0.01 { continue }
            if l.box.minX > label.maxX + 0.5 { continue }
            let dy = l.box.midY - label.midY
            if dy < -0.02 || dy > 0.05 { continue }
            if isPrinted(l.text) || isHeader(l.text) { continue }
            if clean(l.text).filter({ $0.isLetter }).count < 3 { continue }
            c.append(l)
        }
        c.sort { $0.box.minX < $1.box.minX }
        return c.map { clean($0.text) }.joined(separator: " ")
    }

    static func labelBox(_ lines: [OCRLine], _ key: String) -> CGRect? {
        lines.first(where: { clean($0.text).lowercased().contains(key) })?.box
    }

    static func parse(_ lines: [OCRLine]) -> Parsed {
        var out = Parsed()

        // 1. Số RSI
        out.rsiNo = rsiNumber(lines)

        // 2. Ngày yêu cầu
        for l in lines {
            if let s = firstString(dateRe, clean(l.text)) { out.date = s; break }
        }

        // 3. Tên dự án
        for l in lines {
            let u = clean(l.text).uppercased()
            if u.contains("PROJECT") && u.count <= 40 { out.project = clean(l.text); break }
        }

        // 3b. Ngày nhận (viết tay dạng 28/09/2026) và người nhận (viết tay dưới cột Full name)
        for l in lines {
            let t = clean(l.text).replacingOccurrences(of: " ", with: "")
            if let r = match(handDateRe, t), let rr = Range(r, in: t) {
                out.receivedDate = String(t[rr]); break
            }
        }
        if let hdr = lines.first(where: { clean($0.text).lowercased().contains("full name") }) {
            var best = ""
            for l in lines {
                let t = clean(l.text)
                if abs(l.box.midX - hdr.box.midX) > 0.08 { continue }
                if l.box.midY > hdr.box.minY - hdr.box.height * 0.5 { continue }
                if l.box.midY < hdr.box.midY - 0.3 { continue }
                if isHeader(t) || firstString(pkgRe, idForm(t)) != nil { continue }
                if match(handDateRe, t.replacingOccurrences(of: " ", with: "")) != nil { continue }
                let letters = t.filter { $0.isLetter }.count
                let words = t.split(separator: " ").count
                if letters >= 5 && words >= 2 && letters > best.filter({ $0.isLetter }).count { best = t }
            }
            out.receivedBy = best
        }

        // 3c. Tên viết tay cạnh các ô chữ ký ở cuối phiếu
        if let b = labelBox(lines, "requested by") { out.requestedBy = nameNear(b, lines) }
        if let b = labelBox(lines, "checked by") { out.checkedBy = nameNear(b, lines) }
        if let b = labelBox(lines, "confirmed by") { out.confirmedBy = nameNear(b, lines) }
        if let b = labelBox(lines, "approved by") { out.approvedBy = nameNear(b, lines) }

        // 3d. Ghi chú: dòng in cạnh "Remark:" (kèm chữ viết tay cùng dòng) và chữ viết tay dưới cùng tờ
        var remarkParts: [String] = []
        let remarkLabels = lines.filter {
            clean($0.text).lowercased().hasPrefix("remark") && $0.box.minX < 0.3
        }
        if let rl = remarkLabels.min(by: { $0.box.midY < $1.box.midY }) {
            let rowLines = lines.filter { l in
                l.box != rl.box
                    && l.box.minX > rl.box.minX - 0.01
                    && l.box.midY <= rl.box.midY + 0.01
                    && l.box.midY >= rl.box.midY - 0.06
                    && !l.text.lowercased().contains("remark")
                    && clean(l.text).filter({ $0.isLetter }).count >= 2
            }
            .sorted { $0.box.minX < $1.box.minX }
            for l in rowLines { remarkParts.append(clean(l.text)) }
        }
        if let att = lines.first(where: { clean($0.text).lowercased().contains("attachment") && $0.box.minX < 0.3 }) {
            let below = lines.filter { l in
                l.box.midY < att.box.midY - 0.03
                    && !isPrinted(l.text) && !isHeader(l.text)
                    && clean(l.text).filter({ $0.isLetter }).count >= 3
            }
            .sorted { $0.box.midY > $1.box.midY }
            for l in below { remarkParts.append(clean(l.text)) }
        }
        out.remark = remarkParts.joined(separator: " · ")

        // 4. Bảng kiện hàng: mỗi mã Package No là một dòng
        struct Anchor { var pkg: String; var box: CGRect; var rest: String }
        var anchors: [Anchor] = []
        for l in lines {
            let id = idForm(l.text)
            if let pkg = firstString(pkgRe, id) {
                var rest = clean(l.text)
                // phần chữ còn lại cùng dòng (nếu OCR gộp), bỏ mã đi
                rest = rest.replacingOccurrences(of: pkg, with: "", options: .caseInsensitive)
                anchors.append(Anchor(pkg: pkg, box: l.box,
                                      rest: rest.trimmingCharacters(in: .whitespaces)))
            }
        }
        anchors.sort { $0.box.midY > $1.box.midY }

        // bỏ trùng (cùng mã, gần như cùng độ cao)
        var uniq: [Anchor] = []
        for a in anchors {
            if let last = uniq.last, last.pkg == a.pkg, abs(last.box.midY - a.box.midY) < 0.015 { continue }
            uniq.append(a)
        }

        var gaps: [CGFloat] = []
        if uniq.count > 1 {
            for i in 1..<uniq.count {
                gaps.append(uniq[i - 1].box.midY - uniq[i].box.midY)
            }
        }
        gaps.sort()
        let typical: CGFloat = gaps.isEmpty ? 0.05 : gaps[gaps.count / 2]

        let actualHeader = lines.first(where: { clean($0.text).lowercased().contains("actual") })?.box

        for (i, a) in uniq.enumerated() {
            let up = i > 0 ? (uniq[i - 1].box.midY - a.box.midY) : typical
            let down = i < uniq.count - 1 ? (a.box.midY - uniq[i + 1].box.midY) : typical * 0.9
            let top = a.box.midY + up / 2
            let bottom = a.box.midY - down / 2

            var members: [OCRLine] = []
            if !a.rest.isEmpty && !isHeader(a.rest) {
                members.append(OCRLine(text: a.rest, box: CGRect(x: a.box.maxX, y: a.box.minY,
                                                                 width: 0.001, height: a.box.height)))
            }
            for l in lines {
                if l.box.midY < bottom || l.box.midY > top { continue }
                if l.box.minX < a.box.maxX - 0.01 { continue }
                if firstString(pkgRe, idForm(l.text)) != nil { continue }
                if isHeader(l.text) { continue }
                members.append(l)
            }

            var item = Item()
            item.packageNo = a.pkg

            // đơn vị + số lượng
            var unitBox: CGRect? = nil
            var qtyBox: CGRect? = nil
            for l in members {
                let t = clean(l.text)
                if let r = match(unitQtyRe, t),
                   let m = unitQtyRe.firstMatch(in: t, range: r),
                   let u = Range(m.range(at: 1), in: t), let q = Range(m.range(at: 2), in: t) {
                    item.unit = String(t[u]).uppercased()
                    item.qty = String(t[q])
                    unitBox = l.box
                    qtyBox = l.box
                    break
                }
            }
            if unitBox == nil {
                for l in members where match(unitRe, clean(l.text)) != nil {
                    item.unit = clean(l.text).uppercased()
                    unitBox = l.box
                    break
                }
                if let ub = unitBox {
                    let right = members
                        .filter { $0.box.minX >= ub.maxX - 0.005 && match(numRe, clean($0.text)) != nil }
                        .sorted { $0.box.minX < $1.box.minX }
                    if let q = right.first { item.qty = clean(q.text); qtyBox = q.box }
                }
            }

            // số lượng thực nhận (viết tay, cột Actual H/O): số nằm bên phải cột Request Q'ty
            if let qb = qtyBox {
                var cands: [(CGFloat, String)] = []
                for l in members where l.box.minX > qb.maxX + 0.005 && l.box != qb {
                    if let hr = actualHeader, abs(l.box.midX - hr.midX) > hr.width * 0.9 + 0.03 { continue }
                    if let d = digitize(l.text) { cands.append((l.box.minX, d)) }
                }
                cands.sort { $0.0 < $1.0 }
                if let c = cands.first { item.actualQty = c.1 }
            }

            // tag + mô tả
            var descParts: [OCRLine] = []
            for l in members {
                let t = clean(l.text)
                if match(tagRe, t) != nil && (unitBox == nil || l.box.minX < unitBox!.minX) {
                    item.tag = t
                    continue
                }
                if let ub = unitBox, l.box.minX >= ub.minX - 0.005 { continue }
                if match(numRe, t) != nil { continue }
                if match(unitRe, t) != nil { continue }
                descParts.append(l)
            }
            descParts.sort { $0.box.midY > $1.box.midY }
            var textRows: [[OCRLine]] = []
            for l in descParts {
                if var last = textRows.last, let f = last.first,
                   abs(f.box.midY - l.box.midY) < max(f.box.height, l.box.height) * 0.6 {
                    last.append(l)
                    textRows[textRows.count - 1] = last
                } else {
                    textRows.append([l])
                }
            }
            item.desc = textRows
                .map { $0.sorted { $0.box.minX < $1.box.minX }.map { clean($0.text) }.joined(separator: " ") }
                .joined(separator: " ")

            out.items.append(item)
        }
        return out
    }
}

// MARK: - Quy trình: ảnh -> (ảnh đã nắn phẳng, kết quả đọc)

enum Pipeline {
    static func process(_ original: UIImage, flatten: Bool) -> (UIImage, Parsed) {
        var base = original.normalized()
        if flatten { base = Rectifier.flatten(base).normalized() }

        var best = base
        var parsed = SlipParser.parse(OCR.lines(base))

        // Nếu không đọc được gì, thử xoay 90/180/270 (ảnh chụp ngang/dọc lệch)
        if parsed.rsiNo.isEmpty && parsed.items.isEmpty {
            for turns in [1, 3, 2] {
                let r = base.rotated(quarterTurns: turns)
                let p = SlipParser.parse(OCR.lines(r))
                if !p.rsiNo.isEmpty || !p.items.isEmpty {
                    best = r
                    parsed = p
                    break
                }
            }
        }
        return (best, parsed)
    }

    static func merge(_ list: [Parsed]) -> Parsed {
        var out = Parsed()
        for p in list {
            if out.rsiNo.isEmpty { out.rsiNo = p.rsiNo }
            if out.date.isEmpty { out.date = p.date }
            if out.project.isEmpty { out.project = p.project }
            if out.receivedBy.isEmpty { out.receivedBy = p.receivedBy }
            if out.receivedDate.isEmpty { out.receivedDate = p.receivedDate }
            if out.requestedBy.isEmpty { out.requestedBy = p.requestedBy }
            if out.checkedBy.isEmpty { out.checkedBy = p.checkedBy }
            if out.confirmedBy.isEmpty { out.confirmedBy = p.confirmedBy }
            if out.approvedBy.isEmpty { out.approvedBy = p.approvedBy }
            if out.remark.isEmpty { out.remark = p.remark }
            out.items.append(contentsOf: p.items)
        }
        return out
    }
}
