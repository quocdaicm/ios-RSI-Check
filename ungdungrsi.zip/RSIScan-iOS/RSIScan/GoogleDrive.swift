import SwiftUI
import AuthenticationServices
import CryptoKit
import Security

// MARK: - Cấu hình

enum DriveConfig {
    /// DÁN Client ID (loại "iOS") lấy từ Google Cloud Console vào đây.
    /// Dạng: 1234567890-abcdefg.apps.googleusercontent.com
    static let clientID = "66245596761-eca4uan2l5og6h5evn200ht4302gkfdd.apps.googleusercontent.com"

    /// drive.file: app chỉ thấy các file do chính nó tạo ra, không đọc được file khác trong Drive.
    static let scope = "https://www.googleapis.com/auth/drive.file email"
    static let folderName = "RSIScan Backup"
    static let keep = 4

    static let emailKey = "driveEmail"
    static let folderIDKey = "driveFolderID"

    static var isConfigured: Bool { !clientID.hasPrefix("DAN_CLIENT_ID") }

    /// "123-abc.apps.googleusercontent.com" -> "com.googleusercontent.apps.123-abc"
    static var scheme: String {
        let id = clientID.replacingOccurrences(of: ".apps.googleusercontent.com", with: "")
        return "com.googleusercontent.apps." + id
    }
    static var redirectURI: String { scheme + ":/oauth2redirect" }
    static var signedIn: Bool {
        !(UserDefaults.standard.string(forKey: emailKey) ?? "").isEmpty
    }
}

struct DriveError: LocalizedError {
    let message: String
    init(_ m: String) { message = m }
    var errorDescription: String? { message }
}

// MARK: - Keychain (lưu refresh token)

enum DriveKeychain {
    private static func base(_ key: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "rsiscan.drive",
         kSecAttrAccount as String: key]
    }
    static func set(_ value: String, for key: String) {
        SecItemDelete(base(key) as CFDictionary)
        var q = base(key)
        q[kSecValueData as String] = Data(value.utf8)
        q[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlock
        SecItemAdd(q as CFDictionary, nil)
    }
    static func get(_ key: String) -> String? {
        var q = base(key)
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var out: AnyObject?
        guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess,
              let d = out as? Data else { return nil }
        return String(data: d, encoding: .utf8)
    }
    static func remove(_ key: String) {
        SecItemDelete(base(key) as CFDictionary)
    }
}

// MARK: - OAuth token

private struct TokenResponse: Decodable {
    let accessToken: String
    let expiresIn: Int
    let refreshToken: String?
}

private enum DriveHTTP {
    static func form(_ params: [String: String]) -> Data {
        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: "+&=")
        let s = params.map { k, v in
            "\(k)=\(v.addingPercentEncoding(withAllowedCharacters: allowed) ?? v)"
        }.joined(separator: "&")
        return Data(s.utf8)
    }

    static func token(_ params: [String: String]) async throws -> TokenResponse {
        var r = URLRequest(url: URL(string: "https://oauth2.googleapis.com/token")!)
        r.httpMethod = "POST"
        r.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        r.httpBody = form(params)
        let (d, resp) = try await URLSession.shared.data(for: r)
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        guard code == 200 else {
            let body = String(data: d, encoding: .utf8) ?? ""
            if body.contains("invalid_grant") {
                throw DriveError("Phiên đăng nhập Google đã hết hạn, hãy đăng nhập lại.")
            }
            throw DriveError("Google từ chối đăng nhập (\(code)). \(body.prefix(200))")
        }
        let dec = JSONDecoder()
        dec.keyDecodingStrategy = .convertFromSnakeCase
        return try dec.decode(TokenResponse.self, from: d)
    }

    static func random(_ n: Int) -> String {
        var bytes = [UInt8](repeating: 0, count: n)
        _ = SecRandomCopyBytes(kSecRandomDefault, n, &bytes)
        return b64url(Data(bytes))
    }

    static func b64url(_ d: Data) -> String {
        d.base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }
}

// MARK: - Đăng nhập (ASWebAuthenticationSession + PKCE)

final class DriveSignIn: NSObject, ASWebAuthenticationPresentationContextProviding {
    static let shared = DriveSignIn()
    private var session: ASWebAuthenticationSession?

    func presentationAnchor(for session: ASWebAuthenticationSession) -> ASPresentationAnchor {
        let scene = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.first
        return scene?.windows.first(where: { $0.isKeyWindow }) ?? scene?.windows.first ?? ASPresentationAnchor()
    }

    @MainActor
    func signIn() async throws {
        guard DriveConfig.isConfigured else {
            throw DriveError("Chưa dán Client ID Google vào GoogleDrive.swift (DriveConfig.clientID).")
        }
        let verifier = DriveHTTP.random(48)
        let challenge = DriveHTTP.b64url(Data(SHA256.hash(data: Data(verifier.utf8))))
        let state = DriveHTTP.random(16)

        var comps = URLComponents(string: "https://accounts.google.com/o/oauth2/v2/auth")!
        comps.queryItems = [
            URLQueryItem(name: "client_id", value: DriveConfig.clientID),
            URLQueryItem(name: "redirect_uri", value: DriveConfig.redirectURI),
            URLQueryItem(name: "response_type", value: "code"),
            URLQueryItem(name: "scope", value: DriveConfig.scope),
            URLQueryItem(name: "code_challenge", value: challenge),
            URLQueryItem(name: "code_challenge_method", value: "S256"),
            URLQueryItem(name: "state", value: state),
            URLQueryItem(name: "access_type", value: "offline"),
            URLQueryItem(name: "prompt", value: "consent")
        ]

        let callback: URL = try await withCheckedThrowingContinuation { cont in
            let s = ASWebAuthenticationSession(url: comps.url!,
                                               callbackURLScheme: DriveConfig.scheme) { url, err in
                if let url = url {
                    cont.resume(returning: url)
                } else if let e = err as? ASWebAuthenticationSessionError, e.code == .canceledLogin {
                    cont.resume(throwing: DriveError("Đã huỷ đăng nhập."))
                } else {
                    cont.resume(throwing: err ?? DriveError("Đăng nhập thất bại."))
                }
            }
            s.presentationContextProvider = self
            s.prefersEphemeralWebBrowserSession = false
            self.session = s
            if !s.start() {
                cont.resume(throwing: DriveError("Không mở được trang đăng nhập Google."))
            }
        }
        session = nil

        let items = URLComponents(url: callback, resolvingAgainstBaseURL: false)?.queryItems ?? []
        func val(_ n: String) -> String? { items.first(where: { $0.name == n })?.value }
        if let e = val("error") { throw DriveError("Google báo lỗi: \(e)") }
        guard val("state") == state, let code = val("code") else {
            throw DriveError("Phản hồi đăng nhập không hợp lệ.")
        }

        let t = try await DriveHTTP.token([
            "client_id": DriveConfig.clientID,
            "code": code,
            "code_verifier": verifier,
            "redirect_uri": DriveConfig.redirectURI,
            "grant_type": "authorization_code"
        ])
        guard let refresh = t.refreshToken else {
            throw DriveError("Google không cấp quyền truy cập lâu dài. Hãy thử đăng nhập lại.")
        }
        DriveKeychain.set(refresh, for: "refresh")
        await DriveClient.shared.setToken(t.accessToken, expiresIn: t.expiresIn)
        let email = (try? await DriveClient.shared.userEmail()) ?? "Đã đăng nhập"
        UserDefaults.standard.removeObject(forKey: DriveConfig.folderIDKey)
        UserDefaults.standard.set(email, forKey: DriveConfig.emailKey)
    }

    static func signOut() async {
        DriveKeychain.remove("refresh")
        UserDefaults.standard.removeObject(forKey: DriveConfig.emailKey)
        UserDefaults.standard.removeObject(forKey: DriveConfig.folderIDKey)
        await DriveClient.shared.clearToken()
    }
}

// MARK: - Drive REST API

private struct DriveFile: Decodable {
    let id: String
    let name: String?
    let trashed: Bool?
}
private struct DriveFileList: Decodable { let files: [DriveFile] }
private struct UserInfo: Decodable { let email: String? }

actor DriveClient {
    static let shared = DriveClient()

    private var token: String?
    private var expiry = Date.distantPast

    private let session: URLSession = {
        let c = URLSessionConfiguration.default
        c.timeoutIntervalForRequest = 120
        c.timeoutIntervalForResource = 3600
        c.waitsForConnectivity = true
        return URLSession(configuration: c)
    }()

    func setToken(_ t: String, expiresIn: Int) {
        token = t
        expiry = Date().addingTimeInterval(Double(expiresIn))
    }
    func clearToken() { token = nil; expiry = .distantPast }

    private func accessToken() async throws -> String {
        if let t = token, expiry > Date().addingTimeInterval(60) { return t }
        guard let rt = DriveKeychain.get("refresh") else {
            throw DriveError("Chưa đăng nhập Google Drive.")
        }
        do {
            let r = try await DriveHTTP.token([
                "client_id": DriveConfig.clientID,
                "refresh_token": rt,
                "grant_type": "refresh_token"
            ])
            setToken(r.accessToken, expiresIn: r.expiresIn)
            return r.accessToken
        } catch {
            if error.localizedDescription.contains("hết hạn") {
                await DriveSignIn.signOut()
            }
            throw error
        }
    }

    private func send(_ req: URLRequest, ok: Set<Int> = [200, 201, 204]) async throws -> (Data, HTTPURLResponse) {
        var r = req
        r.setValue("Bearer " + (try await accessToken()), forHTTPHeaderField: "Authorization")
        let (d, resp) = try await session.data(for: r)
        guard let h = resp as? HTTPURLResponse else { throw DriveError("Không kết nối được Google Drive.") }
        guard ok.contains(h.statusCode) else {
            if h.statusCode == 401 { clearToken() }
            let body = String(data: d, encoding: .utf8) ?? ""
            throw DriveError("Google Drive báo lỗi \(h.statusCode). \(body.prefix(160))")
        }
        return (d, h)
    }

    func userEmail() async throws -> String? {
        let (d, _) = try await send(URLRequest(url: URL(string: "https://www.googleapis.com/oauth2/v3/userinfo")!))
        return (try? JSONDecoder().decode(UserInfo.self, from: d))?.email
    }

    private func listFiles(query: String, fields: String = "files(id,name,trashed)",
                           orderBy: String? = nil) async throws -> [DriveFile] {
        var c = URLComponents(string: "https://www.googleapis.com/drive/v3/files")!
        var qi = [URLQueryItem(name: "q", value: query),
                  URLQueryItem(name: "fields", value: fields),
                  URLQueryItem(name: "pageSize", value: "100"),
                  URLQueryItem(name: "spaces", value: "drive")]
        if let o = orderBy { qi.append(URLQueryItem(name: "orderBy", value: o)) }
        c.queryItems = qi
        let (d, _) = try await send(URLRequest(url: c.url!))
        return (try JSONDecoder().decode(DriveFileList.self, from: d)).files
    }

    private func ensureFolder() async throws -> String {
        let ud = UserDefaults.standard
        if let id = ud.string(forKey: DriveConfig.folderIDKey) {
            var c = URLComponents(string: "https://www.googleapis.com/drive/v3/files/\(id)")!
            c.queryItems = [URLQueryItem(name: "fields", value: "id,trashed")]
            if let (d, _) = try? await send(URLRequest(url: c.url!)),
               let f = try? JSONDecoder().decode(DriveFile.self, from: d), f.trashed != true {
                return id
            }
        }
        let mime = "application/vnd.google-apps.folder"
        let found = try await listFiles(
            query: "name = '\(DriveConfig.folderName)' and mimeType = '\(mime)' and trashed = false")
        if let f = found.first {
            ud.set(f.id, forKey: DriveConfig.folderIDKey)
            return f.id
        }
        var r = URLRequest(url: URL(string: "https://www.googleapis.com/drive/v3/files?fields=id")!)
        r.httpMethod = "POST"
        r.setValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        r.httpBody = try JSONSerialization.data(withJSONObject: ["name": DriveConfig.folderName, "mimeType": mime])
        let (d, _) = try await send(r)
        let f = try JSONDecoder().decode(DriveFile.self, from: d)
        ud.set(f.id, forKey: DriveConfig.folderIDKey)
        return f.id
    }

    /// Tải file zip lên thư mục "RSIScan Backup", giữ lại DriveConfig.keep bản mới nhất.
    func upload(_ zip: URL) async throws -> String {
        let folder = try await ensureFolder()
        let name = zip.lastPathComponent
        let size = (try? FileManager.default.attributesOfItem(atPath: zip.path)[.size] as? Int) ?? 0

        var start = URLRequest(url: URL(string: "https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields=id,name")!)
        start.httpMethod = "POST"
        start.setValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        start.setValue("application/zip", forHTTPHeaderField: "X-Upload-Content-Type")
        start.setValue(String(size), forHTTPHeaderField: "X-Upload-Content-Length")
        start.httpBody = try JSONSerialization.data(withJSONObject: ["name": name, "parents": [folder]])
        let (_, h) = try await send(start)
        guard let loc = h.value(forHTTPHeaderField: "Location"), let putURL = URL(string: loc) else {
            throw DriveError("Google Drive không cấp địa chỉ tải lên.")
        }

        var put = URLRequest(url: putURL)
        put.httpMethod = "PUT"
        put.setValue("application/zip", forHTTPHeaderField: "Content-Type")
        let (d, resp) = try await session.upload(for: put, fromFile: zip)
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        guard code == 200 || code == 201 else {
            let body = String(data: d, encoding: .utf8) ?? ""
            throw DriveError("Tải lên Google Drive thất bại (\(code)). \(body.prefix(160))")
        }

        // Xoá các bản cũ (lỗi ở bước này không làm hỏng bản vừa sao lưu)
        if let all = try? await listFiles(
            query: "'\(folder)' in parents and trashed = false and name contains 'RSIScan-'",
            orderBy: "name desc") {
            let olds = all.filter { ($0.name ?? "").hasPrefix("RSIScan-") && ($0.name ?? "").hasSuffix(".zip") }
            for f in olds.dropFirst(DriveConfig.keep) {
                var del = URLRequest(url: URL(string: "https://www.googleapis.com/drive/v3/files/\(f.id)")!)
                del.httpMethod = "DELETE"
                _ = try? await send(del)
            }
        }
        return name
    }
}

// MARK: - Nối vào Store

extension Store {
    var hasDrive: Bool { DriveConfig.signedIn }

    func backupToDrive() async -> String {
        guard let zip = exportAll() else { return "Không tạo được file sao lưu." }
        defer { try? FileManager.default.removeItem(at: zip) }
        do {
            let name = try await DriveClient.shared.upload(zip)
            UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: BackupPrefs.lastKey)
            return "Đã sao lưu lên Google Drive: \(name)"
        } catch {
            return error.localizedDescription
        }
    }

    /// Đã đăng nhập Google -> sao lưu lên Drive; chưa thì dùng thư mục đã chọn trong Tệp.
    func backupAny() async -> String {
        if hasDrive { return await backupToDrive() }
        return backupNow()
    }
}
