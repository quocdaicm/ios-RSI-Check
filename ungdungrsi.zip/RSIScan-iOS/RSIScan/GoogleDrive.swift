import SwiftUI
import AuthenticationServices
import CryptoKit
import Security

// MARK: - Cấu hình

enum DriveConfig {
    /// DÁN Client ID (loại "iOS") lấy từ Google Cloud Console vào đây.
    /// Dạng: 1234567890-abcdefg.apps.googleusercontent.com
    static let clientID = "66245596761-eca4uan2l5og6h5evn200ht4302gkfdd.apps.googleusercontent.com"

    /// drive.file: app chỉ thấy các file do chính nó tạo ra, không đọc được file khác trong Drive.
    static let scope = "https://www.googleapis.com/auth/drive.file email"
    static let folderName = "RSIScan Backup"
    static let keep = 4

    static let emailKey = "driveEmail"
    static let folderIDKey = "driveFolderID"

    // Drive là nơi lưu chính: mỗi phiếu một thư mục con trong "RSIScan"
    static let rootName = "RSIScan"
    static let rootIDKey = "driveRootID"
    static let primaryKey = "drivePrimary"
    /// Mặc định bật khi đã đăng nhập Google.
    static var primaryOn: Bool {
        signedIn && (UserDefaults.standard.object(forKey: primaryKey) as? Bool ?? true)
    }

    static var isConfigured: Bool { !clientID.hasPrefix("DAN_CLIENT_ID") }

    /// "123-abc.apps.googleusercontent.com" -> "com.googleusercontent.apps.123-abc"
    static var scheme: String {
        let id = clientID.replacingOccurrences(of: ".apps.googleusercontent.com", with: "")
        return "com.googleusercontent.apps." + id
    }
    static var redirectURI: String { scheme + ":/oauth2redirect" }
    static var signedIn: Bool {
        !(UserDefaults.standard.string(forKey: emailKey) ?? "").isEmpty
    }
}

struct DriveError: LocalizedError {
    let message: String
    init(_ m: String) { message = m }
    var errorDescription: String? { message }
}

// MARK: - Keychain (lưu refresh token)

enum DriveKeychain {
    private static func base(_ key: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "rsiscan.drive",
         kSecAttrAccount as String: key]
    }
    static func set(_ value: String, for key: String) {
        SecItemDelete(base(key) as CFDictionary)
        var q = base(key)
        q[kSecValueData as String] = Data(value.utf8)
        q[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlock
        SecItemAdd(q as CFDictionary, nil)
    }
    static func get(_ key: String) -> String? {
        var q = base(key)
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var out: AnyObject?
        guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess,
              let d = out as? Data else { return nil }
        return String(data: d, encoding: .utf8)
    }
    static func remove(_ key: String) {
        SecItemDelete(base(key) as CFDictionary)
    }
}

// MARK: - OAuth token

private struct TokenResponse: Decodable {
    let accessToken: String
    let expiresIn: Int
    let refreshToken: String?
}

private enum DriveHTTP {
    static func form(_ params: [String: String]) -> Data {
        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: "+&=")
        let s = params.map { k, v in
            "\(k)=\(v.addingPercentEncoding(withAllowedCharacters: allowed) ?? v)"
        }.joined(separator: "&")
        return Data(s.utf8)
    }

    static func token(_ params: [String: String]) async throws -> TokenResponse {
        var r = URLRequest(url: URL(string: "https://oauth2.googleapis.com/token")!)
        r.httpMethod = "POST"
        r.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        r.httpBody = form(params)
        let (d, resp) = try await URLSession.shared.data(for: r)
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        guard code == 200 else {
            let body = String(data: d, encoding: .utf8) ?? ""
            if body.contains("invalid_grant") {
                throw DriveError("Phiên đăng nhập Google đã hết hạn, hãy đăng nhập lại.")
            }
            throw DriveError("Google từ chối đăng nhập (\(code)). \(body.prefix(200))")
        }
        let dec = JSONDecoder()
        dec.keyDecodingStrategy = .convertFromSnakeCase
        return try dec.decode(TokenResponse.self, from: d)
    }

    static func random(_ n: Int) -> String {
        var bytes = [UInt8](repeating: 0, count: n)
        _ = SecRandomCopyBytes(kSecRandomDefault, n, &bytes)
        return b64url(Data(bytes))
    }

    static func b64url(_ d: Data) -> String {
        d.base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }
}

// MARK: - Đăng nhập (ASWebAuthenticationSession + PKCE)

final class DriveSignIn: NSObject, ASWebAuthenticationPresentationContextProviding {
    static let shared = DriveSignIn()
    private var session: ASWebAuthenticationSession?

    func presentationAnchor(for session: ASWebAuthenticationSession) -> ASPresentationAnchor {
        let scene = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.first
        return scene?.windows.first(where: { $0.isKeyWindow }) ?? scene?.windows.first ?? ASPresentationAnchor()
    }

    @MainActor
    func signIn() async throws {
        guard DriveConfig.isConfigured else {
            throw DriveError("Chưa dán Client ID Google vào GoogleDrive.swift (DriveConfig.clientID).")
        }
        let verifier = DriveHTTP.random(48)
        let challenge = DriveHTTP.b64url(Data(SHA256.hash(data: Data(verifier.utf8))))
        let state = DriveHTTP.random(16)

        var comps = URLComponents(string: "https://accounts.google.com/o/oauth2/v2/auth")!
        comps.queryItems = [
            URLQueryItem(name: "client_id", value: DriveConfig.clientID),
            URLQueryItem(name: "redirect_uri", value: DriveConfig.redirectURI),
            URLQueryItem(name: "response_type", value: "code"),
            URLQueryItem(name: "scope", value: DriveConfig.scope),
            URLQueryItem(name: "code_challenge", value: challenge),
            URLQueryItem(name: "code_challenge_method", value: "S256"),
            URLQueryItem(name: "state", value: state),
            URLQueryItem(name: "access_type", value: "offline"),
            URLQueryItem(name: "prompt", value: "consent")
        ]

        let callback: URL = try await withCheckedThrowingContinuation { cont in
            let s = ASWebAuthenticationSession(url: comps.url!,
                                               callbackURLScheme: DriveConfig.scheme) { url, err in
                if let url = url {
                    cont.resume(returning: url)
                } else if let e = err as? ASWebAuthenticationSessionError, e.code == .canceledLogin {
                    cont.resume(throwing: DriveError("Đã huỷ đăng nhập."))
                } else {
                    cont.resume(throwing: err ?? DriveError("Đăng nhập thất bại."))
                }
            }
            s.presentationContextProvider = self
            s.prefersEphemeralWebBrowserSession = false
            self.session = s
            if !s.start() {
                cont.resume(throwing: DriveError("Không mở được trang đăng nhập Google."))
            }
        }
        session = nil

        let items = URLComponents(url: callback, resolvingAgainstBaseURL: false)?.queryItems ?? []
        func val(_ n: String) -> String? { items.first(where: { $0.name == n })?.value }
        if let e = val("error") { throw DriveError("Google báo lỗi: \(e)") }
        guard val("state") == state, let code = val("code") else {
            throw DriveError("Phản hồi đăng nhập không hợp lệ.")
        }

        let t = try await DriveHTTP.token([
            "client_id": DriveConfig.clientID,
            "code": code,
            "code_verifier": verifier,
            "redirect_uri": DriveConfig.redirectURI,
            "grant_type": "authorization_code"
        ])
        guard let refresh = t.refreshToken else {
            throw DriveError("Google không cấp quyền truy cập lâu dài. Hãy thử đăng nhập lại.")
        }
        DriveKeychain.set(refresh, for: "refresh")
        await DriveClient.shared.setToken(t.accessToken, expiresIn: t.expiresIn)
        let email = (try? await DriveClient.shared.userEmail()) ?? "Đã đăng nhập"
        UserDefaults.standard.removeObject(forKey: DriveConfig.folderIDKey)
        UserDefaults.standard.removeObject(forKey: DriveConfig.rootIDKey)
        UserDefaults.standard.set(email, forKey: DriveConfig.emailKey)
    }

    static func signOut() async {
        DriveKeychain.remove("refresh")
        UserDefaults.standard.removeObject(forKey: DriveConfig.emailKey)
        UserDefaults.standard.removeObject(forKey: DriveConfig.folderIDKey)
        UserDefaults.standard.removeObject(forKey: DriveConfig.rootIDKey)
        await DriveClient.shared.clearToken()
    }
}

// MARK: - Drive REST API

private struct DriveFile: Decodable {
    let id: String
    let name: String?
    let trashed: Bool?
}
private struct DriveFileList: Decodable { let files: [DriveFile] }

struct DriveBackup: Identifiable, Decodable {
    let id: String
    let name: String
    let size: String?
    let modifiedTime: String?

    var detail: String {
        var parts: [String] = []
        if let t = modifiedTime {
            let f1 = ISO8601DateFormatter()
            f1.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            let f2 = ISO8601DateFormatter()
            if let d = f1.date(from: t) ?? f2.date(from: t) {
                let o = DateFormatter()
                o.dateFormat = "dd/MM/yyyy HH:mm"
                parts.append(o.string(from: d))
            }
        }
        if let sz = size, let n = Int(sz) { parts.append(formatBytes(n)) }
        return parts.joined(separator: " · ")
    }
}
private struct DriveBackupList: Decodable { let files: [DriveBackup] }
private struct UserInfo: Decodable { let email: String? }

/// Cờ chặn các cập nhật tiến trình đến muộn sau khi việc đã xong (chỉ dùng trên luồng chính).
final class ProgressGate: @unchecked Sendable { var open = true }

/// Báo % tải về / tải lên cho một request (0...1).
final class DownloadProgressDelegate: NSObject, URLSessionDownloadDelegate, URLSessionTaskDelegate {
    private let expected: Int64
    private let onProgress: ((Double) -> Void)?
    init(expected: Int64 = 0, onProgress: ((Double) -> Void)?) {
        self.expected = expected
        self.onProgress = onProgress
    }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64,
                    totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        let total = totalBytesExpectedToWrite > 0 ? totalBytesExpectedToWrite : expected
        if total > 0 { onProgress?(min(1, Double(totalBytesWritten) / Double(total))) }
    }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {}
    func urlSession(_ session: URLSession, task: URLSessionTask, didSendBodyData bytesSent: Int64,
                    totalBytesSent: Int64, totalBytesExpectedToSend: Int64) {
        if totalBytesExpectedToSend > 0 { onProgress?(min(1, Double(totalBytesSent) / Double(totalBytesExpectedToSend))) }
    }
}

actor DriveClient {
    static let shared = DriveClient()

    private var token: String?
    private var expiry = Date.distantPast

    private let session: URLSession = {
        let c = URLSessionConfiguration.default
        c.timeoutIntervalForRequest = 120
        c.timeoutIntervalForResource = 3600
        c.waitsForConnectivity = true
        return URLSession(configuration: c)
    }()

    func setToken(_ t: String, expiresIn: Int) {
        token = t
        expiry = Date().addingTimeInterval(Double(expiresIn))
    }
    func clearToken() { token = nil; expiry = .distantPast }

    private func accessToken() async throws -> String {
        if let t = token, expiry > Date().addingTimeInterval(60) { return t }
        guard let rt = DriveKeychain.get("refresh") else {
            throw DriveError("Chưa đăng nhập Google Drive.")
        }
        do {
            let r = try await DriveHTTP.token([
                "client_id": DriveConfig.clientID,
                "refresh_token": rt,
                "grant_type": "refresh_token"
            ])
            setToken(r.accessToken, expiresIn: r.expiresIn)
            return r.accessToken
        } catch {
            if error.localizedDescription.contains("hết hạn") {
                await DriveSignIn.signOut()
            }
            throw error
        }
    }

    private func send(_ req: URLRequest, ok: Set<Int> = [200, 201, 204]) async throws -> (Data, HTTPURLResponse) {
        var r = req
        r.setValue("Bearer " + (try await accessToken()), forHTTPHeaderField: "Authorization")
        let (d, resp) = try await session.data(for: r)
        guard let h = resp as? HTTPURLResponse else { throw DriveError("Không kết nối được Google Drive.") }
        guard ok.contains(h.statusCode) else {
            if h.statusCode == 401 { clearToken() }
            let body = String(data: d, encoding: .utf8) ?? ""
            throw DriveError("Google Drive báo lỗi \(h.statusCode). \(body.prefix(160))")
        }
        return (d, h)
    }

    func userEmail() async throws -> String? {
        let (d, _) = try await send(URLRequest(url: URL(string: "https://www.googleapis.com/oauth2/v3/userinfo")!))
        return (try? JSONDecoder().decode(UserInfo.self, from: d))?.email
    }

    private func listFiles(query: String, fields: String = "files(id,name,trashed)",
                           orderBy: String? = nil) async throws -> [DriveFile] {
        var c = URLComponents(string: "https://www.googleapis.com/drive/v3/files")!
        var qi = [URLQueryItem(name: "q", value: query),
                  URLQueryItem(name: "fields", value: fields),
                  URLQueryItem(name: "pageSize", value: "100"),
                  URLQueryItem(name: "spaces", value: "drive")]
        if let o = orderBy { qi.append(URLQueryItem(name: "orderBy", value: o)) }
        c.queryItems = qi
        let (d, _) = try await send(URLRequest(url: c.url!))
        return (try JSONDecoder().decode(DriveFileList.self, from: d)).files
    }

    private func ensureFolder() async throws -> String {
        let ud = UserDefaults.standard
        if let id = ud.string(forKey: DriveConfig.folderIDKey) {
            var c = URLComponents(string: "https://www.googleapis.com/drive/v3/files/\(id)")!
            c.queryItems = [URLQueryItem(name: "fields", value: "id,trashed")]
            if let (d, _) = try? await send(URLRequest(url: c.url!)),
               let f = try? JSONDecoder().decode(DriveFile.self, from: d), f.trashed != true {
                return id
            }
        }
        let mime = "application/vnd.google-apps.folder"
        let found = try await listFiles(
            query: "name = '\(DriveConfig.folderName)' and mimeType = '\(mime)' and trashed = false")
        if let f = found.first {
            ud.set(f.id, forKey: DriveConfig.folderIDKey)
            return f.id
        }
        var r = URLRequest(url: URL(string: "https://www.googleapis.com/drive/v3/files?fields=id")!)
        r.httpMethod = "POST"
        r.setValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        r.httpBody = try JSONSerialization.data(withJSONObject: ["name": DriveConfig.folderName, "mimeType": mime])
        let (d, _) = try await send(r)
        let f = try JSONDecoder().decode(DriveFile.self, from: d)
        ud.set(f.id, forKey: DriveConfig.folderIDKey)
        return f.id
    }

    func listBackups() async throws -> [DriveBackup] {
        let folder = try await ensureFolder()
        var c = URLComponents(string: "https://www.googleapis.com/drive/v3/files")!
        c.queryItems = [
            URLQueryItem(name: "q", value: "'\(folder)' in parents and trashed = false"),
            URLQueryItem(name: "fields", value: "files(id,name,size,modifiedTime)"),
            URLQueryItem(name: "orderBy", value: "name desc"),
            URLQueryItem(name: "pageSize", value: "100")
        ]
        let (d, _) = try await send(URLRequest(url: c.url!))
        return try JSONDecoder().decode(DriveBackupList.self, from: d).files
            .filter { $0.name.hasSuffix(".zip") }
    }

    func deleteBackup(_ id: String) async throws {
        var r = URLRequest(url: URL(string: "https://www.googleapis.com/drive/v3/files/\(id)")!)
        r.httpMethod = "DELETE"
        _ = try await send(r)
    }

    /// Tải bản sao lưu về thư mục tạm của máy, trả về đường dẫn file.
    func downloadBackup(_ b: DriveBackup, onProgress: ((Double) -> Void)? = nil) async throws -> URL {
        var r = URLRequest(url: URL(string: "https://www.googleapis.com/drive/v3/files/\(b.id)?alt=media")!)
        r.setValue("Bearer " + (try await accessToken()), forHTTPHeaderField: "Authorization")
        let (tmp, resp) = try await session.download(for: r, delegate: DownloadProgressDelegate(
            expected: Int64(b.size ?? "") ?? 0, onProgress: onProgress))
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        guard code == 200 else { throw DriveError("Tải về thất bại (\(code)).") }
        let fm = FileManager.default
        let dir = fm.temporaryDirectory.appendingPathComponent("drive-\(b.id)", isDirectory: true)
        try? fm.removeItem(at: dir)
        try fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let dst = dir.appendingPathComponent(b.name)
        try fm.moveItem(at: tmp, to: dst)
        return dst
    }

    /// Tải file zip lên thư mục "RSIScan Backup", giữ lại DriveConfig.keep bản mới nhất.
    func upload(_ zip: URL, onProgress: ((Double) -> Void)? = nil) async throws -> String {
        let folder = try await ensureFolder()
        let name = zip.lastPathComponent
        let size = (try? FileManager.default.attributesOfItem(atPath: zip.path)[.size] as? Int) ?? 0

        var start = URLRequest(url: URL(string: "https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields=id,name")!)
        start.httpMethod = "POST"
        start.setValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        start.setValue("application/zip", forHTTPHeaderField: "X-Upload-Content-Type")
        start.setValue(String(size), forHTTPHeaderField: "X-Upload-Content-Length")
        start.httpBody = try JSONSerialization.data(withJSONObject: ["name": name, "parents": [folder]])
        let (_, h) = try await send(start)
        guard let loc = h.value(forHTTPHeaderField: "Location"), let putURL = URL(string: loc) else {
            throw DriveError("Google Drive không cấp địa chỉ tải lên.")
        }

        var put = URLRequest(url: putURL)
        put.httpMethod = "PUT"
        put.setValue("application/zip", forHTTPHeaderField: "Content-Type")
        let (d, resp) = try await session.upload(for: put, fromFile: zip,
                                                 delegate: DownloadProgressDelegate(onProgress: onProgress))
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        guard code == 200 || code == 201 else {
            let body = String(data: d, encoding: .utf8) ?? ""
            throw DriveError("Tải lên Google Drive thất bại (\(code)). \(body.prefix(160))")
        }

        // Xoá các bản cũ (lỗi ở bước này không làm hỏng bản vừa sao lưu)
        if let all = try? await listFiles(
            query: "'\(folder)' in parents and trashed = false and name contains 'RSIScan-'",
            orderBy: "name desc") {
            let olds = all.filter { ($0.name ?? "").hasPrefix("RSIScan-") && ($0.name ?? "").hasSuffix(".zip") }
            for f in olds.dropFirst(DriveConfig.keep) {
                var del = URLRequest(url: URL(string: "https://www.googleapis.com/drive/v3/files/\(f.id)")!)
                del.httpMethod = "DELETE"
                _ = try? await send(del)
            }
        }
        return name
    }
}

// MARK: - Lưu phiếu trực tiếp lên Drive (thư mục, ảnh, slip.json)

struct DriveChild: Decodable {
    let id: String
    let name: String
    let mimeType: String?
}
private struct DriveChildList: Decodable {
    let files: [DriveChild]
    let nextPageToken: String?
}

extension DriveClient {
    static let folderMime = "application/vnd.google-apps.folder"

    func exists(_ id: String) async -> Bool {
        var c = URLComponents(string: "https://www.googleapis.com/drive/v3/files/\(id)")!
        c.queryItems = [URLQueryItem(name: "fields", value: "id,trashed")]
        guard let (d, _) = try? await send(URLRequest(url: c.url!)),
              let f = try? JSONDecoder().decode(DriveFile.self, from: d) else { return false }
        return f.trashed != true
    }

    func createFolder(name: String, parent: String?) async throws -> String {
        var r = URLRequest(url: URL(string: "https://www.googleapis.com/drive/v3/files?fields=id")!)
        r.httpMethod = "POST"
        r.setValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        var body: [String: Any] = ["name": name, "mimeType": DriveClient.folderMime]
        if let p = parent { body["parents"] = [p] }
        r.httpBody = try JSONSerialization.data(withJSONObject: body)
        let (d, _) = try await send(r)
        return try JSONDecoder().decode(DriveFile.self, from: d).id
    }

    /// Thư mục gốc "RSIScan" (tạo nếu chưa có).
    func ensureRoot() async throws -> String {
        let ud = UserDefaults.standard
        if let id = ud.string(forKey: DriveConfig.rootIDKey) {
            let ok = await exists(id)
            if ok { return id }
        }
        let found = try await listFiles(
            query: "name = '\(DriveConfig.rootName)' and mimeType = '\(DriveClient.folderMime)' and trashed = false")
        if let f = found.first {
            ud.set(f.id, forKey: DriveConfig.rootIDKey)
            return f.id
        }
        let id = try await createFolder(name: DriveConfig.rootName, parent: nil)
        ud.set(id, forKey: DriveConfig.rootIDKey)
        return id
    }

    @discardableResult
    func rename(_ id: String, to name: String) async -> Bool {
        var r = URLRequest(url: URL(string: "https://www.googleapis.com/drive/v3/files/\(id)?fields=id")!)
        r.httpMethod = "PATCH"
        r.setValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        r.httpBody = try? JSONSerialization.data(withJSONObject: ["name": name])
        return (try? await send(r)) != nil
    }

    /// Tải một file nhỏ (ảnh JPEG, json) lên. Có existingID thì ghi đè nội dung file đó.
    func uploadData(name: String, mime: String, data: Data, parent: String?,
                    existingID: String?) async throws -> String {
        let boundary = "rsi-" + UUID().uuidString
        var meta: [String: Any] = ["name": name]
        if existingID == nil, let p = parent { meta["parents"] = [p] }
        let metaData = try JSONSerialization.data(withJSONObject: meta)
        var body = Data()
        body.append(Data("--\(boundary)\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n".utf8))
        body.append(metaData)
        body.append(Data("\r\n--\(boundary)\r\nContent-Type: \(mime)\r\n\r\n".utf8))
        body.append(data)
        body.append(Data("\r\n--\(boundary)--".utf8))

        let base = "https://www.googleapis.com/upload/drive/v3/files"
        var r: URLRequest
        if let id = existingID {
            r = URLRequest(url: URL(string: "\(base)/\(id)?uploadType=multipart&fields=id")!)
            r.httpMethod = "PATCH"
        } else {
            r = URLRequest(url: URL(string: "\(base)?uploadType=multipart&fields=id")!)
            r.httpMethod = "POST"
        }
        r.setValue("multipart/related; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        r.httpBody = body
        do {
            let (d, _) = try await send(r)
            return try JSONDecoder().decode(DriveFile.self, from: d).id
        } catch {
            // file cũ đã bị xoá trên Drive: tạo file mới
            if existingID != nil && error.localizedDescription.contains("404") {
                return try await uploadData(name: name, mime: mime, data: data, parent: parent, existingID: nil)
            }
            throw error
        }
    }

    func downloadData(_ id: String) async throws -> Data {
        let url = URL(string: "https://www.googleapis.com/drive/v3/files/\(id)?alt=media")!
        let (d, _) = try await send(URLRequest(url: url), ok: [200])
        return d
    }

    func deleteFile(_ id: String) async throws {
        var r = URLRequest(url: URL(string: "https://www.googleapis.com/drive/v3/files/\(id)")!)
        r.httpMethod = "DELETE"
        _ = try await send(r, ok: [200, 204, 404])
    }

    func listChildren(_ folder: String) async throws -> [DriveChild] {
        var out: [DriveChild] = []
        var page: String? = nil
        repeat {
            var c = URLComponents(string: "https://www.googleapis.com/drive/v3/files")!
            var qi = [URLQueryItem(name: "q", value: "'\(folder)' in parents and trashed = false"),
                      URLQueryItem(name: "fields", value: "nextPageToken,files(id,name,mimeType)"),
                      URLQueryItem(name: "pageSize", value: "200"),
                      URLQueryItem(name: "spaces", value: "drive")]
            if let p = page { qi.append(URLQueryItem(name: "pageToken", value: p)) }
            c.queryItems = qi
            let (d, _) = try await send(URLRequest(url: c.url!))
            let r = try JSONDecoder().decode(DriveChildList.self, from: d)
            out.append(contentsOf: r.files)
            page = r.nextPageToken
        } while page != nil
        return out
    }
}

// MARK: - Chỉ mục toàn bộ phiếu (index.json trong thư mục gốc) để tải lại nhanh

extension DriveClient {
    static let indexName = "index.json"

    func findIndexID(root: String) async throws -> String? {
        let l = try await listFiles(query: "name = '\(DriveClient.indexName)' and '\(root)' in parents and trashed = false")
        return l.first?.id
    }
}

// MARK: - Nối vào Store

extension Store {
    var hasDrive: Bool { DriveConfig.signedIn }

    @MainActor
    func setProgress(_ p: TransferProgress?) { progress = p }

    func backupToDrive() async -> String {
        await setProgress(TransferProgress(title: "Đang tạo file sao lưu", detail: "đóng gói ảnh và dữ liệu..."))
        guard let zip = exportAll() else {
            await setProgress(nil)
            return "Không tạo được file sao lưu."
        }
        defer { try? FileManager.default.removeItem(at: zip) }
        let live = ProgressGate()
        defer { Task { @MainActor in live.open = false; self.progress = nil } }
        do {
            await setProgress(TransferProgress(title: "Đang tải bản sao lưu lên Drive", done: 0, total: 100, detail: "0%"))
            let name = try await DriveClient.shared.upload(zip) { f in
                Task { @MainActor in
                    guard live.open else { return }
                    self.progress = TransferProgress(title: "Đang tải bản sao lưu lên Drive",
                                                     done: Int(f * 100), total: 100, detail: "\(Int(f * 100))%")
                }
            }
            UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: BackupPrefs.lastKey)
            return "Đã sao lưu lên Google Drive: \(name)"
        } catch {
            return error.localizedDescription
        }
    }

    /// Đã đăng nhập Google -> sao lưu lên Drive; chưa thì dùng thư mục đã chọn trong Tệp.
    func backupAny() async -> String {
        // ảnh đã chuyển lên Drive thì tải về tạm để file sao lưu đủ ảnh
        let names = await MainActor.run { self.slips.flatMap { $0.pages } }
        await ensureLocal(names)   // có hiện tiến trình từng ảnh
        if hasDrive { return await backupToDrive() }
        return backupNow()
    }
}


// MARK: - Màn hình quản lý bản sao lưu trên Drive

struct ShareItem: Identifiable {
    let id = UUID()
    let url: URL
}

struct ShareSheet: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

struct DriveBackupsView: View {
    @EnvironmentObject var store: Store
    @State private var items: [DriveBackup] = []
    @State private var loading = false
    @State private var busy = false
    @State private var message: String? = nil
    @State private var share: ShareItem? = nil
    @State private var toDelete: DriveBackup? = nil
    @State private var toRestore: DriveBackup? = nil
    @State private var progress: TransferProgress? = nil

    var body: some View {
        List {
            if let m = message {
                Text(m).font(.caption).foregroundColor(Theme.primaryDark)
            }
            if let p = progress { ProgressCard(p: p) }
            else if loading || busy { ProgressView() }
            if !loading && items.isEmpty {
                Text("Chưa có bản sao lưu nào trên Drive.").foregroundColor(.secondary)
            }
            ForEach(items) { b in
                VStack(alignment: .leading, spacing: 6) {
                    Text(b.name).font(.subheadline)
                    Text(b.detail).font(.caption).foregroundColor(.secondary)
                    HStack(spacing: 18) {
                        Button { download(b) } label: { Label("Tải về", systemImage: "arrow.down.circle") }
                        Button { toRestore = b } label: { Label("Khôi phục", systemImage: "arrow.counterclockwise") }
                        Button(role: .destructive) { toDelete = b } label: { Label("Xoá", systemImage: "trash") }
                    }
                    .font(.footnote)
                    .buttonStyle(.borderless)
                }
                .padding(.vertical, 4)
                .disabled(busy)
            }
        }
        .navigationTitle("Bản sao lưu trên Drive")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button { Task { await load() } } label: { Image(systemName: "arrow.clockwise") }
                    .disabled(loading || busy)
            }
        }
        .task { await load() }
        .refreshable { await load() }
        .sheet(item: $share) { item in ShareSheet(url: item.url) }
        .appDialog(item: $toDelete,
                   content: { b in DialogContent(title: "Xoá bản sao lưu này?",
                                                 message: b.name + "\nSẽ bị xoá khỏi Google Drive.",
                                                 confirmTitle: "Xoá") },
                   action: { b in remove(b) })
        .appDialog(item: $toRestore,
                   content: { _ in DialogContent(icon: "arrow.counterclockwise",
                                                 title: "Khôi phục từ bản sao lưu này?",
                                                 message: "Các phiếu chưa có trong máy sẽ được thêm vào, phiếu đã có giữ nguyên.",
                                                 confirmTitle: "Khôi phục", destructive: false) },
                   action: { b in restore(b) })
    }

    func load() async {
        loading = true
        do { items = try await DriveClient.shared.listBackups() }
        catch { message = error.localizedDescription }
        loading = false
    }

    func download(_ b: DriveBackup) {
        busy = true; message = nil
        let live = ProgressGate()
        Task {
            do {
                let url = try await DriveClient.shared.downloadBackup(b) { f in
                    Task { @MainActor in
                        guard live.open else { return }
                        progress = TransferProgress(title: "Đang tải bản sao lưu về", done: Int(f * 100),
                                                    total: 100, detail: "\(Int(f * 100))%")
                    }
                }
                share = ShareItem(url: url)
            } catch { message = error.localizedDescription }
            live.open = false
            progress = nil
            busy = false
        }
    }

    func remove(_ b: DriveBackup) {
        busy = true; message = nil
        Task {
            do {
                try await DriveClient.shared.deleteBackup(b.id)
                items.removeAll { $0.id == b.id }
                message = "Đã xoá \(b.name)"
            } catch { message = error.localizedDescription }
            busy = false
        }
    }

    func restore(_ b: DriveBackup) {
        busy = true; message = nil
        let st = store
        let ids = Set(store.slips.map { $0.id })
        let live = ProgressGate()
        func show(_ p: TransferProgress?) {
            Task { @MainActor in
                guard live.open else { return }
                progress = p
            }
        }
        Task {
            show(TransferProgress(title: "Đang tải bản sao lưu về", done: 0, total: 100, detail: "0%"))
            do {
                let url = try await DriveClient.shared.downloadBackup(b) { f in
                    show(TransferProgress(title: "Đang tải bản sao lưu về", done: Int(f * 100), total: 100,
                                          detail: "\(Int(f * 100))%"))
                }
                show(TransferProgress(title: "Đang khôi phục phiếu", detail: "đang đọc file..."))
                let r = await Task.detached(priority: .userInitiated) {
                    st.prepareImport(url: url, existingIDs: ids) { done, total in
                        show(TransferProgress(title: "Đang khôi phục phiếu", done: done, total: total, detail: "phiếu"))
                    }
                }.value
                if !r.slips.isEmpty {
                    st.slips.append(contentsOf: r.slips)
                    st.persist()
                    st.syncSoon()   // phiếu khôi phục chưa có trên Drive chính thì tự đưa lên
                }
                message = r.message
                try? FileManager.default.removeItem(at: url.deletingLastPathComponent())
            } catch { message = error.localizedDescription }
            live.open = false
            progress = nil
            busy = false
        }
    }
}
