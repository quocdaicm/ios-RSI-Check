import SwiftUI
import UIKit
import AVFoundation
import Vision
import CoreImage
import CoreImage.CIFilterBuiltins

// MARK: - Khoá / mở xoay màn hình (app chạy dọc, riêng màn hình quét cho xoay ngang)

final class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication,
                     supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
        OrientationLock.mask
    }
}

enum OrientationLock {
    static var mask: UIInterfaceOrientationMask = .portrait

    static func set(_ m: UIInterfaceOrientationMask) {
        mask = m
        guard let scene = UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }).first else { return }
        scene.windows.first?.rootViewController?.setNeedsUpdateOfSupportedInterfaceOrientations()
        if m == .portrait {
            scene.requestGeometryUpdate(.iOS(interfaceOrientations: .portrait)) { _ in }
        }
    }
}

// MARK: - Khung 4 góc kéo được

final class QuadView: UIView {
    private(set) var pts: [CGPoint] = []          // tl, tr, br, bl (toạ độ trong view)
    private let shape = CAShapeLayer()
    private var handles: [UIView] = []

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        shape.strokeColor = UIColor(red: 0.2, green: 0.85, blue: 0.5, alpha: 1).cgColor
        shape.fillColor = UIColor(red: 0.2, green: 0.85, blue: 0.5, alpha: 0.15).cgColor
        shape.lineWidth = 2.5
        layer.addSublayer(shape)
        for _ in 0..<4 {
            let h = UIView(frame: CGRect(x: 0, y: 0, width: 48, height: 48))
            h.backgroundColor = .clear
            let dot = UIView(frame: CGRect(x: 12, y: 12, width: 24, height: 24))
            dot.backgroundColor = .white
            dot.layer.cornerRadius = 12
            dot.layer.borderWidth = 3
            dot.layer.borderColor = UIColor(red: 0.2, green: 0.85, blue: 0.5, alpha: 1).cgColor
            dot.isUserInteractionEnabled = false
            h.addSubview(dot)
            h.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(pan(_:))))
            addSubview(h)
            handles.append(h)
        }
    }
    required init?(coder: NSCoder) { fatalError() }

    func setPoints(_ p: [CGPoint]) {
        pts = p
        refresh()
    }

    private func refresh() {
        guard pts.count == 4 else { return }
        let path = UIBezierPath()
        path.move(to: pts[0])
        for i in 1..<4 { path.addLine(to: pts[i]) }
        path.close()
        shape.path = path.cgPath
        for i in 0..<4 { handles[i].center = pts[i] }
    }

    @objc private func pan(_ g: UIPanGestureRecognizer) {
        guard let h = g.view, let i = handles.firstIndex(of: h), pts.count == 4 else { return }
        let t = g.translation(in: self)
        g.setTranslation(.zero, in: self)
        pts[i].x = min(max(pts[i].x + t.x, 0), bounds.width)
        pts[i].y = min(max(pts[i].y + t.y, 0), bounds.height)
        refresh()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        shape.frame = bounds
    }
}

// MARK: - Màn hình camera tự chỉnh khung rồi bấm chụp

final class CameraScanVC: UIViewController, AVCapturePhotoCaptureDelegate, AVCaptureVideoDataOutputSampleBufferDelegate {
    var onFinish: (([UIImage]) -> Void)?
    var onCancel: (() -> Void)?

    private let session = AVCaptureSession()
    private let photoOut = AVCapturePhotoOutput()
    private let videoOut = AVCaptureVideoDataOutput()
    private let queue = DispatchQueue(label: "rsiscan.camera")
    private let preview = AVCaptureVideoPreviewLayer()
    private let quadView = QuadView()
    private var configured = false

    private let hint = UILabel()
    private let cancelBtn = UIButton(type: .system)
    private let autoBtn = UIButton(type: .system)
    private let shutter = UIButton(type: .custom)
    private let undoBtn = UIButton(type: .system)
    private let doneBtn = UIButton(type: .system)

    private var images: [UIImage] = []
    private var pendingPts: [CGPoint] = []
    private var pendingSize: CGSize = .zero
    private var detected: (quad: [CGPoint], size: CGSize)?
    private var lastDetect = Date.distantPast      // chỉ dùng trên luồng video
    private var lastLayoutSize: CGSize = .zero

    override var prefersStatusBarHidden: Bool { true }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        preview.videoGravity = .resizeAspect
        view.layer.addSublayer(preview)
        view.addSubview(quadView)

        hint.text = "Kéo 4 góc cho khớp tờ giấy rồi bấm nút chụp"
        hint.textColor = .white
        hint.font = .systemFont(ofSize: 13, weight: .medium)
        hint.textAlignment = .center
        hint.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        hint.layer.cornerRadius = 10
        hint.clipsToBounds = true
        hint.numberOfLines = 2
        view.addSubview(hint)

        func style(_ b: UIButton, _ title: String, _ sel: Selector) {
            b.setTitle(title, for: .normal)
            b.setTitleColor(.white, for: .normal)
            b.titleLabel?.font = .systemFont(ofSize: 15, weight: .semibold)
            b.addTarget(self, action: sel, for: .touchUpInside)
            view.addSubview(b)
        }
        style(cancelBtn, "Huỷ", #selector(cancelTapped))
        style(autoBtn, "Tự dò", #selector(autoFit))
        style(undoBtn, "Xoá cuối", #selector(undoTapped))
        style(doneBtn, "Xong", #selector(doneTapped))
        undoBtn.isHidden = true
        doneBtn.isHidden = true

        shutter.backgroundColor = .white
        shutter.layer.cornerRadius = 35
        shutter.layer.borderWidth = 5
        shutter.layer.borderColor = UIColor(white: 0.3, alpha: 1).cgColor
        shutter.addTarget(self, action: #selector(shutterTapped), for: .touchUpInside)
        view.addSubview(shutter)

        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            configure()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { ok in
                DispatchQueue.main.async { ok ? self.configure() : self.denied() }
            }
        default:
            denied()
        }
    }

    private func denied() {
        hint.text = "Chưa cấp quyền camera. Vào Cài đặt iPhone > Phiếu RSI để bật."
        shutter.isEnabled = false
        autoBtn.isEnabled = false
    }

    private func configure() {
        guard !configured else { return }
        guard let dev = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
              let input = try? AVCaptureDeviceInput(device: dev) else {
            hint.text = "Không mở được camera."
            shutter.isEnabled = false
            return
        }
        session.beginConfiguration()
        session.sessionPreset = .photo
        if session.canAddInput(input) { session.addInput(input) }
        if session.canAddOutput(photoOut) { session.addOutput(photoOut) }
        photoOut.maxPhotoQualityPrioritization = .quality
        videoOut.alwaysDiscardsLateVideoFrames = true
        videoOut.setSampleBufferDelegate(self, queue: queue)
        if session.canAddOutput(videoOut) { session.addOutput(videoOut) }
        session.commitConfiguration()
        preview.session = session
        configured = true
        applyOrientation()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        applyOrientation()
        queue.async { [session] in
            if !session.isRunning { session.startRunning() }
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        queue.async { [session] in
            if session.isRunning { session.stopRunning() }
        }
    }

    // MARK: Xoay màn hình

    private var videoOrientation: AVCaptureVideoOrientation {
        switch view.window?.windowScene?.interfaceOrientation ?? .portrait {
        case .landscapeLeft: return .landscapeLeft
        case .landscapeRight: return .landscapeRight
        case .portraitUpsideDown: return .portraitUpsideDown
        default: return .portrait
        }
    }

    private func applyOrientation() {
        guard configured else { return }
        let o = videoOrientation
        for c in [preview.connection, photoOut.connection(with: .video), videoOut.connection(with: .video)] {
            if let c = c, c.isVideoOrientationSupported { c.videoOrientation = o }
        }
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        coordinator.animate(alongsideTransition: nil) { _ in
            self.applyOrientation()
            self.view.setNeedsLayout()
        }
    }

    // MARK: Bố cục

    static func fitRect(_ size: CGSize, in bounds: CGRect) -> CGRect {
        guard size.width > 0, size.height > 0 else { return bounds }
        let k = min(bounds.width / size.width, bounds.height / size.height)
        let w = size.width * k, h = size.height * k
        return CGRect(x: bounds.midX - w / 2, y: bounds.midY - h / 2, width: w, height: h)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let b = view.bounds
        let s = view.safeAreaInsets
        let landscape = b.width > b.height
        let bar: CGFloat = 110
        let area: CGRect
        if landscape {
            area = CGRect(x: s.left, y: 0, width: b.width - bar - s.left - s.right, height: b.height)
        } else {
            area = CGRect(x: 0, y: s.top, width: b.width, height: b.height - bar - s.top - s.bottom)
        }
        preview.frame = area
        quadView.frame = area

        hint.frame = CGRect(x: area.minX + 12, y: area.minY + 8,
                            width: min(area.width - 24, 360), height: 40)

        let items: [UIView] = [cancelBtn, autoBtn, shutter, undoBtn, doneBtn]
        for (i, v) in items.enumerated() {
            v.bounds = CGRect(x: 0, y: 0, width: v === shutter ? 70 : 76, height: v === shutter ? 70 : 44)
            if landscape {
                let h = b.height - s.top - s.bottom
                v.center = CGPoint(x: area.maxX + bar / 2, y: s.top + (CGFloat(i) + 0.5) * h / 5)
            } else {
                v.center = CGPoint(x: (CGFloat(i) + 0.5) * b.width / 5, y: area.maxY + bar / 2)
            }
        }

        if lastLayoutSize != area.size {
            lastLayoutSize = area.size
            resetQuad()
        }
    }

    private func resetQuad() {
        let bounds = quadView.bounds
        let landscape = bounds.width > bounds.height
        let content = CameraScanVC.fitRect(landscape ? CGSize(width: 4, height: 3) : CGSize(width: 3, height: 4), in: bounds)
        let r = content.insetBy(dx: content.width * 0.07, dy: content.height * 0.07)
        quadView.setPoints([CGPoint(x: r.minX, y: r.minY), CGPoint(x: r.maxX, y: r.minY),
                            CGPoint(x: r.maxX, y: r.maxY), CGPoint(x: r.minX, y: r.maxY)])
    }

    // MARK: Nút

    @objc private func cancelTapped() { onCancel?() }

    @objc private func doneTapped() {
        if images.isEmpty { onCancel?() } else { onFinish?(images) }
    }

    @objc private func undoTapped() {
        guard !images.isEmpty else { return }
        images.removeLast()
        updateButtons()
    }

    @objc private func autoFit() {
        guard let d = detected else {
            hint.text = "Chưa dò được tờ giấy, hãy kéo 4 góc bằng tay."
            return
        }
        let rect = CameraScanVC.fitRect(d.size, in: quadView.bounds)
        // nới ra một chút: Vision hay dò ra khung bảng, bỏ sót phần đầu phiếu (số RSI)
        let wide = Rectifier.expand(d.quad, by: 0.2)
        quadView.setPoints(wide.map {
            CGPoint(x: rect.minX + $0.x * rect.width, y: rect.minY + (1 - $0.y) * rect.height)
        })
    }

    private func updateButtons() {
        undoBtn.isHidden = images.isEmpty
        doneBtn.isHidden = images.isEmpty
        doneBtn.setTitle("Xong (\(images.count))", for: .normal)
        shutter.isEnabled = images.count < Store.maxPages
        shutter.alpha = shutter.isEnabled ? 1 : 0.4
        hint.text = images.count >= Store.maxPages
            ? "Đã đủ \(Store.maxPages) ảnh, bấm Xong."
            : "Đã chụp \(images.count) tờ. Chỉnh khung cho tờ tiếp theo hoặc bấm Xong."
    }

    @objc private func shutterTapped() {
        guard configured, images.count < Store.maxPages else { return }
        shutter.isEnabled = false
        pendingPts = quadView.pts
        pendingSize = quadView.bounds.size
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        applyOrientation()
        let settings = AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.jpeg])
        if photoOut.supportedFlashModes.contains(.off) { settings.flashMode = .off }
        settings.photoQualityPrioritization = .quality
        photoOut.capturePhoto(with: settings, delegate: self)
    }

    // MARK: Chụp xong -> cắt theo khung người dùng chỉnh

    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        let pts = pendingPts, viewSize = pendingSize
        var result: UIImage? = nil
        if error == nil, let data = photo.fileDataRepresentation(), let raw = UIImage(data: data) {
            let upright = raw.normalized(maxSide: 3200)      // đúng chiều như đang cầm máy (ngang/dọc)
            result = CameraScanVC.crop(upright, pts: pts, viewSize: viewSize)
        }
        DispatchQueue.main.async {
            if let r = result { self.images.append(r) }
            self.updateButtons()
            self.shutter.isEnabled = self.images.count < Store.maxPages
        }
    }

    static func crop(_ img: UIImage, pts: [CGPoint], viewSize: CGSize) -> UIImage {
        guard pts.count == 4, let cg = img.cgImage else { return img }
        let rect = fitRect(img.size, in: CGRect(origin: .zero, size: viewSize))
        guard rect.width > 0, rect.height > 0 else { return img }
        let np = pts.map {
            CGPoint(x: min(max(($0.x - rect.minX) / rect.width, 0), 1),
                    y: min(max(($0.y - rect.minY) / rect.height, 0), 1))
        }
        // Sắp xếp góc theo vị trí trên màn hình để ảnh ra luôn đúng chiều đang nhìn
        guard let tl = np.min(by: { $0.x + $0.y < $1.x + $1.y }),
              let br = np.max(by: { $0.x + $0.y < $1.x + $1.y }),
              let tr = np.max(by: { $0.x - $0.y < $1.x - $1.y }),
              let bl = np.min(by: { $0.x - $0.y < $1.x - $1.y }) else { return img }
        let q = [tl, tr, br, bl]
        var area: CGFloat = 0
        for i in 0..<4 {
            let a = q[i], b = q[(i + 1) % 4]
            area += a.x * b.y - b.x * a.y
        }
        if abs(area) / 2 < 0.04 { return img }       // khung quá nhỏ/lệch -> giữ nguyên ảnh

        let w = CGFloat(cg.width), h = CGFloat(cg.height)
        func c(_ p: CGPoint) -> CGPoint { CGPoint(x: p.x * w, y: (1 - p.y) * h) }
        let f = CIFilter.perspectiveCorrection()
        f.inputImage = CIImage(cgImage: cg)
        f.topLeft = c(tl)
        f.topRight = c(tr)
        f.bottomRight = c(br)
        f.bottomLeft = c(bl)
        guard let out = f.outputImage,
              let res = CIContext().createCGImage(out, from: out.extent) else { return img }
        return UIImage(cgImage: res)
    }

    // MARK: Dò tờ giấy trên khung hình trực tiếp (chỉ để gợi ý nút "Tự dò")

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        let now = Date()
        guard now.timeIntervalSince(lastDetect) > 0.5,
              let pb = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        lastDetect = now
        let req = VNDetectDocumentSegmentationRequest()
        let handler = VNImageRequestHandler(cvPixelBuffer: pb, orientation: .up, options: [:])
        guard (try? handler.perform([req])) != nil,
              let o = req.results?.first, o.confidence > 0.5 else { return }
        let size = CGSize(width: CVPixelBufferGetWidth(pb), height: CVPixelBufferGetHeight(pb))
        let quad = [o.topLeft, o.topRight, o.bottomRight, o.bottomLeft]
        DispatchQueue.main.async { self.detected = (quad, size) }
    }
}

// MARK: - Cầu nối SwiftUI (giữ nguyên tên và cách gọi cũ)

struct DocumentScanner: UIViewControllerRepresentable {
    var onFinish: ([UIImage]) -> Void
    var onCancel: () -> Void

    func makeUIViewController(context: Context) -> CameraScanVC {
        OrientationLock.set(.allButUpsideDown)
        let vc = CameraScanVC()
        vc.onFinish = onFinish
        vc.onCancel = onCancel
        return vc
    }

    func updateUIViewController(_ vc: CameraScanVC, context: Context) {}

    static func dismantleUIViewController(_ vc: CameraScanVC, coordinator: Void) {
        OrientationLock.set(.portrait)
    }
}
