import SwiftUI

extension Item {
    /// Cùng một loại hàng: trùng mã kiện và trùng Tag/Serial (ví dụ cùng mã nhưng khác cỡ 54mm, 82mm thì coi là khác)
    func sameGoods(_ o: Item) -> Bool {
        func k(_ x: String) -> String { x.trimmingCharacters(in: .whitespaces).uppercased() }
        return !k(packageNo).isEmpty && k(packageNo) == k(o.packageNo) && k(tag) == k(o.tag)
    }

    var qtyValue: Double? {
        Double(qty.trimmingCharacters(in: .whitespaces).replacingOccurrences(of: ",", with: "."))
    }
}

struct IssueRecord: Identifiable {
    let slip: Slip
    let item: Item
    var id: UUID { item.id }
}

func formatQty(_ v: Double) -> String {
    v == v.rounded() ? String(Int(v)) : String(format: "%.2f", v)
}

extension Store {
    /// Tất cả các lần xuất của cùng loại hàng, qua mọi RSI (mới nhất trước)
    func history(for it: Item) -> [IssueRecord] {
        var out: [IssueRecord] = []
        for s in slipsNewestFirst() {
            for x in s.items where x.sameGoods(it) {
                out.append(IssueRecord(slip: s, item: x))
            }
        }
        return out
    }
}

func totalsText(_ recs: [IssueRecord]) -> String {
    var sums: [String: Double] = [:]
    var order: [String] = []
    for r in recs {
        guard let v = r.item.qtyValue else { continue }
        let u = r.item.unit.trimmingCharacters(in: .whitespaces).uppercased()
        if sums[u] == nil { order.append(u) }
        sums[u, default: 0] += v
    }
    if order.isEmpty { return "-" }
    return order.map { "\(formatQty(sums[$0] ?? 0)) \($0)" }.joined(separator: ", ")
}

struct PackageHistoryView: View {
    @EnvironmentObject var store: Store
    let item: Item

    var records: [IssueRecord] { store.history(for: item) }

    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 6) {
                    Text(item.packageNo).font(.title3.weight(.bold))
                    if !item.desc.isEmpty { Text(item.desc).font(.footnote).opacity(0.9) }
                    if !item.tag.isEmpty {
                        Chip(icon: "tag", text: item.tag, fg: .white, bg: Color.white.opacity(0.2))
                    }
                    Text("Đã xuất \(records.count) lần · tổng \(totalsText(records))")
                        .font(.subheadline.weight(.semibold))
                        .padding(.top, 4)
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(16)
                .background(Theme.heroGradient)
                .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))

                Text("Từng lần xuất theo RSI")
                    .font(.footnote.weight(.semibold))
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)

                ForEach(records) { r in
                    NavigationLink {
                        SlipDetailView(id: r.slip.id)
                    } label: {
                        HStack(spacing: 10) {
                            VStack(alignment: .leading, spacing: 3) {
                                Text(r.slip.rsiNo.isEmpty ? "(chưa có số)" : r.slip.rsiNo)
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundColor(.primary)
                                Text(r.slip.requestDate.isEmpty ? "-" : r.slip.requestDate)
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            Text("\(r.item.qty) \(r.item.unit)")
                                .font(.footnote.weight(.bold))
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(Theme.primarySoft)
                                .foregroundColor(Theme.primaryDark)
                                .clipShape(Capsule())
                            Image(systemName: "chevron.right")
                                .font(.footnote.weight(.semibold))
                                .foregroundColor(.secondary)
                        }
                        .padding(12)
                        .card()
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(16)
        }
        .background(Theme.bg.ignoresSafeArea())
        .navigationTitle("Lịch sử xuất")
        .navigationBarTitleDisplayMode(.inline)
    }
}
