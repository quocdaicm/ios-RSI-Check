import SwiftUI

// MARK: - Nền header: vẽ bằng Canvas (vector, nét mịn mọi kích thước)
// Gradient xanh + quầng sáng + lưới chấm + 3 lớp sóng chuyển động nhẹ + hình phiếu và kiện hàng mờ bên phải.

struct HeroBackdrop: View {
    var animated: Bool = true
    var art: Bool = true

    var body: some View {
        ZStack {
            Theme.heroGradient
            TimelineView(.animation(minimumInterval: 1.0 / 24.0, paused: !animated)) { tl in
                Canvas { ctx, size in
                    let t = tl.date.timeIntervalSinceReferenceDate
                    drawGlow(&ctx, size)
                    drawDots(&ctx, size)
                    if art { drawIllustration(&ctx, size) }
                    drawWaves(&ctx, size, t)
                }
            }
        }
    }

    private func drawGlow(_ ctx: inout GraphicsContext, _ s: CGSize) {
        let a = CGPoint(x: s.width * 0.92, y: -s.height * 0.05)
        ctx.fill(Path(ellipseIn: CGRect(x: a.x - 190, y: a.y - 190, width: 380, height: 380)),
                 with: .radialGradient(Gradient(colors: [Color.white.opacity(0.30), .clear]),
                                       center: a, startRadius: 0, endRadius: 190))
        let b = CGPoint(x: -s.width * 0.05, y: s.height * 0.95)
        ctx.fill(Path(ellipseIn: CGRect(x: b.x - 170, y: b.y - 170, width: 340, height: 340)),
                 with: .radialGradient(Gradient(colors: [Color(red: 0.55, green: 1, blue: 0.75).opacity(0.22), .clear]),
                                       center: b, startRadius: 0, endRadius: 170))
    }

    private func drawDots(_ ctx: inout GraphicsContext, _ s: CGSize) {
        let gap: CGFloat = 16
        let cols = Int(s.width / gap) + 1
        let rows = Int(min(s.height, 150) / gap) + 1
        for r in 0..<rows {
            for c in 0..<cols {
                let x = CGFloat(c) * gap + 6, y = CGFloat(r) * gap + 6
                // đậm ở góc phải trên, nhạt dần sang trái và xuống dưới
                let fx = x / s.width, fy = y / max(s.height, 1)
                let o = max(0, fx - 0.35) * max(0, 0.75 - fy) * 0.55
                if o < 0.01 { continue }
                ctx.fill(Path(ellipseIn: CGRect(x: x, y: y, width: 2.2, height: 2.2)),
                         with: .color(.white.opacity(o)))
            }
        }
    }

    private func drawIllustration(_ ctx: inout GraphicsContext, _ s: CGSize) {
        let w: CGFloat = 92, h: CGFloat = 118
        let origin = CGPoint(x: s.width - w - 20, y: 16)
        var c = ctx
        c.translateBy(x: origin.x + w / 2, y: origin.y + h / 2)
        c.rotate(by: .degrees(9))
        c.translateBy(x: -w / 2, y: -h / 2)

        // tờ phiếu
        let page = Path(roundedRect: CGRect(x: 0, y: 0, width: w, height: h), cornerRadius: 10)
        c.fill(page, with: .color(.white.opacity(0.10)))
        c.stroke(page, with: .color(.white.opacity(0.35)), lineWidth: 1.4)
        // tiêu đề + dòng chữ
        c.fill(Path(roundedRect: CGRect(x: 12, y: 12, width: 38, height: 6), cornerRadius: 3), with: .color(.white.opacity(0.45)))
        for i in 0..<5 {
            let y = 30 + CGFloat(i) * 13
            c.fill(Path(roundedRect: CGRect(x: 12, y: y, width: i % 2 == 0 ? 68 : 54, height: 4), cornerRadius: 2),
                   with: .color(.white.opacity(0.22)))
        }
        // dấu tích
        var tick = Path()
        tick.move(to: CGPoint(x: 58, y: 100)); tick.addLine(to: CGPoint(x: 66, y: 108)); tick.addLine(to: CGPoint(x: 80, y: 90))
        c.stroke(tick, with: .color(.white.opacity(0.7)), style: StrokeStyle(lineWidth: 2.6, lineCap: .round, lineJoin: .round))

        // kiện hàng (hình hộp) đè lên góc tờ phiếu
        var b = ctx
        b.translateBy(x: origin.x - 34, y: origin.y + 70)
        let top = Path { p in
            p.move(to: CGPoint(x: 26, y: 0)); p.addLine(to: CGPoint(x: 52, y: 13))
            p.addLine(to: CGPoint(x: 26, y: 26)); p.addLine(to: CGPoint(x: 0, y: 13)); p.closeSubpath()
        }
        let left = Path { p in
            p.move(to: CGPoint(x: 0, y: 13)); p.addLine(to: CGPoint(x: 26, y: 26))
            p.addLine(to: CGPoint(x: 26, y: 56)); p.addLine(to: CGPoint(x: 0, y: 43)); p.closeSubpath()
        }
        let right = Path { p in
            p.move(to: CGPoint(x: 26, y: 26)); p.addLine(to: CGPoint(x: 52, y: 13))
            p.addLine(to: CGPoint(x: 52, y: 43)); p.addLine(to: CGPoint(x: 26, y: 56)); p.closeSubpath()
        }
        b.fill(top, with: .color(.white.opacity(0.30)))
        b.fill(left, with: .color(.white.opacity(0.16)))
        b.fill(right, with: .color(.white.opacity(0.10)))
        for p in [top, left, right] { b.stroke(p, with: .color(.white.opacity(0.45)), lineWidth: 1.2) }
    }

    private func wave(_ s: CGSize, base: CGFloat, amp: CGFloat, len: CGFloat, phase: Double) -> Path {
        var p = Path()
        p.move(to: CGPoint(x: 0, y: s.height))
        var x: CGFloat = 0
        while x <= s.width + 4 {
            let y = base + amp * CGFloat(sin(Double(x / len) * 2 * .pi + phase))
            p.addLine(to: CGPoint(x: x, y: y))
            x += 4
        }
        p.addLine(to: CGPoint(x: s.width, y: s.height))
        p.closeSubpath()
        return p
    }

    private func drawWaves(_ ctx: inout GraphicsContext, _ s: CGSize, _ t: Double) {
        let h = s.height
        ctx.fill(wave(s, base: h - 34, amp: 7, len: 210, phase: t * 0.55), with: .color(.white.opacity(0.07)))
        ctx.fill(wave(s, base: h - 24, amp: 6, len: 160, phase: -t * 0.75 + 1.4), with: .color(.white.opacity(0.08)))
        ctx.fill(wave(s, base: h - 13, amp: 5, len: 120, phase: t * 0.95 + 3.1), with: .color(.white.opacity(0.10)))
    }
}

// MARK: - Xếp chip tự xuống dòng khi hết chỗ

struct FlowLayout: Layout {
    var spacing: CGFloat = 6

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let maxW = proposal.width ?? .infinity
        var x: CGFloat = 0, y: CGFloat = 0, rowH: CGFloat = 0, used: CGFloat = 0
        for v in subviews {
            let s = v.sizeThatFits(.unspecified)
            if x > 0 && x + s.width > maxW { y += rowH + spacing; x = 0; rowH = 0 }
            x += s.width + spacing
            rowH = max(rowH, s.height)
            used = max(used, x - spacing)
        }
        return CGSize(width: used, height: y + rowH)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        var x = bounds.minX, y = bounds.minY, rowH: CGFloat = 0
        for v in subviews {
            let s = v.sizeThatFits(.unspecified)
            if x > bounds.minX && x + s.width > bounds.maxX { y += rowH + spacing; x = bounds.minX; rowH = 0 }
            v.place(at: CGPoint(x: x, y: y), proposal: ProposedViewSize(s))
            x += s.width + spacing
            rowH = max(rowH, s.height)
        }
    }
}
