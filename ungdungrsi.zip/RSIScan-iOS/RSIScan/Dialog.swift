import SwiftUI

// MARK: - Hộp xác nhận và thanh chọn dùng chung (đổi kiểu ở đây là đổi toàn app)

struct DialogContent {
    var icon: String = "trash"
    var title: String
    var message: String? = nil
    var confirmTitle: String
    var destructive: Bool = true
    var cancelTitle: String = "Huỷ"
}

/// Hộp xác nhận bo tròn, nền thẻ, 2 nút cạnh nhau (Huỷ / Xác nhận).
struct AppDialogCard: View {
    let c: DialogContent
    let onCancel: () -> Void
    let onConfirm: () -> Void

    private var tint: Color { c.destructive ? Theme.red : Theme.primary }
    private var soft: Color { c.destructive ? Theme.redSoft : Theme.primarySoft }

    var body: some View {
        VStack(spacing: 14) {
            ZStack {
                Circle().fill(soft)
                Image(systemName: c.icon)
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundColor(tint)
            }
            .frame(width: 52, height: 52)

            Text(c.title)
                .font(.headline)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
            if let m = c.message {
                Text(m)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }

            HStack(spacing: 10) {
                Button(action: onCancel) {
                    Text(c.cancelTitle)
                        .font(.body.weight(.semibold))
                        .frame(maxWidth: .infinity, minHeight: 46)
                        .foregroundColor(Theme.primaryDark)
                        .background(Theme.primarySoft)
                        .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.control, style: .continuous))
                }
                Button(action: onConfirm) {
                    Text(c.confirmTitle)
                        .font(.body.weight(.semibold))
                        .frame(maxWidth: .infinity, minHeight: 46)
                        .foregroundColor(.white)
                        .background(tint)
                        .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.control, style: .continuous))
                }
            }
            .padding(.top, 4)
        }
        .padding(20)
        .frame(maxWidth: 340)
        .background(Theme.card)
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(Theme.line, lineWidth: 1))
        .shadow(color: .black.opacity(0.18), radius: 24, y: 8)
        .padding(.horizontal, 32)
    }
}

private struct AppDialogModifier<T>: ViewModifier {
    @Binding var item: T?
    let content: (T) -> DialogContent
    let action: (T) -> Void

    func body(content view: Content) -> some View {
        view.overlay {
            if let it = item {
                ZStack {
                    Color.black.opacity(0.38)
                        .ignoresSafeArea()
                        .onTapGesture { withAnimation(.easeOut(duration: 0.15)) { item = nil } }
                    AppDialogCard(c: content(it),
                                  onCancel: { withAnimation(.easeOut(duration: 0.15)) { item = nil } },
                                  onConfirm: {
                                      withAnimation(.easeOut(duration: 0.15)) { item = nil }
                                      action(it)
                                  })
                    .transition(.scale(scale: 0.92).combined(with: .opacity))
                }
                .zIndex(10)
            }
        }
        .animation(.spring(response: 0.3, dampingFraction: 0.85), value: item != nil)
    }
}

extension View {
    /// Hộp xác nhận theo một giá trị (xoá bản sao lưu nào, khôi phục bản nào...).
    func appDialog<T>(item: Binding<T?>, content: @escaping (T) -> DialogContent,
                      action: @escaping (T) -> Void) -> some View {
        modifier(AppDialogModifier(item: item, content: content, action: action))
    }

    /// Hộp xác nhận bật/tắt bằng một biến Bool.
    func appDialog(isPresented: Binding<Bool>, _ content: DialogContent,
                   action: @escaping () -> Void) -> some View {
        let item = Binding<Bool?>(get: { isPresented.wrappedValue ? true : nil },
                                  set: { isPresented.wrappedValue = ($0 != nil) })
        return modifier(AppDialogModifier(item: item, content: { _ in content }, action: { _ in action() }))
    }
}

// MARK: - Thanh chọn dạng viên thuốc (thay Picker mặc định)

struct PillPicker<V: Hashable>: View {
    let options: [(title: String, value: V)]
    @Binding var selection: V
    @Namespace private var ns

    var body: some View {
        HStack(spacing: 4) {
            ForEach(options.indices, id: \.self) { i in
                let o = options[i]
                let on = o.value == selection
                Button {
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) { selection = o.value }
                } label: {
                    Text(o.title)
                        .font(.system(size: 13, weight: .semibold))
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)
                        .frame(maxWidth: .infinity, minHeight: 34)
                        .foregroundColor(on ? .white : Theme.primaryDark)
                        .background {
                            if on {
                                Capsule().fill(Theme.primary)
                                    .shadow(color: Theme.primary.opacity(0.35), radius: 4, y: 2)
                                    .matchedGeometryEffect(id: "pill", in: ns)
                            }
                        }
                }
                .buttonStyle(.plain)
            }
        }
        .padding(4)
        .background(Theme.primarySoft)
        .clipShape(Capsule())
    }
}
