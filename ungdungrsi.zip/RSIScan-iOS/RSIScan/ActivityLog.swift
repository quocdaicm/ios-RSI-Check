import SwiftUI

// MARK: - Nhật ký thao tác
// Ghi lại: tạo phiếu, sửa gì, xoá, đã lên Drive, lỗi Drive. Lưu trong Documents/activity.json (tối đa 500 dòng).

struct ActivityEntry: Identifiable, Codable {
    enum Kind: String, Codable { case created, edited, deleted, uploaded, failed }
    var id = UUID()
    var date = Date()
    var kind: Kind
    var rsi: String
    var detail: String = ""
    var slipID: UUID? = nil
}

final class ActivityLog: ObservableObject {
    static let shared = ActivityLog()
    static let maxEntries = 500

    @Published private(set) var entries: [ActivityEntry] = []   // mới nhất ở đầu

    private var url: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("activity.json")
    }

    private init() {
        if let d = try? Data(contentsOf: url),
           let list = try? JSONDecoder().decode([ActivityEntry].self, from: d) {
            entries = list
        }
    }

    func add(_ kind: ActivityEntry.Kind, rsi: String, detail: String = "", slipID: UUID? = nil) {
        let name = rsi.isEmpty ? "(chưa có số)" : rsi
        DispatchQueue.main.async {
            // tránh ghi lặp cùng một lỗi liên tiếp
            if kind == .failed, let f = self.entries.first, f.kind == .failed, f.rsi == name, f.detail == detail { return }
            self.entries.insert(ActivityEntry(kind: kind, rsi: name, detail: detail, slipID: slipID), at: 0)
            if self.entries.count > Self.maxEntries { self.entries.removeLast(self.entries.count - Self.maxEntries) }
            self.save()
        }
    }

    func clear() {
        entries = []
        save()
    }

    private func save() {
        if let d = try? JSONEncoder().encode(entries) { try? d.write(to: url, options: .atomic) }
    }

    /// Mô tả những gì khác nhau giữa bản cũ và bản mới của phiếu.
    static func diff(_ o: Slip, _ n: Slip) -> String {
        var c: [String] = []
        func ch(_ label: String, _ a: String, _ b: String) {
            if a != b { c.append("\(label): \(a.isEmpty ? "trống" : a) → \(b.isEmpty ? "trống" : b)") }
        }
        ch("Số RSI", o.rsiNo, n.rsiNo)
        ch("Ngày", o.requestDate, n.requestDate)
        ch("Dự án", o.project, n.project)
        ch("Ghi chú", o.remark, n.remark)
        if o.pages.count != n.pages.count { c.append("Ảnh: \(o.pages.count) → \(n.pages.count)") }
        if o.items != n.items {
            if o.items.count != n.items.count {
                c.append("Kiện hàng: \(o.items.count) → \(n.items.count) dòng")
            } else {
                c.append("Sửa kiện hàng")
            }
        }
        return c.joined(separator: "; ")
    }
}

struct ActivityLogView: View {
    @ObservedObject private var log = ActivityLog.shared
    @EnvironmentObject var store: Store
    @State private var confirmClear = false
    @State private var filter: ActivityEntry.Kind? = nil

    private static let fmt: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "vi_VN")
        f.dateFormat = "dd/MM/yyyy HH:mm"
        return f
    }()

    private func style(_ k: ActivityEntry.Kind) -> (String, String, Color) {
        switch k {
        case .created:  return ("plus.circle.fill", "Tạo phiếu", .green)
        case .edited:   return ("pencil.circle.fill", "Đã sửa", .orange)
        case .deleted:  return ("trash.circle.fill", "Đã xoá", .red)
        case .uploaded: return ("icloud.and.arrow.up.fill", "Đã lên Drive", .blue)
        case .failed:   return ("exclamationmark.triangle.fill", "Lỗi Drive", .red)
        }
    }

    private var shown: [ActivityEntry] {
        guard let f = filter else { return log.entries }
        return log.entries.filter { $0.kind == f }
    }

    private func chip(_ title: String, _ k: ActivityEntry.Kind?) -> some View {
        Button { filter = k } label: {
            Text(title)
                .font(.footnote.weight(.semibold))
                .padding(.horizontal, 12).padding(.vertical, 6)
                .background(filter == k ? Color.accentColor : Color.secondary.opacity(0.15))
                .foregroundColor(filter == k ? .white : .primary)
                .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }

    @ViewBuilder
    private func row(_ e: ActivityEntry) -> some View {
        let s = style(e.kind)
        let target = e.slipID.flatMap { id in store.slips.first(where: { $0.id == id }) }
        if let t = target {
            NavigationLink { SlipDetailView(id: t.id) } label: { rowBody(e, s) }
        } else {
            rowBody(e, s)
        }
    }

    private func rowBody(_ e: ActivityEntry, _ s: (String, String, Color)) -> some View {
        Group {
            HStack(alignment: .top, spacing: 10) {
                    Image(systemName: s.0).foregroundColor(s.2).font(.title3)
                    VStack(alignment: .leading, spacing: 3) {
                        HStack {
                            Text(e.rsi).font(.subheadline.weight(.semibold))
                            Spacer()
                            Text(Self.fmt.string(from: e.date)).font(.caption2).foregroundColor(.secondary)
                        }
                        Text(s.1 + (e.detail.isEmpty ? "" : " · " + e.detail))
                            .font(.footnote).foregroundColor(.secondary)
                    }
                }
                .padding(.vertical, 2)
        }
    }

    var body: some View {
        List {
            Section {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        chip("Tất cả", nil)
                        chip("Đã lên Drive", .uploaded)
                        chip("Tạo mới", .created)
                        chip("Đã sửa", .edited)
                        chip("Đã xoá", .deleted)
                        chip("Lỗi", .failed)
                    }
                }
                .listRowInsets(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
            }
            if shown.isEmpty {
                Text("Chưa có thao tác nào.").foregroundColor(.secondary)
            }
            ForEach(shown) { e in row(e) }
        }
        .formScreen()
        .navigationTitle("Lịch sử thao tác")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            if !log.entries.isEmpty {
                Button("Xoá") { confirmClear = true }
            }
        }
        .confirmationDialog("Xoá toàn bộ lịch sử thao tác?", isPresented: $confirmClear, titleVisibility: .visible) {
            Button("Xoá lịch sử", role: .destructive) { log.clear() }
        }
    }
}
