import Foundation
import CoreGraphics

// MARK: - Đọc bảng theo tiêu đề cột (không phụ thuộc một mẫu phiếu cố định)
//
// Ý tưởng: thay vì đoán theo định dạng mã kiện của một mẫu, app tìm hàng tiêu đề của bảng
// (Package No / Description / Unit / Qty / Actual ...), biết mỗi cột nằm ở đâu, rồi đọc từng hàng
// theo cột. Mẫu phiếu khác đổi tên cột, đổi thứ tự cột, thêm bớt cột vẫn đọc đúng.

enum Col: String {
    case no, pkg, desc, tag, unit, qty, actual
    case other      // cột không lấy dữ liệu (Balance, Received by, Remark ...), chỉ dùng để chặn chữ lấn sang cột khác
}

struct HeaderCell {
    var kind: Col
    var box: CGRect
}

struct ColumnBand {
    var kind: Col
    var minX: CGFloat      // mép trái/phải của chữ tiêu đề
    var maxX: CGFloat
    var lo: CGFloat = 0    // ranh giới gán chữ vào cột
    var hi: CGFloat = 1
}

enum TableReader {

    // MARK: Chuẩn hoá chữ

    static func fold(_ s: String) -> String {
        var t = SlipParser.clean(s).lowercased()
        t = t.folding(options: .diacriticInsensitive, locale: Locale(identifier: "en_US"))
        t = t.replacingOccurrences(of: "đ", with: "d")
        return t
    }

    static func squash(_ s: String) -> String {
        String(fold(s).filter { $0.isLetter || $0.isNumber })
    }

    // MARK: Nhận ra tên cột (tiếng Anh + tiếng Việt, nhiều cách viết)

    static let exactCols: [String: Col] = [
        "packageno": .pkg, "pkgno": .pkg, "package": .pkg, "pkg": .pkg, "packageid": .pkg,
        "packagenumber": .pkg, "packingno": .pkg, "packagecode": .pkg, "kien": .pkg,
        "makien": .pkg, "sokien": .pkg, "tenkien": .pkg,
        "description": .desc, "descriptions": .desc, "desc": .desc, "material": .desc,
        "materialdescription": .desc, "goods": .desc, "itemdescription": .desc,
        "descriptionofgoods": .desc, "mota": .desc, "tenhang": .desc, "noidung": .desc,
        "tag": .tag, "tagno": .tag, "serialno": .tag, "serial": .tag, "mark": .tag,
        "markno": .tag, "spec": .tag, "specification": .tag, "size": .tag, "partno": .tag,
        "unit": .unit, "units": .unit, "uom": .unit, "dvt": .unit, "donvi": .unit,
        "qty": .qty, "qtty": .qty, "quantity": .qty, "request": .qty, "requested": .qty,
        "reqqty": .qty, "requestqty": .qty, "soluong": .qty, "sl": .qty,
        "actual": .actual, "ho": .actual, "actualho": .actual, "received": .actual,
        "actualqty": .actual, "thucnhan": .actual,
        "no": .no, "stt": .no, "item": .no, "itemno": .no
    ]

    static let containsCols: [(String, Col)] = [
        ("packageno", .pkg), ("packagenumber", .pkg), ("pkgno", .pkg), ("packingno", .pkg),
        ("packagecode", .pkg), ("makien", .pkg), ("sokien", .pkg), ("tenkien", .pkg),
        ("descriptionofgoods", .desc), ("description", .desc), ("tenhang", .desc),
        ("tagno", .tag), ("serialno", .tag),
        ("actualqty", .actual), ("actualho", .actual), ("receivedqty", .actual),
        ("requestqty", .qty), ("requestedqty", .qty), ("requestq", .qty), ("quantity", .qty),
        ("soluong", .qty), ("donvi", .unit)
    ]

    static func classify(_ text: String) -> Col? {
        let f = fold(text)
        if f.isEmpty || f.count > 40 { return nil }
        // Các cột không lấy dữ liệu nhưng phải biết vị trí, nếu không chữ ký/ngày/ghi chú bên phải
        // sẽ bị tính nhầm vào cột Actual H/O
        let sq = squash(text)
        let exactOther: Set<String> = ["balance", "signature", "withsignature"]
        var isOther = exactOther.contains(sq) || sq.contains("fullname")
        for p in ["remark", "receivedby", "receiveddate"] where sq.hasPrefix(p) { isOther = true }
        if isOther { return .other }
        // "Request Date", "Requested By", "Received Date" là nhãn của phần đầu/cuối phiếu, không phải cột
        if f.contains("date") || f.contains(" by") || f.hasSuffix("by") { return nil }
        if f == "#" { return .no }
        let s = squash(text)
        if s.isEmpty { return nil }
        if let c = exactCols[s] { return c }
        for (k, c) in containsCols where s.contains(k) { return c }
        return nil
    }

    // MARK: Tìm hàng tiêu đề

    /// Trả về các ô tiêu đề (đã gộp cùng loại) của hàng tiêu đề tốt nhất, hoặc nil nếu không thấy bảng.
    static func findHeader(_ lines: [OCRLine]) -> [HeaderCell]? {
        var cands: [HeaderCell] = []
        for l in lines {
            if let k = classify(l.text) { cands.append(HeaderCell(kind: k, box: l.box)) }
        }
        if cands.count < 3 { return nil }

        var bestCells: [HeaderCell] = []
        var bestKinds = 0
        var bestY: CGFloat = -1
        for seed in cands where seed.kind != .other {
            // tiêu đề có thể xuống 2 dòng (Request / Q'ty) nên lấy dải dọc rộng một chút
            let win = cands.filter { abs($0.box.midY - seed.box.midY) <= 0.035 }
            let kinds = Set(win.filter { $0.kind != .other }.map { $0.kind })
            if kinds.count > bestKinds || (kinds.count == bestKinds && seed.box.midY > bestY) {
                bestKinds = kinds.count
                bestCells = win
                bestY = seed.box.midY
            }
        }
        guard bestKinds >= 3 else { return nil }
        let kinds = Set(bestCells.map { $0.kind })
        guard kinds.contains(.pkg) || kinds.contains(.desc) else { return nil }

        // "Q'ty" nằm ngay dưới "Actual H/O" là cột thực nhận, không phải cột Request
        var cells = bestCells
        let actuals = cells.filter { $0.kind == .actual }
        if !actuals.isEmpty {
            for i in cells.indices where cells[i].kind == .qty {
                let b = cells[i].box
                var under = false
                for a in actuals {
                    if min(a.box.maxX, b.maxX) - max(a.box.minX, b.minX) > 0 { under = true }
                }
                if under { cells[i].kind = .actual }
            }
        }

        // gộp các ô cùng loại thành một hộp (cột "other" giữ riêng từng ô)
        var merged: [Col: CGRect] = [:]
        var result: [HeaderCell] = []
        for c in cells {
            if c.kind == .other { result.append(c); continue }
            if let r = merged[c.kind] { merged[c.kind] = r.union(c.box) } else { merged[c.kind] = c.box }
        }
        for (k, r) in merged { result.append(HeaderCell(kind: k, box: r)) }
        return result
    }

    static func makeBands(_ cells: [HeaderCell]) -> [ColumnBand] {
        let sorted = cells.sorted { $0.box.midX < $1.box.midX }
        var bands = sorted.map { ColumnBand(kind: $0.kind, minX: $0.box.minX, maxX: $0.box.maxX) }
        if bands.count < 2 { return bands }
        for i in 0..<bands.count {
            if i > 0 { bands[i].lo = boundary(bands[i - 1], bands[i]) }
            if i < bands.count - 1 { bands[i].hi = boundary(bands[i], bands[i + 1]) }
        }
        return bands
    }

    static func boundary(_ a: ColumnBand, _ b: ColumnBand) -> CGFloat {
        if a.maxX < b.minX { return (a.maxX + b.minX) / 2 }
        return ((a.minX + a.maxX) / 2 + (b.minX + b.maxX) / 2) / 2
    }

    static func column(of l: OCRLine, _ bands: [ColumnBand]) -> Col? {
        let x = l.box.midX
        for b in bands where x >= b.lo && x < b.hi { return b.kind }
        return nil
    }

    // MARK: Mã kiện (nhận theo hình dạng chung, không theo một mẫu cụ thể)

    static let codeRe = try! NSRegularExpression(pattern: "^[A-Z0-9][A-Z0-9]*(?:[-/.][A-Z0-9]+)+$")
    static let anyDateRe = try! NSRegularExpression(
        pattern: "^(?:\\d{1,2}[-/. ][A-Za-z]{3,9}[-/. ]\\d{2,4}|\\d{1,2}[/.-]\\d{1,2}[/.-]\\d{2,4}|\\d{4}-\\d{2}-\\d{2})$")

    static func isCode(_ tok: String) -> Bool {
        let t = SlipParser.clean(tok).uppercased()
        guard t.count >= 6, t.count <= 40 else { return false }
        guard t.contains(where: { $0.isNumber }) else { return false }
        if SlipParser.match(anyDateRe, t) != nil { return false }
        let hasLetter = t.contains(where: { $0.isLetter })
        if !hasLetter && t.count < 8 { return false }
        return SlipParser.match(codeRe, t) != nil
    }

    /// Dự án OM4: mã kiện luôn bắt đầu bằng "OM4-", chữ nào đứng trước (OCR đọc dính số thứ tự, ví dụ "5OM4-...") thì bỏ.
    static func stripToProject(_ code: String) -> String {
        let u = code.uppercased()
        if let r = u.range(of: "OM4-"), r.lowerBound > u.startIndex {
            return String(u[r.lowerBound...])
        }
        return code
    }

    /// Tách mã kiện khỏi phần chữ thừa cùng dòng. Trả (mã, phần còn lại).
    static func splitCode(_ text: String) -> (String, String)? {
        let t = SlipParser.clean(text)
        // OCR hay chèn khoảng trắng trong mã: thử cả dòng bỏ trắng trước
        let compact = t.replacingOccurrences(of: " ", with: "")
        if isCode(compact) { return (stripToProject(compact.uppercased()), "") }
        let toks = t.split(separator: " ").map(String.init)
        for (i, tok) in toks.enumerated() where isCode(tok) {
            var rest = toks
            rest.remove(at: i)
            return (stripToProject(tok.uppercased()), rest.joined(separator: " "))
        }
        return nil
    }

    // MARK: Số lượng / đơn vị

    static let knownUnits: Set<String> = [
        "M", "MTR", "EA", "SET", "SETS", "PC", "PCS", "KG", "LOT", "ROLL", "NOS", "NO", "PKG",
        "BOX", "CAN", "DRUM", "TON", "M2", "M3", "L", "LTR", "BAG", "PAIL", "LEN", "BDL", "BUNDLE",
        "CTN", "CARTON", "PLT", "PALLET", "SHEET", "SHT", "PAIR", "UNIT", "CRATE", "CASE", "BTL",
        "TUBE", "COIL", "FT", "JT", "LGTH", "PAC", "PACK"
    ]

    static let unitTailRe = try! NSRegularExpression(
        pattern: "(?:^|\\s)([A-Za-z][A-Za-z0-9]{0,5})\\s+(\\d+(?:[.,]\\d+)?)\\s*$")

    /// Đọc một số lượng, sửa lỗi OCR hay gặp (O->0, l->1, S->5 ...). Trả nil nếu không giống số.
    static func numberize(_ t: String) -> String? {
        let c = t.trimmingCharacters(in: SlipParser.handTrim)
        guard !c.isEmpty, c.count <= 8 else { return nil }
        var r = ""
        var digits = 0
        for ch in c {
            if ch.isNumber { r.append(ch); digits += 1 }
            else if ch == "." || ch == "," { r.append(ch) }
            else if let m = SlipParser.digitMap[ch] { r.append(m); digits += 1 }
            else { return nil }
        }
        // phải có ít nhất 1 chữ số thật, và không được toàn ký tự bị đoán
        let real = c.filter { $0.isNumber }.count
        if digits == 0 || real == 0 { return nil }
        if r.hasPrefix(".") || r.hasPrefix(",") || r.hasSuffix(".") || r.hasSuffix(",") { return nil }
        return r
    }

    static func unitCandidate(_ t: String) -> String? {
        let u = SlipParser.clean(t).uppercased().trimmingCharacters(in: SlipParser.handTrim)
        if u.isEmpty || u.count > 6 { return nil }
        if knownUnits.contains(u) { return u }
        if u.allSatisfy({ $0.isLetter }) && u.count <= 4 { return u }
        return nil
    }

    // MARK: Đọc bảng

    struct Anchor {
        var code: String
        var rest: String
        var box: CGRect
        var conf: Float
    }

    static func joinCell(_ ls: [OCRLine]) -> String {
        // trên xuống dưới, trái sang phải
        let rows = ls.sorted { a, b in
            if abs(a.box.midY - b.box.midY) < max(a.box.height, b.box.height) * 0.6 {
                return a.box.minX < b.box.minX
            }
            return a.box.midY > b.box.midY
        }
        return rows.map { SlipParser.clean($0.text) }.filter { !$0.isEmpty }.joined(separator: " ")
    }

    static let footerKeys = ["remark", "requestedby", "checkedby", "confirmedby", "approvedby",
                             "preparedby", "attachment", "total", "note"]

    /// Khung của ô số liệu: lấy quanh tâm chữ tiêu đề cột, thu hẹp theo chiều dọc để tránh đường kẻ bảng.
    static func cellRect(_ b: ColumnBand, bottom: CGFloat, top: CGFloat, grow: CGFloat) -> CGRect {
        let c: CGFloat = (b.minX + b.maxX) / 2
        let halfW: CGFloat = (b.maxX - b.minX) / 2
        let half: CGFloat = max(halfW * grow, 0.02)
        let x0: CGFloat = max(b.lo, c - half)
        let x1: CGFloat = min(b.hi, c + half)
        let h: CGFloat = top - bottom
        let y0: CGFloat = bottom + h * 0.18
        let y1: CGFloat = top - h * 0.18
        let w: CGFloat = max(x1 - x0, 0.005)
        let hh: CGFloat = max(y1 - y0, 0.005)
        return CGRect(x: x0, y: y0, width: w, height: hh)
    }

    static func read(_ lines: [OCRLine], page: OCRPage? = nil) -> (items: [Item], warnings: [String]) {
        guard let cells = findHeader(lines) else { return ([], []) }
        let bands = makeBands(cells)
        guard let pkgBand = bands.first(where: { $0.kind == .pkg }) else {
            return ([], ["Không nhận ra cột mã kiện (Package No) trên phiếu này. Hãy kiểm tra lại bảng kiện hàng."])
        }
        let headerBottom = cells.map { $0.box.minY }.min() ?? 0

        // 1. Dòng có mã kiện, nằm dưới tiêu đề, trong cột Package No
        var anchors: [Anchor] = []
        for l in lines {
            if l.box.midY >= headerBottom { continue }
            if l.box.midX < pkgBand.lo - 0.03 || l.box.midX > pkgBand.hi + 0.03 { continue }
            if let (code, rest) = splitCode(l.text) {
                anchors.append(Anchor(code: code, rest: rest, box: l.box, conf: l.conf))
            }
        }
        anchors.sort { $0.box.midY > $1.box.midY }
        var uniq: [Anchor] = []
        for a in anchors {
            if let last = uniq.last, last.code == a.code, abs(last.box.midY - a.box.midY) < 0.015 { continue }
            uniq.append(a)
        }
        if uniq.isEmpty {
            return ([], ["Thấy bảng nhưng không đọc được mã kiện nào. Thử chụp rõ hơn hoặc nhập tay."])
        }

        // 2. Chiều cao một hàng
        var gaps: [CGFloat] = []
        if uniq.count > 1 {
            for i in 1..<uniq.count { gaps.append(uniq[i - 1].box.midY - uniq[i].box.midY) }
        }
        gaps.sort()
        let typical: CGFloat = gaps.isEmpty ? 0.05 : gaps[gaps.count / 2]

        // 3. Đáy bảng: dòng chân phiếu (Remark, Requested By ...) nằm dưới mã kiện cuối
        let lastY = uniq[uniq.count - 1].box.midY
        var footerY: CGFloat = -1
        for l in lines where l.box.midY < lastY - typical * 0.5 {
            let s = squash(l.text)
            if footerKeys.contains(where: { s.hasPrefix($0) }) && l.box.midY > footerY {
                footerY = l.box.midY
            }
        }

        var items: [Item] = []
        var warnings: [String] = []
        var seen: Set<String> = []
        var lowestBottom: CGFloat = lastY - typical * 0.9

        for (i, a) in uniq.enumerated() {
            let up = i > 0 ? (uniq[i - 1].box.midY - a.box.midY) : typical
            let down = i < uniq.count - 1 ? (a.box.midY - uniq[i + 1].box.midY) : typical * 0.9
            let top = min(a.box.midY + up / 2, headerBottom)
            var bottom = a.box.midY - down / 2
            if i == uniq.count - 1 && footerY > 0 { bottom = max(bottom, footerY + 0.005) }
            if i == uniq.count - 1 { lowestBottom = bottom }

            var cell: [Col: [OCRLine]] = [:]
            var loose: [OCRLine] = []
            var minConfQty: Float = 1
            for l in lines {
                if l.box.midY <= bottom || l.box.midY > top { continue }
                let colOf = column(of: l, bands)
                if let c = colOf {
                    if c == .pkg || c == .no || c == .other { continue }
                    // chữ tiêu đề lặp lại (bảng sang trang) thì bỏ, trừ ô đơn vị (vd "NO")
                    if c != .unit && SlipParser.isHeader(l.text) && classify(l.text) != nil { continue }
                    cell[c, default: []].append(l)
                } else {
                    loose.append(l)
                }
            }

            var item = Item()
            item.packageNo = a.code

            // đơn vị + số lượng theo cột
            let unitText = joinCell(cell[.unit] ?? [])
            let qtyText = joinCell(cell[.qty] ?? [])

            // trường hợp OCR dính "EA 5" trong một ô
            for t in [unitText, qtyText] where !t.isEmpty {
                let r = NSRange(t.startIndex..., in: t)
                if let m = unitTailRe.firstMatch(in: t, range: r),
                   let u = Range(m.range(at: 1), in: t), let q = Range(m.range(at: 2), in: t),
                   let uu = unitCandidate(String(t[u])) {
                    if item.unit.isEmpty { item.unit = uu }
                    if item.qty.isEmpty { item.qty = String(t[q]) }
                }
            }
            if item.unit.isEmpty, let u = unitCandidate(unitText) { item.unit = u }
            if item.qty.isEmpty {
                if let q = numberize(qtyText) { item.qty = q }
                else if let q = numberize(unitText) { item.qty = q }   // cột lệch: số rơi vào ô đơn vị
            }
            for l in (cell[.qty] ?? []) { minConfQty = min(minConfQty, l.conf) }

            // số thực nhận (thường viết tay)
            let actText = joinCell(cell[.actual] ?? [])
            if !actText.isEmpty {
                if let d = SlipParser.digitize(actText) { item.actualQty = d }
                else if let d = numberize(actText) { item.actualQty = d }
            }

            // Ô còn trống: cắt riêng ô đó, phóng to, thêm viền trắng rồi đọc lại
            var guessed = false
            if let pg = page {
                if item.qty.isEmpty, let qb = bands.first(where: { $0.kind == .qty }) {
                    let r = cellRect(qb, bottom: bottom, top: top, grow: 1.0)
                    if let q = CellOCR.number(in: r, page: pg, allowOnes: true) { item.qty = q }
                }
                if (item.actualQty ?? "").isEmpty, let ab = bands.first(where: { $0.kind == .actual }) {
                    let r = cellRect(ab, bottom: bottom, top: top, grow: 1.3)
                    if let q = CellOCR.number(in: r, page: pg, allowOnes: false) { item.actualQty = q }
                }
            }
            // vẫn không có số yêu cầu mà có số thực nhận viết tay thì tạm lấy số đó, nhắc kiểm tra lại
            if item.qty.isEmpty, let act = item.actualQty, !act.isEmpty {
                item.qty = act
                guessed = true
            }

            // thông tin kiện: tag + mô tả
            item.tag = joinCell(cell[.tag] ?? [])
            var descLines = cell[.desc] ?? []
            descLines.append(contentsOf: loose.filter {
                SlipParser.clean($0.text).filter { $0.isLetter }.count >= 2 && !SlipParser.isHeader($0.text)
            })
            var desc = joinCell(descLines)
            if !a.rest.isEmpty { desc = (a.rest + " " + desc).trimmingCharacters(in: .whitespaces) }
            item.desc = desc

            // Kiểm tra từng dòng
            if seen.contains(a.code) {
                warnings.append("Mã kiện \(a.code) xuất hiện 2 lần, kiểm tra xem có đọc nhầm không.")
            }
            seen.insert(a.code)
            if item.qty.isEmpty {
                warnings.append("Kiện \(a.code): chưa đọc được số lượng, hãy nhập tay.")
            } else if guessed {
                warnings.append("Kiện \(a.code): không đọc được số yêu cầu, tạm lấy số thực nhận (\(item.qty)). Kiểm tra lại.")
            } else if minConfQty < 0.5 || a.conf < 0.5 {
                warnings.append("Kiện \(a.code): chữ mờ, kiểm tra lại số lượng (\(item.qty)).")
            }
            if item.unit.isEmpty && !item.qty.isEmpty {
                warnings.append("Kiện \(a.code): chưa đọc được đơn vị.")
            }
            if !guessed, let act = item.actualQty, !act.isEmpty, !item.qty.isEmpty {
                let x = Double(act.replacingOccurrences(of: ",", with: "."))
                let y = Double(item.qty.replacingOccurrences(of: ",", with: "."))
                if x != nil && y != nil && x != y {
                    warnings.append("Kiện \(a.code): thực nhận \(act) khác số yêu cầu \(item.qty).")
                }
            }
            items.append(item)
        }

        // Đối chiếu với cột số thứ tự (nếu phiếu có) để phát hiện dòng bị sót
        if let noBand = bands.first(where: { $0.kind == .no }) {
            var count = 0
            for l in lines {
                if l.box.midY >= headerBottom || l.box.midY <= lowestBottom { continue }
                if l.box.midX < noBand.lo || l.box.midX >= noBand.hi { continue }
                let t = l.text.trimmingCharacters(in: SlipParser.handTrim)
                if let n = Int(t), n >= 1, n <= 300 { count += 1 }
            }
            if count > items.count {
                warnings.append("Cột số thứ tự có \(count) dòng nhưng chỉ đọc được \(items.count) kiện. Có thể sót kiện.")
            }
        }
        return (items, warnings)
    }

    static func score(_ items: [Item]) -> Int {
        var s = 0
        for it in items {
            if !it.packageNo.isEmpty { s += 2 }
            if !it.qty.isEmpty { s += 2 }
            if !it.unit.isEmpty { s += 1 }
            if !it.desc.isEmpty || !it.tag.isEmpty { s += 1 }
            if let a = it.actualQty, !a.isEmpty { s += 1 }
        }
        return s
    }

    // MARK: Thông tin đầu phiếu theo nhãn (dự phòng cho mẫu khác)

    static let rsiAnyRe = try! NSRegularExpression(pattern: "[A-Z0-9]*(?:-[A-Z0-9]+)*RSI(?:-[A-Z0-9]+)*-\\d{2,6}")
    static let rsiLabelKeys = ["rsino", "rsinumber", "rsi#", "requisitionno", "requestno", "sophieu", "sorsi"]

    /// Tìm số RSI theo hình dạng chung (chứa chữ RSI và có số cuối) hoặc theo nhãn "RSI No".
    static func rsiGeneric(_ lines: [OCRLine]) -> String {
        for l in lines {
            let id = SlipParser.idForm(l.text).replacingOccurrences(of: ".", with: "")
            if let s = SlipParser.firstString(rsiAnyRe, id) { return s }
        }
        for l in lines {
            let s = squash(l.text)
            guard rsiLabelKeys.contains(where: { s.contains($0) }) else { continue }
            // giá trị nằm cùng dòng bên phải, hoặc ngay bên dưới
            var best: OCRLine? = nil
            for c in lines where c.box != l.box {
                let sameRow = abs(c.box.midY - l.box.midY) < max(l.box.height, 0.012)
                let below = c.box.midY < l.box.midY && l.box.midY - c.box.midY < 0.05
                if sameRow && c.box.minX >= l.box.maxX - 0.01 { best = c; break }
                if below && abs(c.box.midX - l.box.midX) < 0.15 && best == nil { best = c }
            }
            if let b = best {
                let t = SlipParser.idForm(b.text)
                if t.count >= 5 && t.contains(where: { $0.isNumber }) { return t }
            }
        }
        return ""
    }

    static let dateLabelKeys = ["requestdate", "date", "ngay", "ngaylap"]

    static func dateGeneric(_ lines: [OCRLine]) -> String {
        for l in lines {
            let t = SlipParser.clean(l.text)
            if SlipParser.match(anyDateRe, t) != nil { return t }
        }
        for l in lines {
            let s = squash(l.text)
            guard dateLabelKeys.contains(where: { s == $0 || s.hasPrefix($0) }) else { continue }
            for c in lines where c.box != l.box {
                let sameRow = abs(c.box.midY - l.box.midY) < max(l.box.height, 0.012)
                if sameRow && c.box.minX >= l.box.maxX - 0.01 {
                    let t = SlipParser.clean(c.text)
                    if t.contains(where: { $0.isNumber }) { return t }
                }
            }
        }
        return ""
    }
}

// MARK: - Phân tích phiếu: thử mẫu cũ và bộ đọc theo tiêu đề, chọn kết quả tốt hơn

extension SlipParser {
    static func parse(_ lines: [OCRLine], page: OCRPage? = nil) -> Parsed {
        var out = parseTemplate(lines)
        let tb = TableReader.read(lines, page: page)

        let oldScore = TableReader.score(out.items)
        let newScore = TableReader.score(tb.items)
        // Mẫu cũ đã chỉnh kỹ cho phiếu Doosan: chỉ đổi sang bộ đọc mới khi nó đọc được nhiều hơn.
        if !tb.items.isEmpty && (out.items.isEmpty || newScore > oldScore) {
            out.items = tb.items
            out.warnings = tb.warnings
        } else if out.items.isEmpty {
            out.warnings = tb.warnings
        }

        if out.rsiNo.isEmpty { out.rsiNo = TableReader.rsiGeneric(lines) }
        if out.date.isEmpty { out.date = TableReader.dateGeneric(lines) }

        if out.items.isEmpty {
            out.warnings.append("Không đọc được kiện hàng nào. Chụp thẳng, đủ sáng, thấy rõ cả bảng.")
        }
        return out
    }
}
