import SwiftUI

@main
struct RSIScanApp: App {
    @StateObject private var store = Store()
    @Environment(\.scenePhase) private var phase

    var body: some Scene {
        WindowGroup {
            SlipListView().environmentObject(store).tint(Theme.primary)
        }
        .onChange(of: phase) { p in
            if p == .active { store.autoBackupIfDue() }
        }
    }
}
