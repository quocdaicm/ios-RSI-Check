import SwiftUI

@main
struct RSIScanApp: App {
    @StateObject private var store = Store()

    var body: some Scene {
        WindowGroup {
            SlipListView().environmentObject(store).tint(Theme.primary)
        }
    }
}
