import SwiftUI

@main
struct RSIScanApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @StateObject private var store = Store()
    @Environment(\.scenePhase) private var phase

    var body: some Scene {
        WindowGroup {
            SlipListView().environmentObject(store).tint(Theme.primary)
        }
        .onChange(of: phase) { p in
            if p == .active {
                store.autoBackupIfDue()
                store.driveOnActive()
            }
        }
    }
}
