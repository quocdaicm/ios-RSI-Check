import SwiftUI
import UIKit

extension Color {
    init(light: UInt32, dark: UInt32) {
        self.init(UIColor { t in
            let v = t.userInterfaceStyle == .dark ? dark : light
            return UIColor(red: CGFloat((v >> 16) & 0xFF) / 255,
                           green: CGFloat((v >> 8) & 0xFF) / 255,
                           blue: CGFloat(v & 0xFF) / 255,
                           alpha: 1)
        })
    }
}

enum Theme {
    static let primary = Color(light: 0x1E9E64, dark: 0x3DC684)
    static let primaryDark = Color(light: 0x147A4C, dark: 0x5FD99C)
    static let primarySoft = Color(light: 0xE3F5EB, dark: 0x16382A)
    static let amberText = Color(light: 0x7A5A00, dark: 0xF2C230)
    static let amberSoft = Color(light: 0xFFF1C2, dark: 0x3D3410)
    static let red = Color(light: 0xE5484D, dark: 0xFF6B70)
    static let redSoft = Color(light: 0xFDE8E9, dark: 0x40191B)
    static let bg = Color(light: 0xF3F6F4, dark: 0x0F1412)
    static let card = Color(light: 0xFFFFFF, dark: 0x1A211E)
    static let line = Color(light: 0xE0E7E3, dark: 0x2A332F)

    static let heroGradient = LinearGradient(
        colors: [Color(light: 0x23AD6F, dark: 0x1F8A5C), Color(light: 0x137047, dark: 0x0F5A3A)],
        startPoint: .topLeading, endPoint: .bottomTrailing)
}

struct BottomRound: Shape {
    var r: CGFloat
    func path(in rect: CGRect) -> Path {
        Path(UIBezierPath(roundedRect: rect,
                          byRoundingCorners: [.bottomLeft, .bottomRight],
                          cornerRadii: CGSize(width: r, height: r)).cgPath)
    }
}

extension View {
    func card() -> some View {
        self
            .background(Theme.card)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(Theme.line, lineWidth: 1))
    }
}

struct Chip: View {
    let icon: String
    let text: String
    let fg: Color
    let bg: Color

    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: icon).font(.system(size: 10, weight: .semibold))
            Text(text).font(.caption2.weight(.semibold)).lineLimit(1)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(bg)
        .foregroundColor(fg)
        .clipShape(Capsule())
    }
}
