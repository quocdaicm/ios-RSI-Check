import SwiftUI

struct Item: Identifiable, Codable, Hashable {
    var id = UUID()
    var packageNo: String = ""
    var desc: String = ""
    var tag: String = ""
    var unit: String = ""
    var qty: String = ""
}

extension Item {
    func sameAs(_ o: Item) -> Bool {
        func k(_ x: String) -> String { x.trimmingCharacters(in: .whitespaces).uppercased() }
        return k(packageNo) == k(o.packageNo) && k(tag) == k(o.tag) && k(qty) == k(o.qty)
            && k(unit) == k(o.unit) && k(desc) == k(o.desc)
    }
}

enum Compression: String, CaseIterable, Identifiable {
    case small, balanced, sharp
    var id: String { rawValue }
    var title: String {
        switch self {
        case .small: return "Nhỏ nhất"
        case .balanced: return "Cân bằng"
        case .sharp: return "Rõ nét"
        }
    }
    var detail: String {
        switch self {
        case .small: return "Cạnh dài 1000px, chất lượng 40%. Khoảng 60 KB/ảnh, chữ nhỏ có thể khó đọc."
        case .balanced: return "Cạnh dài 1600px, chất lượng 50%. Khoảng 150 KB/ảnh."
        case .sharp: return "Cạnh dài 2200px, chất lượng 70%. Khoảng 330 KB/ảnh, chữ rõ nhất."
        }
    }
    var maxSide: CGFloat {
        switch self {
        case .small: return 1000
        case .balanced: return 1600
        case .sharp: return 2200
        }
    }
    var quality: CGFloat {
        switch self {
        case .small: return 0.4
        case .balanced: return 0.5
        case .sharp: return 0.7
        }
    }
    static let key = "compression"
    static var current: Compression {
        Compression(rawValue: UserDefaults.standard.string(forKey: key) ?? "") ?? .balanced
    }
}

struct Slip: Identifiable, Codable, Hashable {
    var id = UUID()
    var rsiNo: String = ""
    var requestDate: String = ""
    var project: String = ""
    var remark: String = ""
    var items: [Item] = []
    var pages: [String] = []      // tên file ảnh trong Documents/Scans
    var createdAt = Date()
}

final class Store: ObservableObject {
    static let maxPages = 10

    @Published var slips: [Slip] = []

    private let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    private var scansDir: URL { docs.appendingPathComponent("Scans", isDirectory: true) }
    private var dbURL: URL { docs.appendingPathComponent("slips.json") }

    init() {
        try? FileManager.default.createDirectory(at: scansDir, withIntermediateDirectories: true)
        load()
    }

    func load() {
        guard let data = try? Data(contentsOf: dbURL),
              let list = try? JSONDecoder().decode([Slip].self, from: data) else { return }
        slips = list
    }

    func persist() {
        if let data = try? JSONEncoder().encode(slips) {
            try? data.write(to: dbURL, options: .atomic)
        }
    }

    func imageURL(_ name: String) -> URL { scansDir.appendingPathComponent(name) }

    func image(_ name: String) -> UIImage? {
        UIImage(contentsOfFile: imageURL(name).path)
    }

    private let cache = NSCache<NSString, UIImage>()

    func thumb(_ name: String) -> UIImage? {
        if let c = cache.object(forKey: name as NSString) { return c }
        guard let img = image(name) else { return nil }
        let t = img.normalized(maxSide: 480)
        cache.setObject(t, forKey: name as NSString)
        return t
    }

    /// Lưu ảnh mới, trả về tên file
    func saveImage(_ img: UIImage) -> String? {
        let name = UUID().uuidString + ".jpg"
        let level = Compression.current
        let small = img.normalized(maxSide: level.maxSide)
        guard let data = small.jpegData(compressionQuality: level.quality) else { return nil }
        do { try data.write(to: imageURL(name), options: .atomic); return name }
        catch { return nil }
    }

    func removeImageFile(_ name: String) {
        try? FileManager.default.removeItem(at: imageURL(name))
    }

    func upsert(_ slip: Slip) {
        if let i = slips.firstIndex(where: { $0.id == slip.id }) {
            slips[i] = slip
        } else {
            slips.append(slip)
        }
        persist()
    }

    func delete(_ slip: Slip) {
        for p in slip.pages { try? FileManager.default.removeItem(at: imageURL(p)) }
        slips.removeAll { $0.id == slip.id }
        persist()
    }

    func existing(rsiNo: String, except id: UUID) -> Slip? {
        let k = rsiNo.trimmingCharacters(in: .whitespaces).uppercased()
        guard !k.isEmpty else { return nil }
        return slips.first { $0.id != id && $0.rsiNo.uppercased() == k }
    }

    func storageBytes() -> Int {
        let urls = (try? FileManager.default.contentsOfDirectory(at: scansDir, includingPropertiesForKeys: [.fileSizeKey])) ?? []
        return urls.reduce(0) { $0 + ((try? $1.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0) }
    }

    func exists(rsiNo: String, except id: UUID) -> Bool {
        let k = rsiNo.trimmingCharacters(in: .whitespaces).uppercased()
        guard !k.isEmpty else { return false }
        return slips.contains { $0.id != id && $0.rsiNo.uppercased() == k }
    }

    func search(_ q: String) -> [Slip] {
        let sorted = slips.sorted { $0.createdAt > $1.createdAt }
        let t = q.trimmingCharacters(in: .whitespaces)
        guard !t.isEmpty else { return sorted }
        return sorted.filter { s in
            s.rsiNo.localizedCaseInsensitiveContains(t)
            || s.requestDate.localizedCaseInsensitiveContains(t)
            || s.project.localizedCaseInsensitiveContains(t)
            || s.remark.localizedCaseInsensitiveContains(t)
            || s.items.contains {
                $0.packageNo.localizedCaseInsensitiveContains(t)
                || $0.desc.localizedCaseInsensitiveContains(t)
                || $0.tag.localizedCaseInsensitiveContains(t)
            }
        }
    }
}
