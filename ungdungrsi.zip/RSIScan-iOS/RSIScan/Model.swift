import SwiftUI
import Compression

struct Item: Identifiable, Codable, Hashable {
    var id = UUID()
    var packageNo: String = ""
    var desc: String = ""
    var tag: String = ""
    var unit: String = ""
    var qty: String = ""
    var actualQty: String? = nil   // số lượng thực nhận (viết tay, cột Actual H/O)
}

extension Item {
    var actualQtyText: String {
        get { actualQty ?? "" }
        set { actualQty = newValue }
    }
    var qtyLabel: String {
        let base = "\(qty) \(unit)"
        if let a = actualQty, !a.isEmpty { return base + " (nhận \(a))" }
        return base
    }

    func sameAs(_ o: Item) -> Bool {
        func k(_ x: String) -> String { x.trimmingCharacters(in: .whitespaces).uppercased() }
        return k(packageNo) == k(o.packageNo) && k(tag) == k(o.tag) && k(qty) == k(o.qty)
            && k(unit) == k(o.unit) && k(desc) == k(o.desc)
    }
}

enum Compression: String, CaseIterable, Identifiable {
    case small, balanced, sharp
    var id: String { rawValue }
    var title: String {
        switch self {
        case .small: return "Nhỏ nhất"
        case .balanced: return "Cân bằng"
        case .sharp: return "Rõ nét"
        }
    }
    var detail: String {
        switch self {
        case .small: return "Cạnh dài 1000px, chất lượng 40%. Khoảng 60 KB/ảnh, chữ nhỏ có thể khó đọc."
        case .balanced: return "Cạnh dài 1600px, chất lượng 50%. Khoảng 150 KB/ảnh."
        case .sharp: return "Cạnh dài 2200px, chất lượng 70%. Khoảng 330 KB/ảnh, chữ rõ nhất."
        }
    }
    var maxSide: CGFloat {
        switch self {
        case .small: return 1000
        case .balanced: return 1600
        case .sharp: return 2200
        }
    }
    var quality: CGFloat {
        switch self {
        case .small: return 0.4
        case .balanced: return 0.5
        case .sharp: return 0.7
        }
    }
    static let key = "compression"
    static var current: Compression {
        Compression(rawValue: UserDefaults.standard.string(forKey: key) ?? "") ?? .balanced
    }
}

func formatBytes(_ b: Int) -> String {
    let f = ByteCountFormatter()
    f.countStyle = .file
    f.allowedUnits = [.useKB, .useMB, .useGB]
    f.allowsNonnumericFormatting = false
    return f.string(fromByteCount: Int64(b))
}

struct Slip: Identifiable, Codable, Hashable {
    var id = UUID()
    var rsiNo: String = ""
    var requestDate: String = ""
    var project: String = ""
    var remark: String = ""
    var items: [Item] = []
    var pages: [String] = []      // tên file ảnh trong Documents/Scans
    var createdAt = Date()
    var receivedBy: String? = nil     // người nhận (viết tay)
    var receivedDate: String? = nil   // ngày nhận (viết tay)
    var requestedBy: String? = nil    // tên viết tay dưới chữ ký: Requested By
    var checkedBy: String? = nil      // Checked By
    var confirmedBy: String? = nil    // Confirmed By
    var approvedBy: String? = nil     // Approved By

    // Lưu trữ chính trên Google Drive (xem DriveSync.swift)
    var driveFolderID: String? = nil          // thư mục của phiếu trên Drive
    var driveJSONID: String? = nil            // file slip.json trên Drive
    var driveImages: [String: String]? = nil  // tên ảnh -> id file trên Drive (đã tải lên)
    var driveNames: [String: String]? = nil   // tên ảnh trong máy -> tên file hiện có trên Drive (RSI-123_1.jpg)
    var driveDirty: Bool? = nil               // true = có thay đổi chưa lên Drive
    var driveRev: Int? = nil                  // số lần sửa, để biết có sửa thêm trong lúc đang tải lên
}

extension Slip {
    var requestedByText: String { get { requestedBy ?? "" } set { requestedBy = newValue } }
    var checkedByText: String { get { checkedBy ?? "" } set { checkedBy = newValue } }
    var confirmedByText: String { get { confirmedBy ?? "" } set { confirmedBy = newValue } }
    var approvedByText: String { get { approvedBy ?? "" } set { approvedBy = newValue } }

    /// Điền các ô chữ viết tay còn trống từ kết quả đọc
    mutating func fillHand(_ p: Parsed) {
        if receivedByText.isEmpty { receivedByText = p.receivedBy }
        if receivedDateText.isEmpty { receivedDateText = p.receivedDate }
        if requestedByText.isEmpty { requestedByText = p.requestedBy }
        if checkedByText.isEmpty { checkedByText = p.checkedBy }
        if confirmedByText.isEmpty { confirmedByText = p.confirmedBy }
        if approvedByText.isEmpty { approvedByText = p.approvedBy }
        if remark.isEmpty { remark = p.remark }
    }

    mutating func fillHand(from o: Slip) {
        if receivedByText.isEmpty { receivedByText = o.receivedByText }
        if receivedDateText.isEmpty { receivedDateText = o.receivedDateText }
        if requestedByText.isEmpty { requestedByText = o.requestedByText }
        if checkedByText.isEmpty { checkedByText = o.checkedByText }
        if confirmedByText.isEmpty { confirmedByText = o.confirmedByText }
        if approvedByText.isEmpty { approvedByText = o.approvedByText }
    }

    var receivedByText: String {
        get { receivedBy ?? "" }
        set { receivedBy = newValue }
    }
    var receivedDateText: String {
        get { receivedDate ?? "" }
        set { receivedDate = newValue }
    }
}

final class Store: ObservableObject {
    static let maxPages = 10

    @Published var slips: [Slip] = []
    @Published var driveStatus: String = ""   // trạng thái đồng bộ Drive (rỗng = ổn)
    var syncing = false
    var syncAgain = false

    private let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    private var scansDir: URL { docs.appendingPathComponent("Scans", isDirectory: true) }
    private var dbURL: URL { docs.appendingPathComponent("slips.json") }
    var thumbsDir: URL { docs.appendingPathComponent("Thumbs", isDirectory: true) }

    init() {
        try? FileManager.default.createDirectory(at: scansDir, withIntermediateDirectories: true)
        try? FileManager.default.createDirectory(at: thumbsDir, withIntermediateDirectories: true)
        load()
    }

    func load() {
        guard let data = try? Data(contentsOf: dbURL),
              let list = try? JSONDecoder().decode([Slip].self, from: data) else { return }
        slips = list
    }

    func persist() {
        if let data = try? JSONEncoder().encode(slips) {
            try? data.write(to: dbURL, options: .atomic)
        }
    }

    func imageURL(_ name: String) -> URL { scansDir.appendingPathComponent(name) }

    func image(_ name: String) -> UIImage? {
        UIImage(contentsOfFile: imageURL(name).path)
    }

    private let cache = NSCache<NSString, UIImage>()

    func thumb(_ name: String) -> UIImage? {
        if let c = cache.object(forKey: name as NSString) { return c }
        let tURL = thumbsDir.appendingPathComponent(name)
        if let t = UIImage(contentsOfFile: tURL.path) {
            cache.setObject(t, forKey: name as NSString)
            return t
        }
        guard let img = image(name) else { return nil }
        let t = img.normalized(maxSide: 480)
        if let d = t.jpegData(compressionQuality: 0.7) { try? d.write(to: tURL, options: .atomic) }
        cache.setObject(t, forKey: name as NSString)
        return t
    }

    /// Lưu ảnh mới, trả về tên file
    func saveImage(_ img: UIImage) -> String? {
        let name = UUID().uuidString + ".jpg"
        let level = Compression.current
        let small = img.normalized(maxSide: level.maxSide)
        guard let data = small.jpegData(compressionQuality: level.quality) else { return nil }
        do { try data.write(to: imageURL(name), options: .atomic); return name }
        catch { return nil }
    }

    func removeImageFile(_ name: String) {
        try? FileManager.default.removeItem(at: imageURL(name))
        try? FileManager.default.removeItem(at: thumbsDir.appendingPathComponent(name))
        cache.removeObject(forKey: name as NSString)
    }

    func upsert(_ slip: Slip) {
        var s = slip
        let old = slips.first(where: { $0.id == s.id })
        // giữ thông tin Drive đã có (bản đang sửa trên màn hình có thể cũ hơn bản vừa đồng bộ)
        if let o = old {
            if s.driveFolderID == nil { s.driveFolderID = o.driveFolderID }
            if s.driveJSONID == nil { s.driveJSONID = o.driveJSONID }
            var m = o.driveImages ?? [:]
            for (k, v) in (s.driveImages ?? [:]) { m[k] = v }
            if !m.isEmpty { s.driveImages = m }
            var n = o.driveNames ?? [:]
            for (k, v) in (s.driveNames ?? [:]) { n[k] = v }
            if !n.isEmpty { s.driveNames = n }
        }
        if DriveConfig.primaryOn {
            s.driveDirty = true
            s.driveRev = (old?.driveRev ?? 0) + 1
        }
        if let o = old {
            let d = ActivityLog.diff(o, s)
            if !d.isEmpty { ActivityLog.shared.add(.edited, rsi: s.rsiNo, detail: d, slipID: s.id) }
        } else {
            ActivityLog.shared.add(.created, rsi: s.rsiNo, detail: "\(s.pages.count) ảnh, \(s.items.count) kiện hàng", slipID: s.id)
        }
        if let i = slips.firstIndex(where: { $0.id == s.id }) {
            slips[i] = s
        } else {
            slips.append(s)
        }
        persist()
        syncSoon()
    }

    func delete(_ slip: Slip) {
        ActivityLog.shared.add(.deleted, rsi: slip.rsiNo, slipID: slip.id)
        if let fid = slip.driveFolderID { DriveQueue.addDelete(fid) }
        for p in slip.pages { removeImageFile(p) }
        slips.removeAll { $0.id == slip.id }
        persist()
        syncSoon()
    }

    func existing(rsiNo: String, except id: UUID) -> Slip? {
        let k = rsiNo.trimmingCharacters(in: .whitespaces).uppercased()
        guard !k.isEmpty else { return nil }
        return slips.first { $0.id != id && $0.rsiNo.uppercased() == k }
    }

    func fileSize(_ name: String) -> Int {
        guard let a = try? FileManager.default.attributesOfItem(atPath: imageURL(name).path),
              let n = a[.size] as? NSNumber else { return 0 }
        return n.intValue
    }

    func slipBytes(_ s: Slip) -> Int {
        s.pages.reduce(0) { $0 + fileSize($1) }
    }

    func storageBytes() -> Int {
        let names = (try? FileManager.default.contentsOfDirectory(atPath: scansDir.path)) ?? []
        return names.reduce(0) { $0 + fileSize($1) }
    }

    func exists(rsiNo: String, except id: UUID) -> Bool {
        let k = rsiNo.trimmingCharacters(in: .whitespaces).uppercased()
        guard !k.isEmpty else { return false }
        return slips.contains { $0.id != id && $0.rsiNo.uppercased() == k }
    }

    func search(_ q: String) -> [Slip] { hits(q).map { $0.slip } }
}

// MARK: - Xuất toàn bộ (ảnh + thông tin)

extension Store {
    /// Tạo file .zip gồm: slips.csv (mở bằng Excel), slips.json (bản sao dữ liệu), thư mục Anh/ (toàn bộ ảnh phiếu)
    func exportAll() -> URL? {
        let fm = FileManager.default
        let f = DateFormatter()
        f.dateFormat = "yyyyMMdd-HHmm"
        let name = "RSIScan-\(f.string(from: Date()))"
        let root = fm.temporaryDirectory.appendingPathComponent(name, isDirectory: true)
        try? fm.removeItem(at: root)
        let imgDir = root.appendingPathComponent("Anh", isDirectory: true)
        do { try fm.createDirectory(at: imgDir, withIntermediateDirectories: true) } catch { return nil }

        func esc(_ s: String) -> String {
            "\"" + s.replacingOccurrences(of: "\"", with: "\"\"") + "\""
        }
        let head = ["Số RSI", "Ngày yêu cầu", "Dự án", "Người nhận", "Ngày nhận", "Yêu cầu (Requested By)",
                    "Kiểm tra (Checked By)", "Xác nhận (Confirmed By)", "Duyệt (Approved By)", "Ghi chú",
                    "Package No", "Mô tả hàng", "Tag/Serial", "Đơn vị", "Số lượng", "SL thực nhận", "File ảnh"]
        var csv = "\u{FEFF}" + head.map(esc).joined(separator: ",") + "\n"

        for s in slips.sorted(by: { $0.createdAt < $1.createdAt }) {
            let safe = (s.rsiNo.isEmpty ? "phieu" : s.rsiNo).replacingOccurrences(of: "/", with: "-")
            var files: [String] = []
            for (i, p) in s.pages.enumerated() {
                let fn = "\(safe)_\(i + 1).jpg"
                let dst = imgDir.appendingPathComponent(fn)
                try? fm.removeItem(at: dst)
                if (try? fm.copyItem(at: imageURL(p), to: dst)) != nil { files.append(fn) }
            }
            let slipCols = [s.rsiNo, s.requestDate, s.project, s.receivedByText, s.receivedDateText,
                            s.requestedByText, s.checkedByText, s.confirmedByText, s.approvedByText, s.remark]
            let items = s.items.isEmpty ? [Item()] : s.items
            for it in items {
                let cols = slipCols + [it.packageNo, it.desc, it.tag, it.unit, it.qty, it.actualQtyText,
                                       files.joined(separator: "; ")]
                csv += cols.map(esc).joined(separator: ",") + "\n"
            }
        }
        do {
            try csv.write(to: root.appendingPathComponent("slips.csv"), atomically: true, encoding: .utf8)
        } catch { return nil }
        try? fm.copyItem(at: dbURL, to: root.appendingPathComponent("slips.json"))

        var zipURL: URL? = nil
        var err: NSError?
        NSFileCoordinator().coordinate(readingItemAt: root, options: [.forUploading], error: &err) { tmp in
            let dst = fm.temporaryDirectory.appendingPathComponent(name + ".zip")
            try? fm.removeItem(at: dst)
            if (try? fm.copyItem(at: tmp, to: dst)) != nil { zipURL = dst }
        }
        try? fm.removeItem(at: root)
        return zipURL
    }
}

// MARK: - Đọc file zip (không cần thư viện ngoài)

struct ZipEntry {
    let name: String
    let method: Int
    let compSize: Int
    let size: Int
    let offset: Int
}

enum ZipReader {
    private static func u16(_ d: Data, _ o: Int) -> Int {
        Int(d[d.startIndex + o]) | (Int(d[d.startIndex + o + 1]) << 8)
    }
    private static func u32(_ d: Data, _ o: Int) -> Int {
        u16(d, o) | (u16(d, o + 2) << 16)
    }

    static func entries(_ d: Data) -> [ZipEntry]? {
        let n = d.count
        guard n >= 22 else { return nil }
        var eocd = -1
        var i = n - 22
        let lowest = max(0, n - 22 - 65535)
        while i >= lowest {
            if u32(d, i) == 0x06054b50 { eocd = i; break }
            i -= 1
        }
        guard eocd >= 0 else { return nil }
        let count = u16(d, eocd + 10)
        var p = u32(d, eocd + 16)
        var out: [ZipEntry] = []
        for _ in 0..<count {
            guard p + 46 <= n, u32(d, p) == 0x02014b50 else { break }
            let method = u16(d, p + 10)
            let cs = u32(d, p + 20), us = u32(d, p + 24)
            let nl = u16(d, p + 28), el = u16(d, p + 30), cl = u16(d, p + 32)
            let lo = u32(d, p + 42)
            guard p + 46 + nl <= n else { break }
            let nameData = d.subdata(in: (d.startIndex + p + 46)..<(d.startIndex + p + 46 + nl))
            let name = String(data: nameData, encoding: .utf8) ?? ""
            out.append(ZipEntry(name: name, method: method, compSize: cs, size: us, offset: lo))
            p += 46 + nl + el + cl
        }
        return out
    }

    static func data(_ d: Data, _ e: ZipEntry) -> Data? {
        let n = d.count
        let o = e.offset
        guard o + 30 <= n, u32(d, o) == 0x04034b50 else { return nil }
        let nl = u16(d, o + 26), el = u16(d, o + 28)
        let start = o + 30 + nl + el
        guard start + e.compSize <= n else { return nil }
        if e.size == 0 { return Data() }
        let raw = d.subdata(in: (d.startIndex + start)..<(d.startIndex + start + e.compSize))
        if e.method == 0 { return raw }
        guard e.method == 8 else { return nil }
        let dst = UnsafeMutablePointer<UInt8>.allocate(capacity: e.size)
        defer { dst.deallocate() }
        let written = raw.withUnsafeBytes { (src: UnsafeRawBufferPointer) -> Int in
            guard let base = src.bindMemory(to: UInt8.self).baseAddress else { return 0 }
            return compression_decode_buffer(dst, e.size, base, e.compSize, nil, COMPRESSION_ZLIB)
        }
        guard written == e.size else { return nil }
        return Data(bytes: dst, count: written)
    }
}

// MARK: - Khôi phục từ file zip đã xuất

struct ImportResult {
    var slips: [Slip] = []
    var message = ""
}

extension Store {
    /// Đọc zip (slips.json + Anh/), ghi ảnh vào thư mục Scans, trả về danh sách phiếu mới để thêm vào.
    /// Phiếu đã có trong máy (cùng id) được bỏ qua, không ghi đè.
    func prepareImport(url: URL, existingIDs: Set<UUID>) -> ImportResult {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }

        guard let d = try? Data(contentsOf: url, options: .mappedIfSafe),
              let es = ZipReader.entries(d) else {
            return ImportResult(message: "Không đọc được file zip này.")
        }
        guard let je = es.first(where: { $0.name.hasSuffix("slips.json") }),
              let jd = ZipReader.data(d, je),
              let list = try? JSONDecoder().decode([Slip].self, from: jd) else {
            return ImportResult(message: "Không thấy dữ liệu phiếu (slips.json) trong file zip.")
        }

        var imgMap: [String: ZipEntry] = [:]
        for e in es where e.name.contains("Anh/") && !e.name.hasSuffix("/") {
            imgMap[(e.name as NSString).lastPathComponent] = e
        }

        var res = ImportResult()
        var skipped = 0, imgs = 0, missing = 0
        for var s in list {
            if existingIDs.contains(s.id) { skipped += 1; continue }
            let safe = (s.rsiNo.isEmpty ? "phieu" : s.rsiNo).replacingOccurrences(of: "/", with: "-")
            var pages: [String] = []
            for (i, old) in s.pages.enumerated() {
                if FileManager.default.fileExists(atPath: imageURL(old).path) { pages.append(old); continue }
                if let e = imgMap["\(safe)_\(i + 1).jpg"], let data = ZipReader.data(d, e),
                   (try? data.write(to: imageURL(old), options: .atomic)) != nil {
                    pages.append(old)
                    imgs += 1
                } else {
                    missing += 1
                }
            }
            s.pages = pages
            res.slips.append(s)
        }

        var msg = "Đã khôi phục \(res.slips.count) phiếu, \(imgs) ảnh."
        if skipped > 0 { msg += " Bỏ qua \(skipped) phiếu đã có trong máy." }
        if missing > 0 { msg += " Thiếu \(missing) ảnh trong file zip." }
        res.message = msg
        return res
    }
}

// MARK: - Tự động sao lưu vào thư mục người dùng chọn (Tệp / iCloud Drive / Google Drive)

enum BackupPrefs {
    static let bookmarkKey = "backupFolderBookmark"
    static let nameKey = "backupFolderName"
    static let autoKey = "backupAuto"
    static let daysKey = "backupDays"
    static let lastKey = "backupLast"
    static let keep = 4
    static var running = false   // chỉ đọc/ghi trên luồng chính
}

extension Store {
    var hasBackupFolder: Bool { UserDefaults.standard.data(forKey: BackupPrefs.bookmarkKey) != nil }

    func saveBackupFolder(_ url: URL) -> Bool {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        guard let data = try? url.bookmarkData() else { return false }
        UserDefaults.standard.set(data, forKey: BackupPrefs.bookmarkKey)
        UserDefaults.standard.set(url.lastPathComponent, forKey: BackupPrefs.nameKey)
        return true
    }

    /// Tạo file zip và ghi vào thư mục đã chọn, giữ lại BackupPrefs.keep bản mới nhất.
    func backupNow() -> String {
        guard let bm = UserDefaults.standard.data(forKey: BackupPrefs.bookmarkKey) else {
            return "Chưa chọn thư mục sao lưu."
        }
        var stale = false
        guard let folder = try? URL(resolvingBookmarkData: bm, bookmarkDataIsStale: &stale) else {
            return "Không mở được thư mục sao lưu. Hãy chọn lại thư mục."
        }
        let scoped = folder.startAccessingSecurityScopedResource()
        defer { if scoped { folder.stopAccessingSecurityScopedResource() } }

        guard let zip = exportAll() else { return "Không tạo được file sao lưu." }
        defer { try? FileManager.default.removeItem(at: zip) }

        let fm = FileManager.default
        let dst = folder.appendingPathComponent(zip.lastPathComponent)
        var err: NSError?
        var ok = false
        NSFileCoordinator().coordinate(writingItemAt: dst, options: .forReplacing, error: &err) { u in
            try? fm.removeItem(at: u)
            ok = (try? fm.copyItem(at: zip, to: u)) != nil
        }
        guard ok else { return "Không ghi được vào thư mục sao lưu. Hãy chọn lại thư mục." }

        if let files = try? fm.contentsOfDirectory(at: folder, includingPropertiesForKeys: nil) {
            let olds = files
                .filter { $0.lastPathComponent.hasPrefix("RSIScan-") && $0.pathExtension == "zip" }
                .sorted { $0.lastPathComponent > $1.lastPathComponent }
            for f in olds.dropFirst(BackupPrefs.keep) {
                var e2: NSError?
                NSFileCoordinator().coordinate(writingItemAt: f, options: .forDeleting, error: &e2) { u in
                    try? fm.removeItem(at: u)
                }
            }
        }
        UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: BackupPrefs.lastKey)
        return "Đã sao lưu: \(zip.lastPathComponent)"
    }

    /// Gọi khi mở app / quay lại app: nếu bật tự sao lưu và đã đến hạn thì sao lưu nền.
    func autoBackupIfDue() {
        let d = UserDefaults.standard
        // Drive là nơi lưu chính thì không cần sao lưu zip nữa
        guard d.bool(forKey: BackupPrefs.autoKey), hasBackupFolder || hasDrive, !slips.isEmpty,
              !DriveConfig.primaryOn, !BackupPrefs.running else { return }
        let days = d.integer(forKey: BackupPrefs.daysKey) == 0 ? 7 : d.integer(forKey: BackupPrefs.daysKey)
        let last = d.double(forKey: BackupPrefs.lastKey)
        if Date().timeIntervalSince1970 - last < Double(days) * 86400 { return }
        BackupPrefs.running = true
        Task.detached(priority: .utility) { [self] in
            _ = await self.backupAny()
            await MainActor.run { BackupPrefs.running = false }
        }
    }
}

// MARK: - Sắp xếp theo ngày của phiếu RSI (mới nhất ở trên)

enum SlipDate {
    private static let fmts: [DateFormatter] = {
        ["d-MMM-yyyy", "d-MMM-yy", "d/M/yyyy", "d/M/yy", "d-M-yyyy", "d.M.yyyy", "d MMM yyyy", "yyyy-MM-dd"].map {
            let f = DateFormatter()
            f.locale = Locale(identifier: "en_US_POSIX")
            f.dateFormat = $0
            return f
        }
    }()

    /// Đọc ngày yêu cầu của phiếu (28-Sep-2026, 02/09/2026, ...). Ngày/tháng theo thứ tự ngày trước.
    static func parse(_ s: String) -> Date? {
        let t = s.trimmingCharacters(in: .whitespaces)
        guard !t.isEmpty else { return nil }
        for cand in [t, t.lowercased().capitalized] {
            for f in fmts {
                if let d = f.date(from: cand) { return d }
            }
        }
        return nil
    }
}

extension Store {
    /// Phiếu sắp theo ngày RSI giảm dần (ngày mới nhất ở trên). Phiếu không đọc được ngày thì dùng ngày quét.
    func slipsNewestFirst() -> [Slip] {
        slips.map { ($0, SlipDate.parse($0.requestDate) ?? $0.createdAt) }
            .sorted { $0.1 != $1.1 ? $0.1 > $1.1 : $0.0.createdAt > $1.0.createdAt }
            .map { $0.0 }
    }
}
