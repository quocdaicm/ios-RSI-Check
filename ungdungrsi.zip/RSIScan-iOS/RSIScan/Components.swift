import SwiftUI

// MARK: - Bộ thành phần giao diện dùng chung
// Muốn đổi diện mạo: sửa Theme.swift (màu, bo góc, khoảng cách) hoặc các thành phần dưới đây.

extension View {
    /// Nền trang chuẩn + giới hạn cỡ chữ.
    func screen() -> some View {
        self
            .background(Theme.bg.ignoresSafeArea())
            .dynamicTypeSize(...Theme.maxType)
    }

    /// Form / List với nền của app.
    func formScreen() -> some View {
        self
            .scrollContentBackground(.hidden)
            .background(Theme.bg.ignoresSafeArea())
            .dynamicTypeSize(...Theme.maxType)
    }

    /// Thẻ một dòng trong danh sách: lề trong + viền + bóng nhẹ.
    func rowCard() -> some View {
        self
            .padding(Theme.Space.inner)
            .frame(maxWidth: .infinity, alignment: .leading)
            .card()
            .shadow(color: .black.opacity(0.04), radius: 6, y: 2)
    }
}

// MARK: Tiêu đề nhóm

struct SectionHeader: View {
    let text: String
    init(_ text: String) { self.text = text }

    var body: some View {
        Text(text)
            .font(.system(.subheadline, design: .rounded).weight(.bold))
            .foregroundColor(.secondary)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.top, 6)
    }
}

// MARK: Khối đầu trang (nền xanh có sóng)

struct HeroCard<Content: View>: View {
    var art: Bool = false
    @ViewBuilder var content: () -> Content

    var body: some View {
        content()
            .foregroundColor(.white)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 18)
            .padding(.top, 18)
            .padding(.bottom, 38)
            .background(
                HeroBackdrop(animated: true, art: art)
                    .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.hero, style: .continuous))
                    .shadow(color: Theme.primaryDark.opacity(0.30), radius: 12, y: 6)
            )
    }
}

// MARK: Nút

enum AppButtonKind { case primary, soft, danger }

struct AppButtonStyle: ButtonStyle {
    var kind: AppButtonKind = .primary
    var fill: Bool = true

    func makeBody(configuration: Configuration) -> some View {
        let shape = RoundedRectangle(cornerRadius: Theme.Radius.control, style: .continuous)
        configuration.label
            .font(.subheadline.weight(.semibold))
            .frame(maxWidth: fill ? .infinity : nil)
            .padding(.horizontal, fill ? 0 : 18)
            .padding(.vertical, 13)
            .foregroundColor(fg)
            .background(bg, in: shape)
            .shadow(color: kind == .primary ? Theme.primaryDark.opacity(0.25) : .clear, radius: 6, y: 3)
            .opacity(configuration.isPressed ? 0.8 : 1)
            .scaleEffect(configuration.isPressed ? 0.98 : 1)
    }

    private var fg: Color {
        switch kind {
        case .primary: return .white
        case .soft: return Theme.primaryDark
        case .danger: return Theme.red
        }
    }

    private var bg: AnyShapeStyle {
        switch kind {
        case .primary: return AnyShapeStyle(Theme.heroGradient)
        case .soft: return AnyShapeStyle(Theme.primarySoft)
        case .danger: return AnyShapeStyle(Theme.redSoft)
        }
    }
}

extension ButtonStyle where Self == AppButtonStyle {
    static func app(_ kind: AppButtonKind, fill: Bool = true) -> AppButtonStyle {
        AppButtonStyle(kind: kind, fill: fill)
    }
}

// MARK: Nút tròn nổi (chụp / chọn ảnh)

struct FloatingIcon: View {
    let systemName: String
    var prominent = false

    var body: some View {
        Image(systemName: systemName)
            .font(.system(size: prominent ? 28 : 20, weight: .semibold))
            .foregroundColor(prominent ? .white : Theme.primaryDark)
            .frame(width: prominent ? 66 : 52, height: prominent ? 66 : 52)
            .background(prominent ? AnyShapeStyle(Theme.heroGradient) : AnyShapeStyle(Theme.card))
            .clipShape(Circle())
            .overlay(Circle().stroke(prominent ? Color.clear : Theme.line, lineWidth: 1))
            .shadow(color: .black.opacity(prominent ? 0.22 : 0.10), radius: prominent ? 10 : 6, y: 4)
    }
}

// MARK: Ảnh thu nhỏ của phiếu

struct SlipThumb: View {
    @EnvironmentObject var store: Store
    let slip: Slip
    var width: CGFloat = 76
    var height: CGFloat = 100

    var body: some View {
        Group {
            if let n = slip.pages.first, let img = store.thumb(n) {
                Image(uiImage: img).resizable().scaledToFill()
            } else {
                ZStack {
                    Theme.primarySoft
                    Image(systemName: "doc.text").font(.title3).foregroundColor(Theme.primary)
                }
            }
        }
        .frame(width: width, height: height)
        .clipShape(RoundedRectangle(cornerRadius: Theme.Radius.control, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: Theme.Radius.control, style: .continuous)
            .stroke(Theme.line, lineWidth: 1))
        .shadow(color: .black.opacity(0.10), radius: 5, y: 2)
        .task(id: slip.id) { await store.ensureFirstThumb(slip) }   // phiếu tải từ chỉ mục: lấy ảnh thu nhỏ khi hiện
    }
}

// MARK: Dòng thông tin có icon (khối ký nhận…)

struct InfoRow: View {
    let icon: String
    let label: String
    let value: String

    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(Theme.primary)
                .frame(width: 20)
            Text(label)
                .font(.footnote)
                .foregroundColor(.secondary)
                .frame(width: 88, alignment: .leading)
            Text(value)
                .font(.subheadline.weight(.medium))
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.vertical, 9)
    }
}

// MARK: Thông tin tác giả (cuối trang Cài đặt)

struct AuthorFooter: View {
    static let name = "Lâm Quốc Đại"
    static let email = "quocdai.net@gmail.com"

    private var version: String {
        let v = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0"
        let b = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "1"
        return "Phiên bản \(v) (\(b))"
    }

    var body: some View {
        VStack(spacing: 14) {
            HStack(spacing: 6) {
                Capsule().fill(Theme.line).frame(width: 36, height: 2)
                Image(systemName: "leaf.fill").font(.system(size: 11)).foregroundColor(Theme.primary.opacity(0.7))
                Capsule().fill(Theme.line).frame(width: 36, height: 2)
            }

            VStack(spacing: 12) {
                Text("LĐ")
                    .font(.system(size: 22, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                    .frame(width: 60, height: 60)
                    .background(Theme.heroGradient, in: Circle())
                    .overlay(Circle().stroke(Color.white.opacity(0.5), lineWidth: 2))
                    .shadow(color: Theme.primaryDark.opacity(0.30), radius: 8, y: 4)

                VStack(spacing: 3) {
                    Text("THIẾT KẾ & PHÁT TRIỂN")
                        .font(.system(size: 10, weight: .semibold))
                        .tracking(1.4)
                        .foregroundColor(.secondary)
                    Text(Self.name)
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                        .foregroundColor(.primary)
                }

                Link(destination: URL(string: "mailto:\(Self.email)")!) {
                    Label(Self.email, systemImage: "envelope.fill")
                        .font(.system(size: 14, weight: .semibold))
                        .lineLimit(1)
                        .minimumScaleFactor(0.75)
                        .foregroundColor(Theme.primaryDark)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(Theme.primarySoft, in: Capsule())
                }
            }
            .padding(.vertical, 20)
            .frame(maxWidth: .infinity)
            .card()
            .shadow(color: .black.opacity(0.04), radius: 6, y: 2)

            VStack(spacing: 2) {
                Text("Phiếu RSI · Doosan")
                Text(version)
            }
            .font(.caption2)
            .foregroundColor(.secondary)
        }
        .padding(.top, 8)
        .padding(.bottom, 24)
        .padding(.horizontal, 4)
    }
}

// MARK: Vòng sóng lan toả liên tục (gợi ý "chạm vào đây")

struct PulseRing: View {
    var color: Color = .white
    @State private var go = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        ZStack {
            ring(delay: 0)
            ring(delay: 0.9)
        }
        .onAppear { if !reduceMotion { go = true } }
        .allowsHitTesting(false)
    }

    private func ring(delay: Double) -> some View {
        Circle()
            .stroke(color.opacity(0.9), lineWidth: 2)
            .scaleEffect(go ? 1.75 : 1)
            .opacity(go ? 0 : 0.8)
            .animation(.easeOut(duration: 1.8).repeatForever(autoreverses: false).delay(delay), value: go)
    }
}
