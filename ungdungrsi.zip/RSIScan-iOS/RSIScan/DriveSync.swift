import SwiftUI

// MARK: - Drive là nơi lưu chính
//
// Mỗi phiếu = một thư mục con trong "RSIScan" trên Drive, chứa các ảnh (UUID.jpg) và slip.json.
// Trong máy chỉ giữ danh sách phiếu (để tìm kiếm) và ảnh thu nhỏ. Ảnh đầy đủ chỉ tải về khi mở xem / xuất PDF.
// Không có mạng: phiếu nằm chờ (driveDirty) và ảnh gốc vẫn còn trong máy, có mạng lại thì tự tải lên.
// Chỉ xoá ảnh trong máy SAU KHI ảnh đã lên Drive thành công.

enum DriveQueue {
    static let key = "drivePendingDeletes"
    static var deletes: [String] { UserDefaults.standard.stringArray(forKey: key) ?? [] }
    static func addDelete(_ id: String) {
        var a = deletes
        if !a.contains(id) { a.append(id) }
        UserDefaults.standard.set(a, forKey: key)
    }
    static func removeDelete(_ id: String) {
        UserDefaults.standard.set(deletes.filter { $0 != id }, forKey: key)
    }
}

extension Store {
    func folderName(for s: Slip) -> String {
        let base = (s.rsiNo.isEmpty ? "phieu" : s.rsiNo)
            .replacingOccurrences(of: "/", with: "-")
            .replacingOccurrences(of: "'", with: "")
        return base + " (" + String(s.id.uuidString.prefix(8)) + ")"
    }

    var pendingSyncCount: Int {
        slips.filter { $0.driveDirty == true }.count + DriveQueue.deletes.count
    }

    /// Đánh dấu mọi phiếu cần tải lên (dùng khi chuyển phiếu cũ lên Drive).
    func markAllDirty() {
        for i in slips.indices {
            slips[i].driveDirty = true
            slips[i].driveRev = (slips[i].driveRev ?? 0) + 1
        }
        persist()
    }

    func syncSoon() {
        guard DriveConfig.primaryOn else { return }
        Task { await self.syncPending() }
    }

    /// Mở app / quay lại app.
    func driveOnActive() {
        guard DriveConfig.primaryOn else { return }
        purgeSynced()
        syncSoon()
        if slips.isEmpty {
            Task { _ = await self.pullFromDrive() }
        }
    }

    @MainActor
    func syncPending() async {
        guard DriveConfig.primaryOn else { return }
        if syncing { syncAgain = true; return }
        syncing = true
        repeat {
            syncAgain = false
            await syncOnce()
        } while syncAgain
        syncing = false
    }

    @MainActor
    func syncOnce() async {
        // 1. Phiếu đã xoá trong máy thì xoá luôn thư mục trên Drive
        for fid in DriveQueue.deletes {
            do {
                try await DriveClient.shared.deleteFile(fid)
                DriveQueue.removeDelete(fid)
            } catch {
                driveStatus = "Chưa đồng bộ được với Drive: " + error.localizedDescription
                return
            }
        }
        // 2. Phiếu mới / có sửa
        let todo = slips.filter { $0.driveDirty == true }
        if todo.isEmpty { driveStatus = ""; return }
        var done = 0
        for s in todo {
            driveStatus = "Đang đưa lên Drive \(done + 1)/\(todo.count)..."
            do {
                try await uploadSlip(s)
                done += 1
            } catch {
                driveStatus = "Chưa lưu được lên Drive, \(todo.count - done) phiếu đang chờ. " + error.localizedDescription
                return
            }
        }
        driveStatus = ""
    }

    @MainActor
    func uploadSlip(_ s0: Slip) async throws {
        let client = DriveClient.shared
        let rev = s0.driveRev
        let root = try await client.ensureRoot()
        var s = s0
        let fname = folderName(for: s)

        var folder = s.driveFolderID ?? ""
        var needNew = folder.isEmpty
        if !needNew {
            let ok = await client.exists(folder)
            needNew = !ok
        }
        if needNew {
            folder = try await client.createFolder(name: fname, parent: root)
            s.driveImages = [:]
            s.driveJSONID = nil
        } else {
            await client.rename(folder, to: fname)
        }

        // ảnh mới
        var imgs = s.driveImages ?? [:]
        for name in s.pages where imgs[name] == nil {
            guard let data = try? Data(contentsOf: imageURL(name)) else { continue }
            imgs[name] = try await client.uploadData(name: name, mime: "image/jpeg", data: data,
                                                     parent: folder, existingID: nil)
        }
        // ảnh đã bị xoá khỏi phiếu
        for (name, id) in imgs where !s.pages.contains(name) {
            try? await client.deleteFile(id)
            imgs[name] = nil
        }

        // thông tin phiếu
        var out = s
        out.driveFolderID = folder
        out.driveImages = imgs
        out.driveDirty = nil
        let json = try JSONEncoder().encode(out)
        let jid = try await client.uploadData(name: "slip.json", mime: "application/json", data: json,
                                              parent: folder, existingID: s.driveJSONID)

        // ghi kết quả vào danh sách phiếu
        guard let i = slips.firstIndex(where: { $0.id == s.id }) else {
            DriveQueue.addDelete(folder)   // phiếu đã bị xoá trong lúc tải lên
            return
        }
        slips[i].driveFolderID = folder
        slips[i].driveJSONID = jid
        slips[i].driveImages = imgs
        if slips[i].driveRev == rev {
            slips[i].driveDirty = nil
            persist()
            purgeLocal(slips[i])
        } else {
            persist()
            syncAgain = true   // có sửa thêm trong lúc đang tải lên
        }
    }

    /// Xoá ảnh đầy đủ trong máy của các trang đã có trên Drive (giữ lại ảnh thu nhỏ).
    func purgeLocal(_ s: Slip) {
        let imgs = s.driveImages ?? [:]
        for n in s.pages where imgs[n] != nil {
            _ = thumb(n)
            try? FileManager.default.removeItem(at: imageURL(n))
        }
    }

    func purgeSynced() {
        for s in slips where s.driveDirty != true && s.driveFolderID != nil {
            purgeLocal(s)
        }
    }

    // MARK: Lấy ảnh từ Drive khi cần

    /// Ảnh đầy đủ: có trong máy thì dùng, không thì tải từ Drive (để tạm trong máy).
    @MainActor
    func fullImage(_ name: String) async -> UIImage? {
        if let im = image(name) { return im }
        guard let s = slips.first(where: { $0.pages.contains(name) }),
              let id = s.driveImages?[name],
              let data = try? await DriveClient.shared.downloadData(id) else { return nil }
        try? data.write(to: imageURL(name), options: .atomic)
        return UIImage(data: data)
    }

    @MainActor
    func ensureLocal(_ names: [String]) async {
        for n in names where !FileManager.default.fileExists(atPath: imageURL(n).path) {
            _ = await fullImage(n)
        }
    }

    /// Ảnh thu nhỏ còn thiếu (máy mới / phiếu tải về từ Drive).
    @MainActor
    func ensureThumbs(_ s: Slip) async {
        var changed = false
        for n in s.pages {
            let t = thumbsDir.appendingPathComponent(n)
            if FileManager.default.fileExists(atPath: t.path) { continue }
            if FileManager.default.fileExists(atPath: imageURL(n).path) { continue }
            guard let id = s.driveImages?[n],
                  let d = try? await DriveClient.shared.downloadData(id),
                  let im = UIImage(data: d),
                  let td = im.normalized(maxSide: 480).jpegData(compressionQuality: 0.7) else { continue }
            try? td.write(to: t, options: .atomic)
            changed = true
        }
        if changed { objectWillChange.send() }
    }

    // MARK: Tải lại danh sách phiếu từ Drive (máy mới, cài lại app)

    @MainActor
    func pullFromDrive() async -> String {
        guard DriveConfig.signedIn else { return "Chưa đăng nhập Google Drive." }
        let client = DriveClient.shared
        do {
            let root = try await client.ensureRoot()
            let folders = try await client.listChildren(root).filter { $0.mimeType == DriveClient.folderMime }
            let have = Set(slips.map { $0.id })
            var added = 0
            for f in folders {
                let kids = try await client.listChildren(f.id)
                guard let j = kids.first(where: { $0.name == "slip.json" }),
                      let data = try? await client.downloadData(j.id),
                      var s = try? JSONDecoder().decode(Slip.self, from: data) else { continue }
                if have.contains(s.id) { continue }
                var m: [String: String] = [:]
                for k in kids where k.name != "slip.json" { m[k.name] = k.id }
                s.driveFolderID = f.id
                s.driveJSONID = j.id
                s.driveImages = m
                s.driveDirty = nil
                // ảnh thu nhỏ trang đầu cho danh sách
                if let first = s.pages.first, let id = m[first],
                   let d = try? await client.downloadData(id), let im = UIImage(data: d),
                   let td = im.normalized(maxSide: 480).jpegData(compressionQuality: 0.7) {
                    try? td.write(to: thumbsDir.appendingPathComponent(first), options: .atomic)
                }
                slips.append(s)
                added += 1
            }
            persist()
            return added > 0 ? "Đã tải về \(added) phiếu từ Drive." : "Không có phiếu mới trên Drive."
        } catch {
            return error.localizedDescription
        }
    }
}
