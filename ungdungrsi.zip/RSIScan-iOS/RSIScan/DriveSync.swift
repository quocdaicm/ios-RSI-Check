import SwiftUI

// MARK: - Drive là nơi lưu chính
//
// Mỗi phiếu = một thư mục con trong "RSIScan" trên Drive, chứa các ảnh (UUID.jpg) và slip.json.
// Trong máy chỉ giữ danh sách phiếu (để tìm kiếm) và ảnh thu nhỏ. Ảnh đầy đủ chỉ tải về khi mở xem / xuất PDF.
// Không có mạng: phiếu nằm chờ (driveDirty) và ảnh gốc vẫn còn trong máy, có mạng lại thì tự tải lên.
// Chỉ xoá ảnh trong máy SAU KHI ảnh đã lên Drive thành công.

/// Tiến trình một lần tải lên / tải về (hiện thanh + "3/12 phiếu").
struct TransferProgress: Equatable {
    var title: String
    var done: Int = 0
    var total: Int = 0          // 0 = chưa biết tổng, hiện vòng xoay
    var detail: String = ""
    var fraction: Double? { total > 0 ? min(1, Double(done) / Double(total)) : nil }
}

/// Khung hiển thị tiến trình dùng chung cho các màn hình Cài đặt / Bản sao lưu.
struct ProgressCard: View {
    let p: TransferProgress
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(p.title).font(.subheadline)
            if let f = p.fraction {
                ProgressView(value: f)
                Text("\(p.done)/\(p.total)" + (p.detail.isEmpty ? "" : " · " + p.detail))
                    .font(.caption).foregroundColor(.secondary).lineLimit(1)
            } else {
                HStack(spacing: 8) {
                    ProgressView()
                    if !p.detail.isEmpty { Text(p.detail).font(.caption).foregroundColor(.secondary) }
                }
            }
        }
        .padding(.vertical, 2)
    }
}

/// Chỉ mục toàn bộ phiếu lưu ở "RSIScan/index.json": cài lại app chỉ cần tải 1 file này.
struct DriveIndex: Codable {
    var version = 1
    var slips: [Slip] = []
}

/// Thay đổi chờ ghi vào index.json (id phiếu -> "u" thêm/sửa, "r" xoá). Lưu trong máy nên thoát app vẫn giữ.
enum IndexQueue {
    static let key = "driveIndexPending"
    static var all: [String: String] { UserDefaults.standard.dictionary(forKey: key) as? [String: String] ?? [:] }
    static func mark(_ id: UUID, _ op: String) {
        var d = all
        d[id.uuidString] = op
        UserDefaults.standard.set(d, forKey: key)
    }
    /// Xoá các mục đã ghi xong (giữ lại mục bị đổi trong lúc đang ghi).
    static func clear(_ done: [String: String]) {
        var d = all
        for (k, v) in done where d[k] == v { d[k] = nil }
        UserDefaults.standard.set(d, forKey: key)
    }
}

/// Thanh tiến trình mảnh ở đầu danh sách phiếu.
struct MiniProgressBar: View {
    let p: TransferProgress
    var body: some View {
        VStack(spacing: 2) {
            if let f = p.fraction {
                ProgressView(value: f)
            } else {
                ProgressView().progressViewStyle(.linear)
            }
            Text(p.total > 0 ? "\(p.title) \(p.done)/\(p.total)" : p.title)
                .font(.system(size: 10)).foregroundColor(.secondary).lineLimit(1)
        }
        .padding(.horizontal, 16).padding(.vertical, 4)
        .background(Theme.bg)
    }
}

enum DriveQueue {
    static let key = "drivePendingDeletes"
    static var deletes: [String] { UserDefaults.standard.stringArray(forKey: key) ?? [] }
    static func addDelete(_ id: String) {
        var a = deletes
        if !a.contains(id) { a.append(id) }
        UserDefaults.standard.set(a, forKey: key)
    }
    static func removeDelete(_ id: String) {
        UserDefaults.standard.set(deletes.filter { $0 != id }, forKey: key)
    }
}

extension Store {
    func folderName(for s: Slip) -> String {
        let base = (s.rsiNo.isEmpty ? "phieu" : s.rsiNo)
            .replacingOccurrences(of: "/", with: "-")
            .replacingOccurrences(of: "'", with: "")
        return base + " (" + String(s.id.uuidString.prefix(8)) + ")"
    }

    /// Tên file ảnh trên Drive: theo số RSI + số trang, ví dụ "RSI-123_1.jpg".
    func driveImageName(for s: Slip, index: Int) -> String {
        let base = (s.rsiNo.isEmpty ? "phieu" : s.rsiNo)
            .replacingOccurrences(of: "/", with: "-")
            .replacingOccurrences(of: "'", with: "")
            .replacingOccurrences(of: ":", with: "-")
            .trimmingCharacters(in: .whitespaces)
        return "\(base)_\(index + 1).jpg"
    }

    var pendingSyncCount: Int {
        slips.filter { $0.driveDirty == true }.count + DriveQueue.deletes.count
    }

    /// Đánh dấu mọi phiếu cần tải lên (dùng khi chuyển phiếu cũ lên Drive).
    func markAllDirty() {
        for i in slips.indices {
            slips[i].driveDirty = true
            slips[i].driveRev = (slips[i].driveRev ?? 0) + 1
        }
        persist()
    }

    func syncSoon() {
        guard DriveConfig.primaryOn else { return }
        Task { await self.syncPending() }
    }

    /// Mở app / quay lại app.
    func driveOnActive() {
        guard DriveConfig.primaryOn else { return }
        purgeSynced()
        syncSoon()
        if slips.isEmpty {
            Task { _ = await self.pullFromDrive() }
        }
    }

    @MainActor
    func syncPending() async {
        guard DriveConfig.primaryOn else { return }
        if syncing { syncAgain = true; return }
        syncing = true
        repeat {
            syncAgain = false
            await syncOnce()
        } while syncAgain
        syncing = false
    }

    @MainActor
    func syncOnce() async {
        // 1. Phiếu đã xoá trong máy thì xoá luôn thư mục trên Drive
        for fid in DriveQueue.deletes {
            do {
                try await DriveClient.shared.deleteFile(fid)
                DriveQueue.removeDelete(fid)
            } catch {
                driveStatus = "Chưa đồng bộ được với Drive: " + error.localizedDescription
                progress = nil
                return
            }
        }
        // 2. Phiếu mới / có sửa
        let todo = slips.filter { $0.driveDirty == true }
        if todo.isEmpty { await flushIndex(); driveStatus = ""; progress = nil; return }
        var done = 0
        for s in todo {
            driveStatus = "Đang đưa lên Drive \(done + 1)/\(todo.count)..."
            progress = TransferProgress(title: "Đang đưa phiếu lên Drive", done: done, total: todo.count,
                                        detail: s.rsiNo.isEmpty ? "phiếu mới" : s.rsiNo)
            do {
                try await uploadSlip(s)
                done += 1
            } catch {
                ActivityLog.shared.add(.failed, rsi: s.rsiNo, detail: error.localizedDescription, slipID: s.id)
                driveStatus = "Chưa lưu được lên Drive, \(todo.count - done) phiếu đang chờ. " + error.localizedDescription
                progress = nil
                await flushIndex()
                return
            }
            if done % 25 == 0 { await flushIndex() }   // ghi chỉ mục từng đợt, lỡ thoát app cũng không mất
        }
        progress = TransferProgress(title: "Đang cập nhật chỉ mục", detail: "index.json")
        await flushIndex()
        driveStatus = ""
        progress = nil
    }

    @MainActor
    func uploadSlip(_ s0: Slip) async throws {
        let client = DriveClient.shared
        let rev = s0.driveRev
        let root = try await client.ensureRoot()
        var s = s0
        let fname = folderName(for: s)

        var folder = s.driveFolderID ?? ""
        var needNew = folder.isEmpty
        if !needNew {
            let ok = await client.exists(folder)
            needNew = !ok
        }
        if needNew {
            folder = try await client.createFolder(name: fname, parent: root)
            s.driveImages = [:]
            s.driveNames = [:]
            s.driveJSONID = nil
        } else {
            await client.rename(folder, to: fname)
        }

        // ảnh mới + đổi tên ảnh theo số RSI
        var imgs = s.driveImages ?? [:]
        var names = s.driveNames ?? [:]
        for (i, name) in s.pages.enumerated() {
            let want = driveImageName(for: s, index: i)
            if let id = imgs[name] {
                if names[name] != want {
                    if await client.rename(id, to: want) { names[name] = want }
                }
            } else {
                guard let data = try? Data(contentsOf: imageURL(name)) else { continue }
                imgs[name] = try await client.uploadData(name: want, mime: "image/jpeg", data: data,
                                                         parent: folder, existingID: nil)
                names[name] = want
            }
        }
        // ảnh đã bị xoá khỏi phiếu
        for (name, id) in imgs where !s.pages.contains(name) {
            try? await client.deleteFile(id)
            imgs[name] = nil
            names[name] = nil
        }

        // thông tin phiếu
        var out = s
        out.driveFolderID = folder
        out.driveImages = imgs
        out.driveNames = names
        out.driveDirty = nil
        let json = try JSONEncoder().encode(out)
        let jid = try await client.uploadData(name: "slip.json", mime: "application/json", data: json,
                                              parent: folder, existingID: s.driveJSONID)

        // ghi kết quả vào danh sách phiếu
        guard let i = slips.firstIndex(where: { $0.id == s.id }) else {
            DriveQueue.addDelete(folder)   // phiếu đã bị xoá trong lúc tải lên
            return
        }
        slips[i].driveFolderID = folder
        slips[i].driveJSONID = jid
        slips[i].driveImages = imgs
        slips[i].driveNames = names
        if slips[i].driveRev == rev {
            slips[i].driveDirty = nil
            persist()
            IndexQueue.mark(slips[i].id, "u")
            ActivityLog.shared.add(.uploaded, rsi: slips[i].rsiNo, detail: "\(slips[i].pages.count) ảnh", slipID: slips[i].id)
            purgeLocal(slips[i])
        } else {
            persist()
            IndexQueue.mark(slips[i].id, "u")
            syncAgain = true   // có sửa thêm trong lúc đang tải lên
        }
    }

    /// Xoá ảnh đầy đủ trong máy của các trang đã có trên Drive (giữ lại ảnh thu nhỏ).
    func purgeLocal(_ s: Slip) {
        let imgs = s.driveImages ?? [:]
        for n in s.pages where imgs[n] != nil {
            _ = thumb(n)
            try? FileManager.default.removeItem(at: imageURL(n))
        }
    }

    func purgeSynced() {
        for s in slips where s.driveDirty != true && s.driveFolderID != nil {
            purgeLocal(s)
        }
    }

    // MARK: Lấy ảnh từ Drive khi cần

    /// Ảnh đầy đủ: có trong máy thì dùng, không thì tải từ Drive (để tạm trong máy).
    @MainActor
    func fullImage(_ name: String) async -> UIImage? {
        if let im = image(name) { return im }
        guard let s = slips.first(where: { $0.pages.contains(name) }),
              let id = s.driveImages?[name],
              let data = try? await DriveClient.shared.downloadData(id) else { return nil }
        try? data.write(to: imageURL(name), options: .atomic)
        return UIImage(data: data)
    }

    @MainActor
    func ensureLocal(_ names: [String]) async {
        let missing = names.filter { !FileManager.default.fileExists(atPath: imageURL($0).path) }
        if missing.isEmpty { return }
        defer { progress = nil }
        for (i, n) in missing.enumerated() {
            progress = TransferProgress(title: "Đang tải ảnh từ Drive về máy", done: i, total: missing.count)
            _ = await fullImage(n)
        }
    }

    /// Ảnh thu nhỏ còn thiếu (máy mới / phiếu tải về từ Drive).
    @MainActor
    func ensureThumbs(_ s: Slip) async {
        var changed = false
        for n in s.pages {
            let t = thumbsDir.appendingPathComponent(n)
            if FileManager.default.fileExists(atPath: t.path) { continue }
            if FileManager.default.fileExists(atPath: imageURL(n).path) { continue }
            guard let id = s.driveImages?[n],
                  let d = try? await DriveClient.shared.downloadData(id),
                  let im = UIImage(data: d),
                  let td = im.normalized(maxSide: 480).jpegData(compressionQuality: 0.7) else { continue }
            try? td.write(to: t, options: .atomic)
            changed = true
        }
        if changed { objectWillChange.send() }
    }

    // MARK: Chỉ mục index.json

    /// Ghi các thay đổi đang chờ vào index.json: tải bản hiện có, áp thay đổi của máy này, ghi lại.
    /// (Gộp theo từng phiếu nên dùng nhiều máy không ghi đè nhau.) Lỗi thì giữ hàng chờ, lần đồng bộ sau làm lại.
    @MainActor
    func flushIndex() async {
        guard DriveConfig.primaryOn else { return }
        let pend = IndexQueue.all
        if pend.isEmpty { return }
        let client = DriveClient.shared
        do {
            let root = try await client.ensureRoot()
            let iid = try await client.findIndexID(root: root)
            var map: [UUID: Slip] = [:]
            if let iid, let d = try? await client.downloadData(iid),
               let x = try? JSONDecoder().decode(DriveIndex.self, from: d) {
                for s in x.slips { map[s.id] = s }
            }
            for (k, op) in pend {
                guard let id = UUID(uuidString: k) else { continue }
                if op == "r" { map[id] = nil; continue }
                guard var s = slips.first(where: { $0.id == id }), s.driveFolderID != nil else { continue }
                s.driveDirty = nil
                s.driveRev = nil
                map[id] = s
            }
            let idx = DriveIndex(slips: map.values.sorted { $0.createdAt < $1.createdAt })
            let data = try JSONEncoder().encode(idx)
            _ = try await client.uploadData(name: DriveClient.indexName, mime: "application/json",
                                            data: data, parent: root, existingID: iid)
            IndexQueue.clear(pend)
        } catch {
            // giữ hàng chờ
        }
    }

    // MARK: Tải lại danh sách phiếu từ Drive (máy mới, cài lại app)

    /// Đọc index.json (1 file) + danh sách thư mục; chỉ quét từng thư mục cho phần chưa có trong chỉ mục.
    /// Ảnh thu nhỏ tải dần khi phiếu hiện trên màn hình.
    @MainActor
    func pullFromDrive() async -> String {
        guard DriveConfig.signedIn else { return "Chưa đăng nhập Google Drive." }
        let client = DriveClient.shared
        defer { progress = nil }
        do {
            progress = TransferProgress(title: "Đang tải lại phiếu từ Drive", detail: "đọc chỉ mục...")
            let root = try await client.ensureRoot()
            let folders = try await client.listChildren(root).filter { $0.mimeType == DriveClient.folderMime }
            let folderIDs = Set(folders.map { $0.id })

            // 1. Chỉ mục
            var indexed: [Slip] = []
            if let id = try? await client.findIndexID(root: root),
               let d = try? await client.downloadData(id),
               let x = try? JSONDecoder().decode(DriveIndex.self, from: d) {
                indexed = x.slips
            }
            let have = Set(slips.map { $0.id })
            var added = 0
            for var s in indexed where !have.contains(s.id) {
                guard let f = s.driveFolderID, folderIDs.contains(f) else { continue }   // thư mục đã bị xoá
                s.driveDirty = nil
                slips.append(s)
                added += 1
            }
            persist()

            // 2. Thư mục chưa nằm trong chỉ mục hoặc trong máy -> quét (song song, lưu từng đợt)
            let covered = Set(indexed.compactMap { $0.driveFolderID }).union(slips.compactMap { $0.driveFolderID })
            let missing = folders.filter { !covered.contains($0.id) }
            var scanned = 0
            var i = 0
            while i < missing.count {
                let batch = Array(missing[i..<min(i + 6, missing.count)])
                progress = TransferProgress(title: "Đang quét thư mục chưa có trong chỉ mục",
                                            done: i, total: missing.count, detail: batch.first?.name ?? "")
                let found: [Slip] = await withTaskGroup(of: Slip?.self) { g in
                    for f in batch { g.addTask { await loadSlipFolder(f, client: client) } }
                    var out: [Slip] = []
                    for await s in g { if let s { out.append(s) } }
                    return out
                }
                let ids = Set(slips.map { $0.id })
                for s in found where !ids.contains(s.id) {
                    slips.append(s)
                    scanned += 1
                }
                i += batch.count
                if (i / 6) % 4 == 0 { persist() }
            }
            added += scanned
            persist()

            // 3. Phiếu có thư mục trên Drive nhưng chưa có trong chỉ mục -> thêm vào chỉ mục
            let inIndex = Set(indexed.map { $0.id })
            for s in slips where s.driveFolderID != nil && s.driveDirty != true && !inIndex.contains(s.id) {
                IndexQueue.mark(s.id, "u")
            }
            progress = TransferProgress(title: "Đang cập nhật chỉ mục", detail: "index.json")
            await flushIndex()
            return added > 0 ? "Đã tải về \(added) phiếu từ Drive." : "Không có phiếu mới trên Drive."
        } catch {
            persist()
            return error.localizedDescription
        }
    }

    /// Tải ảnh thu nhỏ trang đầu khi phiếu (lấy từ chỉ mục) hiện trên màn hình lần đầu.
    @MainActor
    func ensureFirstThumb(_ s: Slip) async {
        guard let first = s.pages.first, !thumbLoading.contains(first),
              !FileManager.default.fileExists(atPath: thumbsDir.appendingPathComponent(first).path),
              !FileManager.default.fileExists(atPath: imageURL(first).path),
              let id = s.driveImages?[first] else { return }
        thumbLoading.insert(first)
        defer { thumbLoading.remove(first) }
        guard let d = try? await DriveClient.shared.downloadData(id), let im = UIImage(data: d),
              let td = im.normalized(maxSide: 480).jpegData(compressionQuality: 0.7) else { return }
        try? td.write(to: thumbsDir.appendingPathComponent(first), options: .atomic)
        objectWillChange.send()
    }
}

/// Đọc một thư mục phiếu trên Drive (slip.json + danh sách ảnh). Phiếu cũ đặt tên ảnh theo UUID thì khớp theo tên file.
func loadSlipFolder(_ f: DriveChild, client: DriveClient) async -> Slip? {
    guard let kids = try? await client.listChildren(f.id),
          let j = kids.first(where: { $0.name == "slip.json" }),
          let data = try? await client.downloadData(j.id),
          var s = try? JSONDecoder().decode(Slip.self, from: data) else { return nil }
    var m = s.driveImages ?? [:]
    let kidIDs = Set(kids.map { $0.id })
    m = m.filter { kidIDs.contains($0.value) }
    for k in kids where k.name != "slip.json" && m[k.name] == nil && s.pages.contains(k.name) { m[k.name] = k.id }
    s.driveFolderID = f.id
    s.driveJSONID = j.id
    s.driveImages = m
    s.driveDirty = nil
    return s
}
