# Phiếu RSI (iOS, SwiftUI)
Quản lý & lưu trữ phiếu xuất hàng (Requestion for storage item - Doosan).
- Quét phiếu bằng camera (tự dò khung, nắn phẳng, ra bản sao như bản gốc) hoặc nhập ảnh từ thư viện.
- Mỗi phiếu RSI tối đa 10 ảnh (quét liên tục nhiều tờ trong 1 lần, hoặc thêm sau bằng nút Sửa). Ảnh thêm vào được đọc để bổ sung kiện hàng, trùng thì bỏ qua.
- Quét tờ có số RSI đã tồn tại: app đề nghị gộp vào phiếu cũ.
- Chọn mức nén ảnh: Nhỏ nhất / Cân bằng / Rõ nét (biểu tượng bánh răng).
- OCR trên máy (Vision): tự điền số RSI, ngày, dự án và bảng kiện hàng (Package No, mô tả, tag, đơn vị, số lượng).
- Luôn có màn hình xác nhận để sửa lại trước khi lưu.
- Tìm theo số RSI, mã kiện, mô tả, ngày. Xuất PDF để gửi.
- Dữ liệu lưu trong máy (Documents), không gửi đi đâu.

Build: đẩy lên GitHub (nhánh main) -> tab Actions -> "Build iOS" -> tải artifact `RSIScan-ipa`.
Cài lên iPhone bằng AltStore/Sideloadly.

Tờ tiếp theo không in số RSI: khi quét app hỏi gắn vào phiếu nào, hoặc vào chi tiết phiếu bấm "Quét tờ tiếp theo".
