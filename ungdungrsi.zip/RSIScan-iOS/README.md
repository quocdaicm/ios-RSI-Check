# Phiếu RSI (iOS, SwiftUI)
Quản lý & lưu trữ phiếu xuất hàng (Requestion for storage item - Doosan).
- Quét phiếu bằng camera riêng: tự kéo 4 góc khung cho khớp tờ giấy rồi bấm nút chụp (nút "Tự dò" để gợi ý khung), xoay ngang được, ảnh ra đúng chiều ngang/dọc như đang cầm máy; hoặc nhập ảnh từ thư viện.
- Mỗi phiếu RSI tối đa 10 ảnh (quét liên tục nhiều tờ trong 1 lần, hoặc thêm sau bằng nút Sửa). Ảnh thêm vào được đọc để bổ sung kiện hàng, trùng thì bỏ qua.
- Quét tờ có số RSI đã tồn tại: app đề nghị gộp vào phiếu cũ.
- Chọn mức nén ảnh: Nhỏ nhất / Cân bằng / Rõ nét (biểu tượng bánh răng).
- Đọc bảng theo tiêu đề cột (TableReader.swift): app tự tìm hàng tiêu đề (Package No, Description, Tag, Unit, Qty/Request, Actual...) rồi đọc từng hàng theo cột, nên mẫu RSI khác tên cột/thứ tự cột vẫn đọc được. Chỗ đọc chưa chắc (thiếu số lượng, chữ mờ, mã trùng, sót dòng so với cột STT) hiện cảnh báo màu cam ở màn xác nhận. Lượt 1 chưa chắc thì tự đọc lại lượt 2 trên ảnh tăng tương phản.
- OCR trên máy (Vision): tự điền số RSI, ngày, dự án và bảng kiện hàng (Package No, mô tả, tag, đơn vị, số lượng).
- Luôn có màn hình xác nhận để sửa lại trước khi lưu.
- Tìm theo số RSI, mã kiện, mô tả, ngày. Xuất PDF để gửi.
- Dữ liệu lưu trong máy (Documents). Sao lưu (tuỳ chọn): đăng nhập Google để app tự tải bản .zip lên Google Drive (thư mục "RSIScan Backup", chỉ truy cập file do app tạo), hoặc chọn thư mục trong Tệp. Cần dán Client ID vào RSIScan/GoogleDrive.swift (xem hướng dẫn bên dưới).

Build: đẩy lên GitHub (nhánh main) -> tab Actions -> "Build iOS" -> tải artifact `RSIScan-ipa`.
Cài lên iPhone bằng AltStore/Sideloadly.

Tờ tiếp theo không in số RSI: khi quét app hỏi gắn vào phiếu nào, hoặc vào chi tiết phiếu bấm "Quét tờ tiếp theo".

Cài đặt Google Drive (làm 1 lần):
1. console.cloud.google.com -> tạo project -> APIs & Services -> Library -> bật "Google Drive API".
2. OAuth consent screen: loại External, điền tên app + email, thêm scope `.../auth/drive.file` và `email`. Bấm "Publish app" (In production) để đăng nhập không hết hạn sau 7 ngày.
3. Credentials -> Create credentials -> OAuth client ID -> loại iOS, Bundle ID = com.quocdai.rsiscan.
4. Copy Client ID dán vào `DriveConfig.clientID` trong RSIScan/GoogleDrive.swift, rồi build lại.
